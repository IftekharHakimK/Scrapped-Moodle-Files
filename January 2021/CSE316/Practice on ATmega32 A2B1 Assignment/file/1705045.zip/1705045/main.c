/*
 * Demo.c
 *
 * Created: 4/6/2021 12:54:20 AM
 * Author : User
 */ 

#define F_CPU 1000000
#include <avr/io.h>
#include <util//delay.h>


int main(void)
{
    /* Replace with your application code */
	DDRC = 0b11010011;
	DDRA = 0b00000000;
	
	unsigned char count = 0;
	int is_up=1;
	PORTC=0b00010000;
    while (1) 
    {
		unsigned char in = PINA;
		if((in&0b0000001)==0) {
			if(is_up){
				count++;
				if(count==16) count = 0;
			}
			else {
				count--;
				if(count==-1) count=15;
			}
			PORTC = (count&0b00000011)|((count<<4)&0b11000000)|((is_up<<4)&0b00010000);
			_delay_ms(500);
		}
		if((in&0b00000010)==0)
		{
			is_up=!is_up;
			count=~count;
			PORTC = (count&0b00000011)|((count<<4)&0b11000000)|((is_up<<4)&0b00010000);
			_delay_ms(500);
		}
    }
}

