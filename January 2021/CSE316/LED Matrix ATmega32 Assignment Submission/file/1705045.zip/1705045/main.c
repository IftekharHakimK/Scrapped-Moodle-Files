
#define F_CPU 1000000
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include <time.h>
#include <stdio.h>

volatile int mode;
unsigned char cols[8]={0,0b01111111,0b01111111,0b00001001,0b00011001,0b00101111,0b01001111,0};

ISR(INT2_vect)
{
	mode^=1;
}

int main(void)
{
	DDRA = 0xFF;
	DDRC = 0xFF;
	GICR = (1<<INT2);
	MCUCSR |= (1<<6);
	sei();
	
	mode = 0;
	
    while (1) 
    {
		if(mode==0) {
			for(int i=0;i<8;i++)
			{
				PORTA=(1<<i);
				PORTC=~cols[i];
				_delay_ms(5);
			}
		}
		else {
			for(int k=1;k<=8;k++)
			{
				for(int i=0;i<8;i++)
				{
					PORTA=(1<<i);
					PORTC=~cols[i];
					_delay_ms(5);
				}
			}
			for(int i=0;i<8;i++)
			{
				cols[i]=(cols[i]<<1)|(cols[i]>>7);
			}
		}
	}
}

