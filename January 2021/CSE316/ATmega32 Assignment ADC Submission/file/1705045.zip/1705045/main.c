//1705045	4.5	ADC5	Right	32
#define F_CPU 1000000
#include <avr/io.h>
#define D4 eS_PORTD4
#define D5 eS_PORTD5
#define D6 eS_PORTD6
#define D7 eS_PORTD7
#define RS eS_PORTC6
#define EN eS_PORTC7
#include "lcd.h"


int main(void)
{
	//LCD initialization
    DDRC=0xFF;
	DDRD=0xFF;
	Lcd4_Init();
	//ADC configuration
	ADMUX=0b00000101;
	ADCSRA=0b10000101;
	char c[14]="Voltage: ";;
    while (1) 
    {
		//Lcd4_Clear();
		ADCSRA |= (1<<ADSC);
		while(ADCSRA&(1<<ADSC)) {;}	
		int result=0;
		result|=ADCL;
		result|=(ADCH&0b00000011)<<8;
		double x= result*4.5/1024;
		int y=round(x*100);;
		
		
		c[12]='0'+(y%10);
		y/=10;
		c[11]='0'+(y%10);
		y/=10;
		c[10]='.';
		c[9]='0'+(y%10);
		c[13]=0;
		Lcd4_Set_Cursor(1,1);
		Lcd4_Write_String(c);
    }
}

