public interface Parser {
    void parse();
}
