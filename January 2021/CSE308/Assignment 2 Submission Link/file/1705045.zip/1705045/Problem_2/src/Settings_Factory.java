public interface Settings_Factory {
    Aesthetics makeAesthetics();
    Parser makeParser();
}
