public class C_Settings_Factory implements Settings_Factory {
    @Override
    public Aesthetics makeAesthetics() {
        return new C_Aesthetics();
    }
    public Parser makeParser(){
        return new C_Parser();
    }
}
