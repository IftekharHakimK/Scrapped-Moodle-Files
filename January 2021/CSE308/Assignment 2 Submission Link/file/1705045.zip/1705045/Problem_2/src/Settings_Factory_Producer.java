public class Settings_Factory_Producer {
    Settings_Factory get_Settings_Factory(String extension)
    {
        if(extension.equals("cpp"))
        {
            return new CPP_Settings_Factory();
        }
        else if(extension.equals("c"))
        {
            return new C_Settings_Factory();
        }
        else if (extension.equals("py"))
        {
            return new Python_Settings_Factory();
        }
        else
        {
            System.out.println("Invalid extension");
            return null;
        }
    }
}
