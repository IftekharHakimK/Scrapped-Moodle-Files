public class CPP_Parser implements Parser {
    @Override
    public void parse() {
        System.out.println("Parsing by CPP parser");
    }
}
