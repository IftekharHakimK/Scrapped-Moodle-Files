public class Python_Aesthetics implements Aesthetics {
    String font="Consolas";

    @Override
    public void show() {
        System.out.println("Python Aesthetics");
        System.out.println("Font = "+font);
    }
}
