public class C_Aesthetics implements Aesthetics {
    String font="Courier New";

    @Override
    public void show() {
        System.out.println("C Aesthetics");
        System.out.println("Font = "+font);
    }
}
