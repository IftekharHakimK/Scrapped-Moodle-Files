public interface Aesthetics {
    void show();
}
