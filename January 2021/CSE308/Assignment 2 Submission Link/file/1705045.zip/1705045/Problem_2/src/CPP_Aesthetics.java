public class CPP_Aesthetics implements Aesthetics {
    String font="Monaco";

    @Override
    public void show() {
        System.out.println("CPP Aesthetics");
        System.out.println("Font = "+font);
    }
}
