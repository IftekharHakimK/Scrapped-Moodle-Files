import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
	    Editor editor = null;
	    while (true)
        {
            String command=scanner.next();
            if(command.equals("Open")) {
                String filename = scanner.next();

                editor = Editor.getInstance();
                editor.openFile(filename);
            }
            else if(command.equals("Close"))
            {
                Editor.close();
            }
            else if(command.equals("Stop"))
            {
                break;
            }
        }
    }
}
