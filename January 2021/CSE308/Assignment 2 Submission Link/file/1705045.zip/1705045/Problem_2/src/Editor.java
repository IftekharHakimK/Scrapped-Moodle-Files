public class Editor {
    private static Editor instance=null;
    private Aesthetics current_aesthetics=null;
    private Parser current_parser=null;
    private Settings_Factory settings_factory=null;
    private Settings_Factory_Producer settings_factory_producer=null;

    private Editor()
    {
        System.out.println("New instance of editor made");
    }
    public static Editor getInstance()
    {
        if(instance==null)
        {
            instance=new Editor();
        }
        return instance;
    }
    public void openFile(String filename)
    {
        String[] all=filename.split("\\.");
        int len=all.length;
        if(len<2)
        {
            System.out.println("Wrong file name format");
            return;
        }
        String extension = all[len-1];

        settings_factory_producer=new Settings_Factory_Producer();
        settings_factory=settings_factory_producer.get_Settings_Factory(extension);
        if(settings_factory==null)
            return;

        current_aesthetics=settings_factory.makeAesthetics();
        current_parser=settings_factory.makeParser();

        current_aesthetics.show();
        current_parser.parse();
        return;
    }
    public static void close()
    {
        instance=null;
    }
}
