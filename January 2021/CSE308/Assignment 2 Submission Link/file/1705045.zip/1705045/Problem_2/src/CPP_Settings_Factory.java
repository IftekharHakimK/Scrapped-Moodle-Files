public class CPP_Settings_Factory implements Settings_Factory {
    @Override
    public Aesthetics makeAesthetics() {
        return new CPP_Aesthetics();
    }
    public Parser makeParser(){
        return new CPP_Parser();
    }
}
