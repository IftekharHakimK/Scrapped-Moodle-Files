public class C_Parser implements Parser {
    @Override
    public void parse() {
        System.out.println("Parsing by C parser");
    }
}
