public class Python_Parser implements Parser {
    @Override
    public void parse() {
        System.out.println("Parsing by Python parser");
    }
}
