public class Python_Settings_Factory implements Settings_Factory {

    @Override
    public Aesthetics makeAesthetics() {
        return new Python_Aesthetics();
    }

    @Override
    public Parser makeParser(){
        return new Python_Parser();
    }
}
