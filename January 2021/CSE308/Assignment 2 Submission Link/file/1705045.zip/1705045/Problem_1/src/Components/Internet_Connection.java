package Components;

public interface Internet_Connection {
    void connect();
}
