package Components;

public class WeightModule implements WeightMeasurer {
    @Override
    public void measure() {
        System.out.println("Measuring with Weight Module");
    }
}
