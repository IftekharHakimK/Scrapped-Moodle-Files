package Admin;

public interface FrameWork {
    void develop();
}
