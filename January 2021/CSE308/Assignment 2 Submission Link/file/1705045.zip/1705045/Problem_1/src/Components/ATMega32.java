package Components;

public class ATMega32 implements Microprocessor {
    @Override
    public void work() {
        System.out.println("Working via ATMega32");
    }

}
