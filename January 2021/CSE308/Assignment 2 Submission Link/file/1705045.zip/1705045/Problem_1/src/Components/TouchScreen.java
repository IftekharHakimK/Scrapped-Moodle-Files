package Components;

public class TouchScreen implements Display, Controller {
    @Override
    public void showSomething() {
        System.out.println("Showing something from Touch Screen Display");
    }

    @Override
    public void control() {
        System.out.println("Controlling directly by Touch Screen");
    }
}
