package Components;

public class RFIDCard implements Identification {
    @Override
    public void identify()
    {
        System.out.println("Identifying by RFID Card");
    }
}
