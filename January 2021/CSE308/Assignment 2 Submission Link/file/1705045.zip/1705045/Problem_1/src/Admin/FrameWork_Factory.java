package Admin;
public class FrameWork_Factory {
    public FrameWork getFrameWork(String s)
    {
        if(s.equals("Django"))
            return new Django();
        else if(s.equals("Spring"))
            return new Spring();
        else if(s.equals("Laravel"))
            return new Laravel();
        else
        {
            System.out.println("Warning, wrong framework choice");
            return null;
        }

    }
}
