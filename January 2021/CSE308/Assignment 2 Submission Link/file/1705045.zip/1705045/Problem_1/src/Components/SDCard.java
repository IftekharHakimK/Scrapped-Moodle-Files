package Components;

public class SDCard implements Storage {
    public void viewStorage()
    {
        System.out.println("Viewing storage from SD Card");
    }
}
