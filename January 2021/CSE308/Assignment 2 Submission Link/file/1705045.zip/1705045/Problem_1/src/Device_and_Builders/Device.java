package Device_and_Builders;

import Components.*;

public class Device {
    private Microprocessor microprocessor=null;
    private WeightMeasurer weightMeasurer=null;
    private Identification identification=null;
    private Storage storage=null;
    private Display display=null;
    private Internet_Connection internet_connection=null;
    private Controller controller=null;
    public Device()
    {
        ;
    }

    public void setMicroprocessor(Microprocessor microprocessor) {
        this.microprocessor = microprocessor;
    }

    public void setWeightMeasurer(WeightMeasurer weightMeasurer) {
        this.weightMeasurer = weightMeasurer;
    }

    public void setIdentification(Identification identification) {
        this.identification = identification;
    }

    public void setStorage(Storage storage) {
        this.storage = storage;
    }

    public void setDisplay(Display display) {
        this.display = display;
    }

    public void setInternet_connection(Internet_Connection internet_connection) {
        this.internet_connection = internet_connection;
    }

    public void setController(Controller controller) {
        this.controller = controller;
    }

    public Microprocessor getMicroprocessor() {
        return microprocessor;
    }

    public WeightMeasurer getWeightMeasurer() {
        return weightMeasurer;
    }

    public Identification getIdentification() {
        return identification;
    }

    public Storage getStorage() {
        return storage;
    }

    public Display getDisplay() {
        return display;
    }

    public Internet_Connection getInternet_connection() {
        return internet_connection;
    }

    public Controller getController() {
        return controller;
    }

    public void work()
    {
        if(microprocessor==null)
        {
            System.out.println("No microprocessor");
            return;
        }
        microprocessor.work();
    }

    public void measure()
    {
        if(weightMeasurer==null)
        {
            System.out.println("No measurer");
            return;
        }
        weightMeasurer.measure();
    }
    public void identify()
    {
        if(identification==null)
        {
            System.out.println("No identifier");
            return;
        }
        identification.identify();
    }
    public void viewStorage()
    {
        if(storage==null)
        {
            System.out.println("No storage");
            return;
        }
        storage.viewStorage();
    }
    public void showSomething()
    {
        if(display==null)
        {
            System.out.println("No display");
            return;
        }
        display.showSomething();
    }
    public void connect()
    {
        if(internet_connection==null)
        {
            System.out.println("No connection");
            return;
        }
        internet_connection.connect();
    }
    public void control()
    {
        if(controller==null)
        {
            System.out.println("No controller");
            return;
        }
        controller.control();
    }
}
