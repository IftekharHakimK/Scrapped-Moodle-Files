package Device_and_Builders;

public class Package_Factory {
    public DeviceBuilder getDeviceBuilder(String package_name)
    {
        if(package_name.equals("Silver"))
            return new Builder_Silver();
        else if(package_name.equals("Gold"))
            return new Builder_Gold();
        else if(package_name.equals("Diamond"))
            return new Builder_Diamond();
        else if(package_name.equals("Platinum"))
            return new Builder_Platinum();
        else
        {
            System.out.printf("Warning, wrong package name");
            return null;
        }
    }
}
