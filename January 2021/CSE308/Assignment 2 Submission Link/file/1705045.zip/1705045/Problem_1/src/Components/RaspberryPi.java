package Components;

public class RaspberryPi implements Microprocessor, Storage {
    @Override
    public void work() {
        System.out.println("Working via RaspberryPi");
    }

    @Override
    public void viewStorage() {
        System.out.println("Viewing storage by built-in storage of RaspberryPi");
    }
}
