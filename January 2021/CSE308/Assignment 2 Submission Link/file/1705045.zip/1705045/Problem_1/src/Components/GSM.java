package Components;

public class GSM implements Internet_Connection{
    @Override
    public void connect() {
        System.out.println("Connecting via GSM");
    }
}
