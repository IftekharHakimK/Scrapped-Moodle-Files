package Device_and_Builders;

public interface DeviceBuilder {
    void makeMicroprocessor();
    void makeIdentification();
    void makeWeightMeasurer();
    void makeStorage();
    void makeDisplay();
    void makeInternetConnection(String selected_internet);
    void makeController();
    Device getDevice();
}
