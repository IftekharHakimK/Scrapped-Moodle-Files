package Components;

public interface WeightMeasurer {
    void measure();
}
