package Admin;
public class Django implements FrameWork {
    @Override
    public void develop() {
        System.out.println("Developing by Django");
    }
}
