package Admin;

public class Spring implements FrameWork {
    @Override
    public void develop() {
        System.out.println("Developing by Spring");
    }
}
