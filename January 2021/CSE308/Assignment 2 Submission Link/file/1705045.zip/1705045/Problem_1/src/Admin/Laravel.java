package Admin;

public class Laravel implements FrameWork {
    @Override
    public void develop() {
        System.out.println("Developing by Laravel");
    }
}
