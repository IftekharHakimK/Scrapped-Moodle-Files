package Components;

public class ButtonPad implements Controller {
    @Override
    public void control() {
        System.out.println("Controlling by Button");
    }
}
