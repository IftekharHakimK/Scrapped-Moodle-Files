package Components;

public class ArduinoMega implements Microprocessor {
    @Override
    public void work() {
        System.out.println("Working via Arduino Mega");
    }
}
