package Components;
public class Ethernet implements Internet_Connection {
    @Override
    public void connect() {
        System.out.println("Connecting via Ethernet");
    }
}
