package Device_and_Builders;

public class Director {
    public void build(DeviceBuilder deviceBuilder, String selected_internet)
    {
        deviceBuilder.makeMicroprocessor();
        deviceBuilder.makeWeightMeasurer();
        deviceBuilder.makeIdentification();
        deviceBuilder.makeStorage();
        deviceBuilder.makeDisplay();
        deviceBuilder.makeInternetConnection(selected_internet);
        deviceBuilder.makeController();
        return;
    }
}
