package Components;

public interface Storage {
    void viewStorage();
}
