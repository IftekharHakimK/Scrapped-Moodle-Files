package Device_and_Builders;

import Components.*;

public class Builder_Diamond implements DeviceBuilder {
    private Device device=null;
    Builder_Diamond()
    {
        device=new Device();
    }
    public void makeMicroprocessor()
    {
        Microprocessor microprocessor=new RaspberryPi();
        device.setMicroprocessor(microprocessor);
    }
    public void makeIdentification()
    {
        Identification identification=new NFCCard();
        device.setIdentification(identification);
    }
    public void makeWeightMeasurer()
    {
        WeightMeasurer weightMeasurer=new LoadSensor();
        device.setWeightMeasurer(weightMeasurer);
    }
    public void makeStorage()
    {
        device.setStorage((Storage)device.getMicroprocessor());
    }
    public void makeDisplay()
    {
        Display display=new TouchScreen();
        device.setDisplay(display);
    }
    public void makeInternetConnection(String selected_internet)
    {
        if(!(selected_internet.equals("WIFI")||selected_internet.equals("GSM")||selected_internet.equals("Ethernet")))
        {
            System.out.println("Incompatible choice of connection");
            return;
        }
        Internet_Connection_Factory internet_Connection_Factory=new Internet_Connection_Factory();
        Internet_Connection internet_connection=internet_Connection_Factory.getConnection(selected_internet);
        device.setInternet_connection(internet_connection);
    }
    public void makeController()
    {
        device.setController((Controller) device.getDisplay());
    }
    public Device getDevice()
    {
        return device;
    }
}
