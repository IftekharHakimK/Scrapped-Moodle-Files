package Components;

public interface Identification {
    void identify();
}
