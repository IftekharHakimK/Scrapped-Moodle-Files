package Device_and_Builders;

import Components.*;

public class Builder_Silver implements DeviceBuilder {
    private Device device=null;
    Builder_Silver()
    {
        device=new Device();
    }
    public void makeMicroprocessor()
    {
        Microprocessor microprocessor=new ATMega32();
        device.setMicroprocessor(microprocessor);
    }
    public void makeIdentification()
    {
        Identification identification=new RFIDCard();
        device.setIdentification(identification);
    }
    public void makeWeightMeasurer()
    {
        WeightMeasurer weightMeasurer=new LoadSensor();
        device.setWeightMeasurer(weightMeasurer);
    }
    public void makeStorage()
    {
        Storage storage=new SDCard();
        device.setStorage(storage);
    }
    public void makeDisplay()
    {
        Display display=new LCD_Display();
        device.setDisplay(display);
    }
    public void makeInternetConnection(String selected_internet)
    {
        if(!(selected_internet.equals("WIFI")||selected_internet.equals("GSM")))
        {
            System.out.println("Incompatible choice of connection");
            return;
        }
        Internet_Connection_Factory internet_Connection_Factory=new Internet_Connection_Factory();
        Internet_Connection internet_connection=internet_Connection_Factory.getConnection(selected_internet);
        device.setInternet_connection(internet_connection);
    }
    public void makeController()
    {
        Controller controller=new ButtonPad();
        device.setController(controller);
    }
    public Device getDevice()
    {
        return device;
    }
}
