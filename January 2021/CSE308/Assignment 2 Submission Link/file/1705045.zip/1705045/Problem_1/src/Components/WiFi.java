package Components;

public class WiFi implements Internet_Connection {
    @Override
    public void connect() {
        System.out.println("Connecting via WIFI");
    }

}
