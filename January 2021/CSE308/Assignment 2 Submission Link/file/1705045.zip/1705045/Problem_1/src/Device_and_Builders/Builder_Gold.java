package Device_and_Builders;

import Components.*;

public class Builder_Gold implements DeviceBuilder {
    private Device device=null;
    Builder_Gold()
    {
        device=new Device();
    }
    public void makeMicroprocessor()
    {
        Microprocessor microprocessor=new ArduinoMega();
        device.setMicroprocessor(microprocessor);
    }
    public void makeIdentification()
    {
        Identification identification=new RFIDCard();
        device.setIdentification(identification);
    }
    public void makeWeightMeasurer()
    {
        WeightMeasurer weightMeasurer=new WeightModule();
        device.setWeightMeasurer(weightMeasurer);
    }
    public void makeStorage()
    {
        Storage storage=new SDCard();
        device.setStorage(storage);
    }
    public void makeDisplay()
    {
        Display display=new LED_Display();
        device.setDisplay(display);
    }
    public void makeInternetConnection(String selected_internet)
    {
        if(!(selected_internet.equals("WIFI")||selected_internet.equals("GSM")))
        {
            System.out.println("Incompatible choice of connection");
            return;
        }
        Internet_Connection_Factory internet_Connection_Factory=new Internet_Connection_Factory();
        Internet_Connection internet_connection=internet_Connection_Factory.getConnection(selected_internet);
        device.setInternet_connection(internet_connection);
    }
    public void makeController()
    {
        Controller controller=new ButtonPad();
        device.setController(controller);
    }
    public Device getDevice()
    {
        return device;
    }
}
