package Components;

public class LCD_Display implements Display {
    @Override
    public void showSomething() {
        System.out.println("Showing something from LCD Display");
    }
}
