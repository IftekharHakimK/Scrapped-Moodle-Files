package Components;

public interface Microprocessor {
    void work();
}
