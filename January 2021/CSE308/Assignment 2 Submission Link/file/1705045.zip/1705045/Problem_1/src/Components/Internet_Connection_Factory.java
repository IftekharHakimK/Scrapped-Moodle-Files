package Components;

public class Internet_Connection_Factory {
    public Internet_Connection getConnection(String s)
    {
        if(s.equals("WIFI"))
            return new WiFi();
        else if(s.equals("Ethernet"))
            return new Ethernet();
        else if(s.equals("GSM"))
            return new GSM();
        else
        {
            System.out.println("Warning, wrong choice of internet connection");
            return null;
        }
    }
}
