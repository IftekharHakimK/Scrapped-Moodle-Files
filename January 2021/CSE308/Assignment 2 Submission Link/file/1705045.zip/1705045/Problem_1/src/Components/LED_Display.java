package Components;

public class LED_Display implements Display {
    @Override
    public void showSomething() {
        System.out.println("Showing something from LED Display");
    }
}
