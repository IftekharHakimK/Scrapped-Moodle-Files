package Components;

public class NFCCard implements Identification {
    @Override
    public void identify() {
        System.out.println("Identifying by NFC Card");
    }
}
