package Components;

public interface Controller {
    void control();
}
