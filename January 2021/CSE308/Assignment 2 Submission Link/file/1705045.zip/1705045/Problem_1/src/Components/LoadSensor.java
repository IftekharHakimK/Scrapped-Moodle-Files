package Components;

public class LoadSensor implements WeightMeasurer {
    @Override
    public  void measure()
    {
        System.out.println("Measuring by Load Sensor");
    }
}
