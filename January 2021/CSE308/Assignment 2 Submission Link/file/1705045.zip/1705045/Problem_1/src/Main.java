import Admin.*;
import Device_and_Builders.*;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);


        Package_Factory package_factory=new Package_Factory();
        Director director=new Director();
        DeviceBuilder deviceBuilder;
        FrameWork_Factory frameWork_factory=new FrameWork_Factory();

        while(true)
        {
            String package_name;
            String selected_internet;
            String framework_name;
            System.out.printf("Package choice: ");
            package_name=scanner.nextLine();
            if(package_name.equals("Stop"))
            {
                break;
            }
            System.out.printf("Internet choice: ");
            selected_internet=scanner.nextLine();
            System.out.printf("Framework choice: ");
            framework_name=scanner.nextLine();



            deviceBuilder=package_factory.getDeviceBuilder(package_name);
            director.build(deviceBuilder, selected_internet);
            Device device=deviceBuilder.getDevice();

            device.work();
            device.measure();
            device.identify();
            device.viewStorage();
            device.showSomething();
            device.connect();
            device.control();

            FrameWork frameWork=frameWork_factory.getFrameWork(framework_name);
            frameWork.develop();

        }


    }
}
