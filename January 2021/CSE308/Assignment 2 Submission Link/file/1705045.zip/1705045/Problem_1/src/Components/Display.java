package Components;

public interface Display {
    void showSomething();
}
