import java.util.ArrayList;
import java.util.Scanner;

abstract class Account {
    protected String name;
    protected double balance;
    protected double reqLoan;
    protected double approvedLoan;
    protected int maturity;

    Account(String _name,double initialDeposit)
    {
        name=_name;
        balance=initialDeposit;
        reqLoan=approvedLoan=0;
        maturity=0;

        System.out.println("Account created for "+name+". Initial balance "+balance);
    }

    String getName()
    {
        return name;
    }
    double getBalance()
    {
        return balance;
    }
    double getReqLoan()
    {
        return reqLoan;
    }
    void addApprovedLoan(double c)
    {
        approvedLoan+=c;
        balance+=c;
        return;
    }
    void resetReqLoan()
    {
        reqLoan=0;
        return;
    }
    void query()
    {
        System.out.println("Current balance = "+balance+". Loan = "+approvedLoan);
        return;
    }
    void INC(double interestRate)
    {
        maturity+=1;
        balance=balance+balance*interestRate-approvedLoan*0.1;
        return;
    }
    abstract void deposit(double c);
    abstract void withdraw(double c);
    abstract void requestLoan(double c);
}

class Savings extends Account {
    Savings (String name, double initialDeposit)
    {
        super(name, initialDeposit);
    }
    void deposit(double c)
    {
        balance+=c;
        System.out.println("Deposited "+c+". Balance = "+balance);
    }

    void withdraw(double c) {
        if(balance-c<1000) {
            System.out.println("Wrong withdrawal for Savings account");
            return;
        }
        balance-=c;
        System.out.println("Withdrawn "+c+". Balance = "+balance);
    }
    void requestLoan(double c)
    {
        if(c>10000)
        {
            System.out.println("Wrong loan request for Savings account");
            return;
        }
        reqLoan+=c;
        System.out.println("Loan requested for "+c);
    }
    void INC(double interestRate)
    {
        super.INC(interestRate);
        balance-=500;
    }
}
class Student extends Account {
    Student (String name, double initialDeposit)
    {
        super(name,initialDeposit);
    }

    void deposit(double c)
    {
        balance+=c;
        System.out.println("Deposited "+c+". Balance = "+balance);
        return;
    }

    void withdraw(double c) {
        if(c>10000||balance<c) {
            System.out.println("Wrong withdrawal for Student account");
            return;
        }
        balance-=c;
        System.out.println("Withdrawn "+c+". Balance = "+balance);
    }
    void requestLoan(double c)
    {
        if(c>1000)
        {
            System.out.println("Wrong loan request for Student account");
            return;
        }
        reqLoan+=c;
        System.out.println("Loan requested for "+c);
    }
}
class Fixed extends Account{
    Fixed (String name, double initialDeposit)
    {
        super(name,initialDeposit);
    }
    void deposit(double c){
        if(c<50000)
        {
            System.out.println("Deposit needs to be more than 50000 for Fixed account");
            return;
        }
        balance+=c;
        System.out.println("Deposited "+c+". Balance = "+balance);
    }
    void withdraw(double c) {
        if(maturity<1||balance < c) {
            System.out.println("Wrong withdrawal for Fixed account");
            return;
        }
        balance-=c;
        System.out.println("Withdrawn "+c+". Balance = "+balance);
    }
    void requestLoan(double c)
    {
        if(c>100000)
        {
            System.out.println("Wrong loan request for Fixed account");
            return;
        }
        reqLoan+=c;
    }
    void INC(double interestRate)
    {
        super.INC(interestRate);
        balance-=500;
    }
}

abstract class Employee {
    private String name;
    Employee(String _name)
    {
        name=_name;
    }
    String getName()
    {
        return name;
    }
    void lookup(String name, ArrayList<Account> accounts)
    {
        for(Account acc: accounts)
        {
            if(name.equals(acc.getName()))
            {
                System.out.println("Balance = " + acc.getBalance());
                break;
            }
        }
        return;
    }
    double approveLoan(ArrayList<Account> accounts,double fund)
    {
        System.out.println("Access failed.");
        return fund;
    }
    void changeRate(String type, double c, ArrayList<Double> rates)
    {
        System.out.println("Access failed.");
        return;
    }
    void seeInternalFund(double fund)
    {
        System.out.println("Access failed.");
        return;
    }
}

class MD extends Employee {
    MD(String _name)
    {
        super(_name);
    }
    double approveLoan(ArrayList<Account> accounts,double fund) {
        for(Account acc: accounts)
        {
            double amount=acc.getReqLoan();
            if(amount>0 && fund>=amount)
            {
                System.out.println("Loan for "+acc.getName()+" successful");
                fund-=amount;
                acc.addApprovedLoan(amount);
                acc.resetReqLoan();
            }
        }
        return fund;
    }
    void changeRate(String type, double c, ArrayList<Double> rates)
    {
        if(type.equals("Student")) rates.set(0, c/100);
        else if(type.equals("Fixed")) rates.set(1, c/100);
        else if(type.equals("Savings")) rates.set(2, c/100);
        System.out.println("Changed rate for "+type);
        return;
    }
    void seeInternalFund(double fund)
    {
        System.out.println("Bank fund = "+fund);
    }
}
class Officer extends Employee {
    Officer(String _name)
    {
        super(_name);
    }
    double approveLoan(ArrayList<Account> accounts,double fund) {
        for(Account acc: accounts)
        {
            double amount=acc.getReqLoan();
            if(amount>0 && fund>=amount)
            {
                System.out.println("Loan for "+acc.getName()+" successful");
                fund-=amount;
                acc.addApprovedLoan(amount);
                acc.resetReqLoan();
            }
        }
        return fund;
    }
}

class Cashier extends Employee {
    Cashier(String _name)
    {
        super(_name);
    }
}

class Bank {
    private double fund;
    
    private Employee employees[];

    private ArrayList<Account> accounts;
    private ArrayList<Double> rates; //Order - Student, Fixed, Savings 

    Bank()
    {
        fund=1000000;
        
        employees=new Employee[8];
        employees[0]=new MD("MD");
        for(int i=1;i<=2;i++)
        {
            employees[i]=new Officer("O"+i);
        }
        for(int i=3,p=1;i<=7;i++,p++)
        {
            employees[i]=new Cashier("C"+p);
        }

        accounts=new ArrayList<Account>();
        rates=new ArrayList<Double>();
        rates.add(0.05);
        rates.add(0.15);
        rates.add(0.10);

        System.out.println("Bank instantiated");
    }
    
    Employee getEmployee(String name)
    {
        for(Employee e:employees)
        {
            if(name.equals(e.getName()))
            {
                return e;
            }
        }
        System.out.println("Invalid Employee");
        return null;
    }

    void createAccount(String name, String type, double initialDeposit)
    {
        if(type.equals("Fixed")&&initialDeposit<100000)
        {
            System.out.println("Failed to create account, low initial deposit");
            return;
        }
        for(Account acc:accounts)
        {
            if(name.equals(acc.name))
            {
                System.out.println("User with same name exists");
                return;
            }
        }

        if(type.equals("Fixed"))
        {
            Account acc=new Fixed(name,initialDeposit);
            accounts.add(acc);
        }
        else if(type.equals("Savings"))
        {
            Account acc=new Savings(name,initialDeposit);
            accounts.add(acc);
        }
        else if(type.equals("Student"))
        {
            Account acc=new Student (name,initialDeposit);
            accounts.add(acc);
        }
    }
    void makeDeposit(String name,double c)
    {
        for(Account acc:accounts)
        {
            if(name.equals(acc.getName()))
            {
                acc.deposit(c);
                return;
            }
        }
    }
    void makeWithdraw(String name,double c)
    {
        for(Account acc:accounts)
        {
            if(name.equals(acc.getName()))
            {
                acc.withdraw(c);
                return;
            }
        }
    }
    void makeRequest(String name,double c)
    {
        for(Account acc:accounts)
        {
            if(name.equals(acc.getName()))
            {
                acc.requestLoan(c);
                return;
            }
        }
    }
    void checkBalance(String name) {
        for(Account acc:accounts)
        {
            if(name.equals(acc.name))
            {
                acc.query();
                return;
            }
        }
    }
    void makeINC()
    {
        for(Account acc:accounts)
        {
            if(acc instanceof Student)
                acc.INC(rates.get(0));
            else if(acc instanceof Fixed)
                acc.INC(rates.get(1));
            else if(acc instanceof Savings)
                acc.INC(rates.get(2));
        }
        return;
    }
    void makeLookup(String emp, String name)
    {
        Employee e=getEmployee(emp);
        if(e==null)
        {
            return;
        }
        e.lookup(name, accounts);
    }

    void doApproveLoan(String emp)
    {
        Employee e=getEmployee(emp);
        if(e==null)
        {
            return;
        }
        if((e instanceof MD)||(e instanceof Officer))
        {
            fund=e.approveLoan(accounts, fund);
        }
        else
        {
            System.out.println("Access Denied");
        }
    }
    void doChangeRates(String emp, String type, double c) 
    {
        Employee e=getEmployee(emp);
        if(e==null)
        {
            return;
        }
        if(e instanceof MD)
        {
            e.changeRate(type, c, rates);
        }
        else
        {
            System.out.println("Access Denied");
        }
    }
    void doSeeFund(String emp)
    {
        Employee e=getEmployee(emp);
        if(e==null)
        {
            return;
        }
        if(e instanceof MD)
        {
            e.seeInternalFund(fund);
        }
        else
        {
            System.out.println("Access Denied");
        }
    }
}

public class Offline {
    public static void main(String [] args) {
        Bank bank=new Bank();
        Scanner sc=new Scanner(System.in);
        String loggedUser="";

        while(true)
        {
            String command;
            command=sc.next();
            if(command.equals("Create"))
            {
                String name,type;
                double initialDeposit;
                name=sc.next();
                type=sc.next();
                initialDeposit=sc.nextDouble();
                bank.createAccount(name, type, initialDeposit);
                loggedUser=name;
            }
            else if(command.equals("Deposit"))
            {
                double c;
                c=sc.nextDouble();
                bank.makeDeposit(loggedUser,c);
            }
            else if(command.equals("Withdraw"))
            {
                double c;
                c=sc.nextDouble();
                bank.makeWithdraw(loggedUser,c);
            }
            else if(command.equals("Request"))
            {
                double c;
                c=sc.nextDouble();
                bank.makeRequest(loggedUser,c);
            }
            else if(command.equals("Query"))
            {
                bank.checkBalance(loggedUser);
            }
            else if(command.equals("INC"))
            {
                bank.makeINC();
            }
            else if(command.equals("Open"))
            {
                loggedUser=sc.next();
            }
            else if(command.equals("Lookup"))
            {
                String name=sc.next();
                bank.makeLookup(loggedUser, name);
            }
            else if(command.equals("ApproveLoan")) 
            {
                bank.doApproveLoan(loggedUser);
            }
            else if(command.equals("Change"))
            {
                String type;
                double c;
                type=sc.next();
                c=sc.nextDouble();
                bank.doChangeRates(loggedUser,type,c);
            }
            else if(command.equals("See"))
            {
                bank.doSeeFund(loggedUser);
            }
            else if(command.equals("Close"))
            {
                System.out.println(loggedUser+" Logged out");
                loggedUser="";
            }
            else if(command.equals("Stop"))
            {
                break;
            }
            
        }
        sc.close();
    }
}