import java.util.ArrayList;

public class SortClass {

    public ArrayList<Integer> sort(ArrayList<Integer> list)
    {
        if(list==null)
            return null;
        for(int i=0;i+1<list.size();i++)
        {
            for(int j=i+1;j<list.size();j++)
            {
                int a = list.get(i);
                int b = list.get(j);
                if(a>b)
                {
                    list.set(i,b);
                    list.set(j,a);
                }
            }
        }
        return list;
    }

}
