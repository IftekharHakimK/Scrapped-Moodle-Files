import java.util.*;

import org.junit.Test;

import static org.junit.Assert.*;

public class SortClassTest {
    boolean isUnaltered(ArrayList<Integer> input, ArrayList<Integer> output)
    {
        if(input!=null&&output==null) return false;
        if(input==null&&output!=null) return false;
        if(input==null&&output==null) return true;
        if(input.size()!=output.size()) return false;

        int n=input.size();
        boolean [] marked = new boolean[n];
        for(int i=0;i<n;i++)
        {
            marked[i]=false;
        }

        int totalMarked=0;
        for(int i=0;i<n;i++) {
            for (int j = 0; j < n; j++) {
                int a=input.get(i);
                int b=output.get(j);
                if (a==b && marked[j] == false) {
                    marked[j] = true;
                    totalMarked++;
                    break;
                }
            }
        }
        return totalMarked==n;
    }

    boolean isSorted(ArrayList<Integer> output)
    {
        if(output==null) return true;
        for(int i=1;i<output.size();i++)
        {
            int a=output.get(i-1);
            int b=output.get(i);
            if(a>b)
            {
                return false;
            }
        }
        return true;
    }

    @Test
    public void sort_Blank_List() {
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();
        ArrayList<Integer> output;

        output = sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for blank list \n" +
                    "input = " + input + "\n"+
                    "output = "+ output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_One_Number() {

        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>(Arrays.asList(20));
        ArrayList<Integer> output;

        output=sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for One number \n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_Two_Number() {

        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>(Arrays.asList(20,10));
        ArrayList<Integer> output;

        output=sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for Two number \n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_Random_Size() {
        Random random = new Random(500);

        int n=random.nextInt(20);
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();

        for(int i=0;i<n;i++)
            input.add(10-i);

        ArrayList<Integer> output;

        output=sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for random size \n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_Random_Elements() {
        Random random = new Random(500);

        int n=30;
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();

        for(int i=0;i<n;i++)
            input.add(random.nextInt(500));

        ArrayList<Integer> output;

        output=sortClass.sort(new ArrayList<>(input));

        assertTrue("Failed for random elements \n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_Ascending_Elements()
    {
        int n=10;
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();

        for(int i=0;i<n;i++)
            input.add(i*5);

        ArrayList<Integer> output;

        output=sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for ascending elements \n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_Descending_Elements()
    {
        int n=10;
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();

        for(int i=0;i<n;i++)
            input.add(10-i*5);

        ArrayList<Integer> output;

        output=sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for descending elements\n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));

    }

    @Test
    public void sort_Equal_Elements()
    {
        int n=10;
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();

        for(int i=0;i<n;i++)
            input.add(100);

        ArrayList<Integer> output;

        output=sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for equal elements\n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_Null_List()
    {
        SortClass sortClass = new SortClass();

        ArrayList<Integer> output = sortClass.sort(null);
        assertNull("Failed for null",output);
    }

    @Test
    public void sort_all_negative()
    {
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();
        Random random = new Random(500);
        for(int i=0;i<10;i++)
        {
            input.add(random.nextInt(500)-1000);
        }
        ArrayList<Integer> output;
        output = sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for all negative \n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test
    public void sort_MX_MN()
    {
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();
        for(int i=0;i<5;i++) input.add(Integer.MAX_VALUE);
        for(int i=0;i<5;i++) input.add(Integer.MIN_VALUE);

        ArrayList output = sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for MX MN \n"+
                "input = "+input+"\n"+
                "output = "+output,isUnaltered(input,output)&&isSorted(output));
    }

    @Test(timeout = 2000)
    public void sort_time_testing()
    {
        SortClass sortClass = new SortClass();
        ArrayList<Integer> input = new ArrayList<>();
        Random random = new Random(500);
        for(int i=0;i<4000;i++)
            input.add(random.nextInt(1000));
        ArrayList output = sortClass.sort(new ArrayList<>(input));
        assertTrue("Failed for time testing",isUnaltered(input,output)&&isSorted(output));
    }

}