public abstract class Appetizer extends FoodDecorator {
}
