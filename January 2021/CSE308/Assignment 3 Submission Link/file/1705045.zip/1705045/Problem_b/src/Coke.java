public class Coke extends Drink {

    public Coke(Food food)
    {
        this.food=food;
    }

    @Override
    public String description() {
        return food.description()+"Coke : Tk. 30 \n";
    }

    @Override
    public int getCost() {
        return food.getCost()+30;
    }
}
