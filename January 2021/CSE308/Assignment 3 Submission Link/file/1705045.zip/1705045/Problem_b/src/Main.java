import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        Scanner scanner=new Scanner(System.in);

        while(true) {
            int choice = scanner.nextInt();
            if (choice == 0)
                break;
            if (choice == 1) {
                Food food = new BeefPizza();
                food = new FrenchFries(food);

                System.out.println("Total cost : "+food.getCost());
                System.out.println("List : \n"+food.description());
            }
            else if(choice == 2)
            {
                Food food = new VeggiPizza();
                food = new OnionRings(food);

                System.out.println("Total cost : "+food.getCost());
                System.out.println("List : \n"+food.description());
            }
            else if(choice == 3)
            {
                Food food = new VeggiPizza();
                food = new FrenchFries(food);
                food = new Coke(food);

                System.out.println("Total cost : "+food.getCost());
                System.out.println("List : \n"+food.description());
            }
            else if(choice == 4)
            {
                Food food = new VeggiPizza();
                food = new OnionRings(food);
                food = new Coffee(food);

                System.out.println("Total cost : "+food.getCost());
                System.out.println("List : \n"+food.description());
            }
            else if(choice == 5)
            {
                Food food = new BeefPizza();

                System.out.println("Total cost : "+food.getCost());
                System.out.println("List : \n"+food.description());
            }
        }
    }
}
