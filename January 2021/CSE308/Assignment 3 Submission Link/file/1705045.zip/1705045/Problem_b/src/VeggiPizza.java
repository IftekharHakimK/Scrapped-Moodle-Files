public class VeggiPizza implements Food {
    @Override
    public String description() {
        return "Veggi Pizza : Tk. 500 \n";
    }

    @Override
    public int getCost() {
        return 500;
    }
}
