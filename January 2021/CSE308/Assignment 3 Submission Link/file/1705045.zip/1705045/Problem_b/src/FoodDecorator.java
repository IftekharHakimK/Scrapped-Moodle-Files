public abstract class FoodDecorator implements Food {
    Food food;
}
