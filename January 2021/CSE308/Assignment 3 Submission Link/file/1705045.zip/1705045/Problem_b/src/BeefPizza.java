public class BeefPizza implements Food {
    @Override
    public String description() {
        return "Beef Pizza : Tk. 600 \n";
    }

    @Override
    public int getCost() {
        return 600;
    }
}
