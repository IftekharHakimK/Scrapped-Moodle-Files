public class OnionRings extends Appetizer {

    public OnionRings(Food food)
    {
        this.food=food;
    }

    @Override
    public String description() {
        return food.description()+"Onion Rings : Tk. 100 \n";
    }

    @Override
    public int getCost() {
        return food.getCost()+100;
    }
}
