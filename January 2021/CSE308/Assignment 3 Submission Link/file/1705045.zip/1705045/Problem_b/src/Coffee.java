public class Coffee extends Drink {

    public Coffee(Food food)
    {
        this.food=food;
    }

    @Override
    public String description() {
        return food.description()+"Coffee : Tk. 50\n";
    }

    @Override
    public int getCost() {
        return food.getCost()+50;
    }
}
