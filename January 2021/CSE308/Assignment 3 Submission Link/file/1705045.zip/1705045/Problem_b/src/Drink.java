public abstract class Drink extends FoodDecorator {
}
