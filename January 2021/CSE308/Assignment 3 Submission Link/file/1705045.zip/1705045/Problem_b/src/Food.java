public interface Food {
    String description();
    int getCost();
}
