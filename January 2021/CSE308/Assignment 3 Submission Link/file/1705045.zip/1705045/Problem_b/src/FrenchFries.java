public class FrenchFries extends Appetizer {

    public FrenchFries(Food food)
    {
        this.food=food;
    }

    @Override
    public String description() {
        return food.description()+"French Fries : Tk. 100 \n";
    }

    @Override
    public int getCost() {
        return 100+food.getCost();
    }
}
