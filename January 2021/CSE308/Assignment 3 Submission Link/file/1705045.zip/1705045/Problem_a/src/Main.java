import java.io.File;
import java.io.IOException;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) throws IOException {

        //Assumed to be client
	    String fileName, fileType;
        Scanner scanner=new Scanner(System.in);
        FileAdapter fileAdapter = new FileAdapter();

	    while(true)
        {
            fileName=scanner.next();

            if(fileName.equalsIgnoreCase("Stop"))
                break;
            fileType=scanner.next();
            File file = new File(fileName);

            System.out.println(fileAdapter.getSum(file, fileType));
        }

    }
}
