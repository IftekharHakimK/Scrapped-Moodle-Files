import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class FileAdapter {

    int getSum(File file, String fileType) throws IOException {
        CalculateSum calculateSum = new CalculateSum();
        if(fileType.equalsIgnoreCase("Int"))
        {
            return calculateSum.calculate(file);
        }
        else if(fileType.equalsIgnoreCase("Char"))
        {
            File temp = new File("temporary_file.txt");
            FileWriter fileWriter = new FileWriter(temp);
            Scanner scanner = new Scanner(file);
            while (scanner.hasNext())
            {
                int num = scanner.next().charAt(0);
                fileWriter.write(String.valueOf(num));
                fileWriter.write(" ");
            }

            fileWriter.close();
            scanner.close();

            int ans = calculateSum.calculate(temp);
            temp.delete();
            return ans;
        }
        else
        {
            System.out.println("Wrong type given");
            return 0;
        }
    }

}
