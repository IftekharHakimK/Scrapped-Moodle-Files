import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class CalculateSum {
    int calculate(File file) throws FileNotFoundException {
        Scanner scanner = new Scanner(file);
        int sum=0;
        while (scanner.hasNextInt())
        {
            sum+=scanner.nextInt();
        }
        scanner.close();
        return sum;
    }
}
