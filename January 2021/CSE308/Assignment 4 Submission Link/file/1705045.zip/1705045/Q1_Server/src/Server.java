import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Server {
    static ArrayList<Stock> allStocks;

    public static void main(String[] args) throws IOException {

        //Server reading from file
        File file = new File("input.txt");
        Scanner scanner = new Scanner(file);
        allStocks = new ArrayList<Stock>();
        while (scanner.hasNext())
        {
            String name = scanner.next();
            int count = scanner.nextInt();
            double price = scanner.nextDouble();
            allStocks.add(new Stock(name,count,price));
        }

        //Separate thread so that users may connect
        Connection_Acknowledger connection_acknowledger = new Connection_Acknowledger();
        Thread thread1 = new Thread(connection_acknowledger);
        thread1.start();

        //Another thread to get trigger input from console
        scanner = new Scanner(System.in);
        while(true)
        {
            String type = scanner.next();
            if(type.equals("I"))
            {
                String name = scanner.next();
                double price = scanner.nextDouble();
                for(Stock stock:allStocks)
                {
                    if(stock.getName().equals(name))
                    {
                        stock.increasePrice(price);
                    }
                }
            }
            else if(type.equals("D"))
            {
                String name = scanner.next();
                double price = scanner.nextDouble();
                for(Stock stock:allStocks)
                {
                    if(stock.getName().equals(name))
                    {
                        stock.decreasePrice(price);
                    }
                }
            }
            else if(type.equals("C"))
            {
                String name = scanner.next();
                int count = scanner.nextInt();
                for(Stock stock:allStocks)
                {
                    if(stock.getName().equals(name))
                    {
                        stock.changeCount(count);
                    }
                }
            }
            else if(type.equals("stop"))
            {
                System.exit(0);
            }
        }

    }
}
