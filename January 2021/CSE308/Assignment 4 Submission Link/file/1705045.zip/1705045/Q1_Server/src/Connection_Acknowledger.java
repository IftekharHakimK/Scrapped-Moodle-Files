import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class Connection_Acknowledger implements  Runnable {
    private ServerSocket serverSocket;
    Connection_Acknowledger() throws IOException {
        serverSocket = new ServerSocket(555);
    }

    //This thread will keep running so that users may connect
    @Override
    public void run() {
        int id=1;
        while(true) {
            Socket connectionSocket = null;
            try {
                connectionSocket = serverSocket.accept();
                ClientThread ct = new ClientThread(connectionSocket, id);
                Thread t = new Thread(ct);
                t.start();
                System.out.println("New client connected. Assigned ID: "+id);
                id++;
            } catch (IOException e) {
                System.out.println("Exception in Connection_Acknowledger");
                return;
            }
        }
    }
}
