import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

public class ClientThread implements Runnable {
    private Socket socket;
    private int assignedID;

    ClientThread(Socket socket,int id)
    {
        this.socket=socket;
        this.assignedID=id;
    }

    @Override
    public void run() {
        try {

            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(),true);

            printWriter.println("Assigned ID: "+assignedID);
            printWriter.flush();
            //Sending initial list
            printWriter.println(Server.allStocks.size());
            printWriter.flush();
            for(Stock stock:Server.allStocks)
            {
                printWriter.println(stock.getName());
                printWriter.println(stock.getCount());
                printWriter.println(stock.getPrice());
                printWriter.flush();
            }



            //Reading subscribe-unsubscribe
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            while (true) {
                String data;
                data = bufferedReader.readLine();
                String[] strings;
                strings = data.split(" ");
                if (strings[0].equals("S")) {
                    for (Stock stock : Server.allStocks) {
                        if (stock.getName().equals(strings[1])) {
                            stock.subscribe(socket);
                        }

                    }
                }
                else if (strings[0].equals("U")) {
                    for (Stock stock : Server.allStocks) {
                        if (stock.getName().equals(strings[1]))
                            stock.unsubscribe(socket);
                    }
                }

            }

        }
        catch (IOException e)
        {
            return;
        }
    }
}
