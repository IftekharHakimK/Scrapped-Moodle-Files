import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.net.*;

public class Stock {
    private String name;
    private int count;
    private double price;
    ArrayList<Socket> subscribers;
    Stock(String name, int count, double price)
    {
        this.name=name;
        this.count=count;
        this.price=price;
        subscribers=new ArrayList<Socket>();
    }
    String getName()
    {
        return name;
    }
    int getCount()
    {
        return count;
    }
    double getPrice()
    {
        return price;
    }
    void decreasePrice(double price) throws IOException {
        this.price=price;
        for(Socket socket:subscribers)
        {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(),true);
            printWriter.println("Price of "+name+" decreased to "+price);
            printWriter.flush();
        }
        return;
    }
    void increasePrice(double price) throws IOException {
        this.price=price;
        for(Socket socket:subscribers)
        {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream(),true);
            printWriter.println("Price of "+name+" increased to "+price);
            printWriter.flush();
        }
        return;
    }
    void changeCount(int count) throws IOException {
        this.count=count;
        for(Socket socket:subscribers)
        {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println("Count of "+name+" changed to "+count);
            printWriter.flush();
        }
        return;
    }
    void subscribe(Socket socket) throws IOException {
        if(subscribers.contains(socket)==false)
        {
            subscribers.add(socket);
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println("Subsribed to "+name);
            printWriter.flush();
        }
        else
        {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println("Already subsribed to "+name);
            printWriter.flush();
        }
        return;
    }
    void unsubscribe(Socket socket) throws IOException {
        if(subscribers.contains(socket)==true)
        {
            subscribers.remove(socket);
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println("Unsubsribed from "+name);
            printWriter.flush();
        }
        else
        {
            PrintWriter printWriter = new PrintWriter(socket.getOutputStream());
            printWriter.println("Not subsribed to "+name);
            printWriter.flush();
        }
        return;
    }

}
