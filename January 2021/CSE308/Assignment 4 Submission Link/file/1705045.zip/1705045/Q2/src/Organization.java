public interface Organization {
    void requestService(String service);
    void receiveService(String service);
    void takeRequest();
    void provideService();
}
