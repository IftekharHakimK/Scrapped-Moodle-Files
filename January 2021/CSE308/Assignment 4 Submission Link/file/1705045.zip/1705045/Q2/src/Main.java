import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Mediator mediator = new Mediator();
        Organization jwsa = new JWSA(mediator);
        Organization jpdc = new JPDC(mediator);
        Organization jrta = new JRTA(mediator);
        Organization jtrc = new JTRC(mediator);
        mediator.setJWSA(jwsa);
        mediator.setJPDC(jpdc);
        mediator.setJRTA(jrta);
        mediator.setJTRC(jtrc);
        System.out.println("All initiated");
        Scanner scanner = new Scanner(System.in);
        while (scanner.hasNext())
        {
            String a,b;
            a=scanner.next();
            b=scanner.next();
            if(b.equalsIgnoreCase("SERVE"))
            {
                if(a.equalsIgnoreCase("JWSA")) jwsa.provideService();
                else if(a.equalsIgnoreCase("JPDC")) jpdc.provideService();
                else if(a.equalsIgnoreCase("JRTA")) jrta.provideService();
                else if(a.equalsIgnoreCase("JTRC")) jtrc.provideService();
            }
            else
            {
                if(a.equalsIgnoreCase("JWSA")) jwsa.requestService(b);
                else if(a.equalsIgnoreCase("JPDC")) jpdc.requestService(b);
                else if(a.equalsIgnoreCase("JRTA")) jrta.requestService(b);
                else if(a.equalsIgnoreCase("JTRC")) jtrc.requestService(b);
            }
        }
    }
}
