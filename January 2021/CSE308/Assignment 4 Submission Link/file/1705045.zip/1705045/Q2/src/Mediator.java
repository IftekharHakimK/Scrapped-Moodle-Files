import java.util.LinkedList;
import java.util.Queue;

public class Mediator {
    private Organization jwsa, jpdc, jrta, jtrc;
    private Queue<Organization> waterRequests, powerRequests, transportRequests, telecomRequests;

    Mediator()
    {
        waterRequests=new LinkedList<>();
        powerRequests=new LinkedList<>();
        transportRequests=new LinkedList<>();
        telecomRequests=new LinkedList<>();
    }
    public void setJWSA(Organization jwsa)
    {
        this.jwsa = jwsa;
    }
    public void setJPDC(Organization jpdc)
    {
        this.jpdc=jpdc;
    }
    public void setJRTA(Organization jrta) {
        this.jrta = jrta;
    }

    public void setJTRC(Organization jtrc) {
        this.jtrc = jtrc;
    }

    void request(Organization organization, String service)
    {
        if(service.equalsIgnoreCase("water"))
        {
            waterRequests.offer(organization);
            jwsa.takeRequest();
        }
        else if(service.equalsIgnoreCase("power"))
        {
            powerRequests.offer(organization);
            jpdc.takeRequest();
        }
        else if(service.equalsIgnoreCase("transport"))
        {
            transportRequests.offer(organization);
            jrta.takeRequest();
        }
        else if(service.equalsIgnoreCase("telecom"))
        {
            telecomRequests.offer(organization);
            jtrc.takeRequest();
        }
    }

    void serve(String service)
    {
        Organization receiver = null;
        if(service.equalsIgnoreCase("water"))  receiver = waterRequests.poll();
        else if(service.equalsIgnoreCase("power")) receiver = powerRequests.poll();
        else if(service.equalsIgnoreCase("transport")) receiver = transportRequests.poll();
        else if(service.equalsIgnoreCase("telecom")) receiver = telecomRequests.poll();

        receiver.receiveService(service);
    }
}
