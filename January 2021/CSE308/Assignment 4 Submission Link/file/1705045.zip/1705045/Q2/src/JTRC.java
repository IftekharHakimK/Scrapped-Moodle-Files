public class JTRC implements Organization {
    Mediator mediator;
    int requestLeft;
    JTRC(Mediator mediator)
    {
        this.mediator=mediator;
        requestLeft=0;
    }
    @Override
    public void provideService() {
        if(requestLeft>0) {
            System.out.println("Service provided by JTRC");
            mediator.serve("TELECOM");
            requestLeft-=1;
        }
        else
            System.out.println("No service needed from JTRC");
    }

    @Override
    public void takeRequest() {
        requestLeft+=1;
        System.out.println("New request received by JTRC");
    }

    @Override
    public void receiveService(String service) {
        System.out.println(service+" service received by JTRC");
    }

    @Override
    public void requestService(String service) {
        System.out.println(service+" is requested by JTRC");
        mediator.request(this,service);
    }
}
