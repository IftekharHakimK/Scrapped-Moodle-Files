public class JPDC implements Organization {
    Mediator mediator;
    int requestLeft;
    JPDC(Mediator mediator)
    {
        this.mediator=mediator;
        requestLeft=0;
    }
    @Override
    public void provideService() {
        if(requestLeft>0) {
            System.out.println("Service provided by JPDC");
            mediator.serve("POWER");
            requestLeft-=1;
        }
        else
            System.out.println("No service needed from JPDC");
    }

    @Override
    public void takeRequest() {
        requestLeft+=1;
        System.out.println("New request received by JPDC");
    }

    @Override
    public void receiveService(String service) {
        System.out.println(service+" service received by JPDC");
    }

    @Override
    public void requestService(String service) {
        System.out.println(service+" is requested by JPDC");
        mediator.request(this,service);
    }
}
