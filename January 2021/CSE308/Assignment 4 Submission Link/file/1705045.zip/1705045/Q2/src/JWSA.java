public class JWSA implements Organization {
    Mediator mediator;
    int requestLeft;
    JWSA(Mediator mediator)
    {
        this.mediator=mediator;
        requestLeft=0;
    }

    @Override
    public void provideService() {
        if(requestLeft>0) {
            System.out.println("Service provided by JWSA");
            mediator.serve("WATER");
            requestLeft-=1;
        }
        else
            System.out.println("No service needed from JWSA");
    }

    @Override
    public void takeRequest() {
        System.out.println("New request received by JWSA");
        requestLeft+=1;
    }

    @Override
    public void receiveService(String service) {
        System.out.println(service+" service received by JWSA");
    }

    @Override
    public void requestService(String service) {
        System.out.println(service+" is requested by JWSA");
        mediator.request(this,service);
    }
}
