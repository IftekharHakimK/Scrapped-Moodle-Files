import java.io.*;
import java.net.Socket;
import java.util.Scanner;

public class Client {

    public static void main(String[] args) throws IOException {


        Socket clientSocket = new Socket("localhost", 555);
        PrintWriter printWriter = new PrintWriter(clientSocket.getOutputStream(),true);
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));


        System.out.println(bufferedReader.readLine());

        int n= Integer.parseInt(bufferedReader.readLine());
        for(int i=0;i<n;i++)
        {
            System.out.println("Stock: "+bufferedReader.readLine()+" "+bufferedReader.readLine()+" "+bufferedReader.readLine());
        }

        Thread notify_thread = new Thread(){
            public void run() {
                while(true)
                {
                    try {
                        String data;
                        data = bufferedReader.readLine();
                        System.out.println("Notification: " + data);
                    }
                    catch (Exception e)
                    {
                        return;
                    }
                }
            }
        };
        Thread console_input = new Thread(){
            public void run()
            {
                while(true)
                {
                    Scanner scanner1 = new Scanner(System.in);
                    String input = scanner1.nextLine();
                    printWriter.println(input);
                    printWriter.flush();
                    if(input.equals("stop"))
                    {
                        notify_thread.interrupt();
                        this.interrupt();
                        System.exit(0);
                    }
                }
            }
        };
        console_input.start();
        notify_thread.start();
    }
}
