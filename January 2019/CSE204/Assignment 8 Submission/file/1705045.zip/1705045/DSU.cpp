#include<bits/stdc++.h>
using namespace std;

struct ds
{
    int *pOrRank;
    int mx;
    ds(int mx)
    {
        this->mx=mx;
        pOrRank=new int[mx+1];
        for(int i=0; i<=mx; i++)
            pOrRank[i]=mx+5;
    }
    void Make_Set(int x)
    {
        pOrRank[x]=-1;
    }
    //rank negative,parent positive
    int Find_Set(int x)
    {
        if(pOrRank[x]>mx) return -1;
        if(pOrRank[x]<0)
            return x;
        else
            return pOrRank[x]=Find_Set(pOrRank[x]);
    }

    int Union(int x,int y)
    {
        x=Find_Set(x);
        y=Find_Set(y);
        if(x==y)
            return x;
        if(-pOrRank[x]>-pOrRank[y])
        {
            pOrRank[y]=x;
            return x;
        }

        else if(-pOrRank[x]<-pOrRank[y])
        {
            pOrRank[x]=y;
            return y;
        }
        else
        {
            pOrRank[x]=y;
            pOrRank[y]--;
            return y;
        }
    }
    void print(int u)
    {
        for(int i=0;i<=mx;i++)
        {
            if(Find_Set(i)==u)
            {
                cout<<i<<' ';
            }
        }
        cout<<endl;
    }


};

main()
{
    int mx;
    cout<<"Input max number"<<endl;
    cin>>mx;
    ds D(mx);
    int y,ch,x;
    while(true)
    {
        cout<<"1. Make_Set"<<endl;
        cout<<"2. Find_Set"<<endl;
        cout<<"3. Union"<<endl;
        cout<<"4. Print"<<endl;
        cin>>ch;
        if(ch==1)
        {
            cout<<"Element=";
            cin>>x;
            D.Make_Set(x);
            cout<<"New set created with id="<<x<<endl;
        }
        else if(ch==2)
        {
            cout<<"Element=";
            cin>>x;
            int p=D.Find_Set(x);
            if(p==-1) cout<<"No included"<<endl;
            else cout<<"Set ID="<<p<<endl;
        }
        else if(ch==3)
        {
            cout<<"Enter two elements"<<endl;
            cin>>x>>y;
            int p=D.Union(x,y);
            cout<<"Sets are united,having a common ID="<<p<<endl;
        }
        else if(ch==4)
        {
            cout<<"Enter a set ID"<<endl;
            cin>>x;
            D.print(x);
        }
        else
        {
            break;
        }
    }

}
