#include<bits/stdc++.h>
using namespace std;
struct act
{
    int s,f;
    act() {}
    act(int s,int f)
    {
        this->s=s;
        this->f=f;
    }
};
void mergeIt(act *a,int s,int mid,int f)
{
    int n1=mid-s+1,n2=f-mid;
    act L[n1+1],R[n2+1];
    for(int i=0; i<n1; i++)
    {
        L[i]=a[s+i];
    }
    for(int j=0; j<n2; j++)
    {
        R[j]=a[mid+1+j];
    }
    L[n1].f=INT_MAX;
    R[n2].f=INT_MAX;
    int p=0,q=0;
    for(int i=s; i<=f; i++)
    {
        if(L[p].f<R[q].f)
        {
            a[i]=L[p++];
        }
        else
        {
            a[i]=R[q++];
        }
    }
    return;
}
void merge_sort(act *a,int i,int j)
{
    if(i>=j)
        return;

    merge_sort(a,i,(i+j)/2);
    merge_sort(a,(i+j)/2+1,j);
    mergeIt(a,i,(i+j)/2,j);
    return;
}
int Find(act *A,int n,int p)
{
    int last=-1;
    int c=0;
    for(int i=0; i<n; i++)
    {
        if(A[i].s>=last)
        {
            c++;
            last=A[i].f;
            if(p)
            {
                cout<<"Activity "<<c<<" : "<<A[i].s<<' '<<A[i].f<<endl;
            }
        }
    }
    return c;
}
int possible[100];
void Build(act*A,int idx,int n)
{
    possible[idx]=1;
    for(int i=idx+1; i<n; i++)
    {
        if(A[i].s>=A[idx].f)
        {
            possible[idx]=possible[i]+1;
            return;
        }
    }
}
act ans[100];
int k,way;
void run(act *A,int n,int idx,int last,int current,int mx)
{
    // cout<<idx<<' '<<last<<' '<<current<<' '<<mx<<endl;
    if(current==mx)
    {
        way++;
        cout<<"Way "<<way<<endl;
        for(int i=0; i<mx; i++)
        {
            cout<<ans[i].s<<' '<<ans[i].f<<endl;
        }
        cout<<endl;
        return;
    }

    for(int i=idx; i<n; i++)
    {
        if(A[i].s>=last&&current+possible[i]==mx)
        {
            // cout<<current<<' '<<"Took "<<A[i].s<<' '<<A[i].f<<' '<<endl;
            ans[current]=A[i];
            run(A,n,i+1,A[i].f,current+1,mx);
        }
    }
}



main()
{
    srand(time(0));

    cout<<"1.Self Input"<<endl;
    cout<<"2.Random"<<endl;
    int ch;
    cin>>ch;
    int n;
    act* A;
    if(ch==2)
    {
        n=20;
        A=new act[n];
        cout<<"N= "<<n<<endl;
        for(int i=0; i<n; i++)
        {
            int s=rand()%100;
            int sz=rand()%100;
            cout<<s<<' '<<s+sz+1<<endl;
            A[i]=act(s,s+sz+1);
        }
    }
    else
    {
        cout<<"N=";
        cin>>n;
        A=new act[n];
        cout<<"Start and End point(half open)"<<endl;
        for(int i=0; i<n; i++)
        {
            int s,f;
            cin>>s>>f;
            A[i]=act(s,f);
        }
    }
    merge_sort(A,0,n-1);

    cout<<"1. All 2.One"<<endl;
    cin>>ch;
    if(ch==1)
    {
        int mx=Find(A,n,0);
        cout<<"Maximum possible= "<<mx<<endl;
        for(int i=n-1; i>=0; i--)
            Build(A,i,n);

        run(A,n,0,-1,0,mx);
    }
    else
    {
        int mx=Find(A,n,1);
        cout<<"Maximum possible= "<<mx<<endl;

    }

}
