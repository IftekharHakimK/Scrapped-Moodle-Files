#include<bits/stdc++.h>
using namespace std;
main()
{
    string a,b;
    cin>>a;
    cin>>b;
    int n=a.size();
    int m=b.size();
    int dp[n+1][m+1];
    for(int i=0; i<=n; i++)
        dp[i][m]=0;
    for(int i=0; i<=m; i++)
        dp[n][i]=0;

    for(int i=n-1; i>=0; i--)
    {
        for(int j=m-1; j>=0; j--)
        {
            if(a[i]==b[j])
            {
                dp[i][j]=1+dp[i+1][j+1];
            }
            else
            {
                dp[i][j]=max(dp[i+1][j],dp[i][j+1]);
            }
            //cout<<dp[i][j]<<' ';

        }
        //cout<<endl;
    }
    int out=dp[n][m];
    cout<<"Ans= "<<dp[0][0]<<endl;
    int i=0,j=0;
    string ans;
    while(i!=n&&j!=m)
    {
        if(a[i]==b[j])
        {
            ans+=a[i];
            i++;
            j++;
        }
        else
        {
            if(dp[i+1][j]>dp[i][j+1])
            {
                i++;
            }
            else
            {
                j++;
            }
        }
    }
    cout<<ans;
}
