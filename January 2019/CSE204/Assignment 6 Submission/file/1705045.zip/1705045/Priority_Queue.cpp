#include<bits/stdc++.h>
using namespace std;
class pq
{
    int *a;
    int cap,sz;
    public:
    pq()
    {
        a=(int*)malloc(10*sizeof(int));
        cap=10;
        sz=0;
    }
    void Insert(int key)
    {
        if(sz+1>cap)
        {
            a=(int*)realloc(a,(cap+10)*sizeof(int));
            cap+=10;
        }
        a[sz]=key;
        heapifyUp(sz);
        sz++;
    }
    int FindMax()
    {
        if(sz>0)return a[0];
        cout<<"NO element in priority queue...";
        return -9999999;
    }
    int ExtractMax()
    {
        if(sz>0){
        int ret=a[0];
        a[0]=a[sz-1];
        sz--;
        heapifyDown(0);
        return ret;
        }
        cout<<"NO element in priority queue...";
        return -9999999;
    }
    void IncreaseKey(int i,int key)
    {
        if(i<sz)
        {
            if(a[i]<key)
            {
                a[i]=key;
                heapifyUp(i);
            }
        }
    }
    void DecreaseKey(int i,int key)
    {
        if(i<sz)
        {
            if(a[i]>key)
            {
                a[i]=key;
                heapifyDown(i);
            }
        }
    }
    void print()
    {
        cout<<"Array: ";
        for(int i=0;i<sz;i++)
        {
            cout<<a[i]<<' ';
        }
        cout<<endl;

        int element_in_level=1;
        for(int i=0;i<sz;i++)
        {
            cout<<a[i]<<' ';
            if(i+1==element_in_level||i+1==sz)
            {
                cout<<endl;
                element_in_level=element_in_level+element_in_level*2;
            }
        }

    }
    inline int parent(int idx)
    {
        return (idx%2==0)?idx/2-1:idx/2;
    }
    void swp(int *x,int* y)
    {
        int t=*x;
        *x=*y;
        *y=t;
    }
    void heapifyUp(int idx)
    {
        if(idx==0||a[idx]<=a[parent(idx)]) return;
        swp(&a[idx],&a[parent(idx)]);
        heapifyUp(parent(idx));
    }
    void heapifyDown(int idx)
    {
        int large=idx;
        if(2*idx+1<sz&&a[2*idx+1]>a[large]) large=2*idx+1;
        if(2*idx+2<sz&&a[2*idx+2]>a[large]) large=2*idx+2;
        if(large!=idx)
        {
            swp(&a[idx],&a[large]);
            heapifyDown(large);
        }
    }
};
int main()
{
    pq q;
    int ch;
    while(true)
    {
        cout<<"1: Insert \t 2: FindMax"<<endl;
        cout<<"3: ExtractMax \t 4: IncreaseKey"<<endl;
        cout<<"5: DecreaseKey \t 6: Print "<<endl;
        cout<<"7: Exit"<<endl;
        cin>>ch;
        if(ch==1)
        {
            cout<<"Element to insert: ";
            int x;
            cin>>x;
            q.Insert(x);
        }
        else if(ch==2)
        {
            cout<<q.FindMax()<<endl;
        }
        else if(ch==3)
        {
            cout<<q.ExtractMax()<<endl;
        }
        else if(ch==4)
        {
            int idx,key;
            cout<<"Enter index and key to increase: ";
            cin>>idx>>key;
            q.IncreaseKey(idx,key);
        }
        else if(ch==5)
        {
            int idx,key;
            cout<<"Enter index and key to decrease: ";
            cin>>idx>>key;
            q.DecreaseKey(idx,key);
        }
        else if(ch==6)
        {
            q.print();
        }
        else
        {
            break;
        }
    }
}
