#include <bits/stdc++.h>
using namespace std;
int *a;
int n;
void mergeIt(int *a,int s,int mid,int f)
{
    int n1=mid-s+1,n2=f-mid;
    int L[n1+1],R[n2+1];
    for(int i=0; i<n1; i++)
    {
        L[i]=a[s+i];
    }
    for(int j=0;j<n2;j++)
    {
        R[j]=a[mid+1+j];
    }
    L[n1]=INT_MAX;
    R[n2]=INT_MAX;
    int p=0,q=0;
    for(int i=s; i<=f; i++)
    {
        if(L[p]<R[q])
        {
            a[i]=L[p++];
        }
        else
        {
            a[i]=R[q++];
        }
    }
    return;
}
void merge_sort(int *a,int i,int j)
{
    if(i>=j)
        return;

    merge_sort(a,i,(i+j)/2);
    merge_sort(a,(i+j)/2+1,j);
    mergeIt(a,i,(i+j)/2,j);
    return;
}

void swap(int *x,int *y)
{
    *y=(*x+*y)-(*x=*y);
}

int pivoting(int *a,int s,int f)
{
    int pivot=a[f];
    int where=s;
    for(int i=s; i<f; i++)
    {
        if(a[i]<=pivot)
        {
            swap(&a[i],&a[where]);
            where++;
        }
    }
    swap(&a[f],&a[where]);
    return where;
}
void quick_sort(int *a,int i,int j)
{
    if(i>=j)
        return;
    int p=pivoting(a,i,j);
    quick_sort(a,i,p-1);
    quick_sort(a,p+1,j);
    return;
}



int main()
{
    int choice;
    while(1)
    {
        printf("1. Generate average case\n");
        printf("2. Generate best case(Increasing)\n");
        printf("3. Generate worst case(Decreasing)\n");
        printf("4. Apply Merge sort\n");
        printf("5. Apply Quicksort\n");
        printf("6. Print array\n");
        printf("> ");
        scanf("%d", &choice);

        srand(time(0));
        switch(choice)
        {
        case 1:
        {
            printf("Number of elements: ");
            scanf("%d", &n);
            if(a)delete[] a;
            a=new int[n];
            if(!a)
            {
                cout<<"Could not allocate"<<endl;
                return 0;
            }
            for(int i=0; i<n; i++)
            {
                a[i]=rand()%100000;
            }
            break;
        }

        case 2:
            printf("Number of elements: ");
            scanf("%d", &n);
            if(a)delete[] a;
            a=new int[n];
            if(!a)
            {
                cout<<"Could not allocate"<<endl;
                return 0;
            }
            for(int i=0;i<n;i++) a[i]=i;
            break;

        case 3:
            printf("Number of elements: ");
            scanf("%d", &n);
            if(a)delete[] a;
            a=new int[n];
            if(!a)
            {
                cout<<"Could not allocate"<<endl;
                return 0;
            }
            for(int i=0; i<n; i++)
            {
                a[i]=n-i;
            }
            break;

        case 4:
        {

            printf("Applying merge sort\n");
            auto start = chrono::high_resolution_clock::now();
            merge_sort(a,0,n-1);
            auto end = chrono::high_resolution_clock::now();
            double tm= chrono::duration_cast<chrono::nanoseconds>(end- start).count();
            printf("Time taken to finish: %0.10f ns\n",tm);
            break;
        }
        case 5:
            {
            printf("Applying quicksort\n");
            auto start = chrono::high_resolution_clock::now();
            quick_sort(a,0,n-1);
            auto end = chrono::high_resolution_clock::now();
            double tm= chrono::duration_cast<chrono::nanoseconds>(end- start).count();
            printf("Time taken to finish: %0.10f ns\n",tm);
            break;
            }

        case 6:
            printf("Array %d\n",n);
            for(int i=0; i<n; i++)
            {
                cout<<a[i]<<' ';
            }
            cout<<endl;
            break;
        }
    }
}

