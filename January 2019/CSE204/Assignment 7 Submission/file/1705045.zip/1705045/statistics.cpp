#include<bits/stdc++.h>
using namespace std;
void mergeIt(int *a,int s,int mid,int f)
{
    int n1=mid-s+1,n2=f-mid;
    int L[n1+1],R[n2+1];
    for(int i=0; i<n1; i++)
    {
        L[i]=a[s+i];
    }
    for(int j=0; j<n2; j++)
    {
        R[j]=a[mid+1+j];
    }
    L[n1]=INT_MAX;
    R[n2]=INT_MAX;
    int p=0,q=0;
    for(int i=s; i<=f; i++)
    {
        if(L[p]<R[q])
        {
            a[i]=L[p++];
        }
        else
        {
            a[i]=R[q++];
        }
    }
    return;
}
void merge_sort(int *a,int i,int j)
{
    if(i>=j)
        return;

    merge_sort(a,i,(i+j)/2);
    merge_sort(a,(i+j)/2+1,j);
    mergeIt(a,i,(i+j)/2,j);
    return;
}

void swap(int *x,int *y)
{
    *y=(*x+*y)-(*x=*y);
}

int pivoting(int *a,int s,int f)
{
    int pivot=a[f];
    int where=s;
    for(int i=s; i<f; i++)
    {
        if(a[i]<=pivot)
        {
            swap(&a[i],&a[where]);
            where++;
        }
    }
    swap(&a[f],&a[where]);
    return where;
}
void quick_sort(int *a,int i,int j)
{
    if(i>=j)
        return;
    int p=pivoting(a,i,j);
    quick_sort(a,i,p-1);
    quick_sort(a,p+1,j);
    return;
}
main()
{
    freopen("Times.txt","w",stdout);
    srand(time(0));
    int ns[]= {10,50,100,500,1000,2500,5000,10000};
    int a[10000],duplicate[10000];
    for(int n:ns)
    {
        int sample=100000/n;

        printf("N=%d\n",n);
        Increasing:
        {
            double time1=0,time2=0;
            for(int s=1; s<=sample; s++)
            {
                for(int i=0; i<n; i++)
                {
                    a[i]=i;
                    duplicate[i]=i;
                }
                auto start1 = chrono::high_resolution_clock::now();
                merge_sort(a,0,n);
                auto end1 = chrono::high_resolution_clock::now();
                double tm1= chrono::duration_cast<chrono::nanoseconds>(end1- start1).count();
                time1+=tm1;

                auto start2 = chrono::high_resolution_clock::now();
                quick_sort(duplicate,0,n);
                auto end2 = chrono::high_resolution_clock::now();
                double tm2= chrono::duration_cast<chrono::nanoseconds>(end2- start2).count();
                time2+=tm2;
            }
            time1/=sample;
            time2/=sample;
            printf("Increasing:\n");
            printf("Merge sort took: %.5f ns\n",time1);
            printf("Quick sort took: %.5f ns\n",time2);
        }



        Decreasing:
        {
            double time1=0,time2=0;
            for(int s=1; s<=sample; s++)
            {
                for(int i=0; i<n; i++)
                {
                    a[i]=n-i;
                    duplicate[i]=n-i;
                }
                auto start1 = chrono::high_resolution_clock::now();
                merge_sort(a,0,n);
                auto end1 = chrono::high_resolution_clock::now();
                double tm1= chrono::duration_cast<chrono::nanoseconds>(end1- start1).count();
                time1+=tm1;

                auto start2 = chrono::high_resolution_clock::now();
                quick_sort(duplicate,0,n);
                auto end2 = chrono::high_resolution_clock::now();
                double tm2= chrono::duration_cast<chrono::nanoseconds>(end2- start2).count();
                time2+=tm2;
            }
            time1/=sample;
            time2/=sample;
            printf("Decreasing:\n");
            printf("Merge sort took: %.5f ns\n",time1);
            printf("Quick sort took: %.5f ns\n",time2);
        }
        Random:
            {
            double time1=0,time2=0;
            for(int s=1; s<=sample; s++)
            {
                for(int i=0; i<n; i++)
                {
                    a[i]=rand()%100000;
                    duplicate[i]=a[i];
                }
                auto start1 = chrono::high_resolution_clock::now();
                merge_sort(a,0,n);
                auto end1 = chrono::high_resolution_clock::now();
                double tm1= chrono::duration_cast<chrono::nanoseconds>(end1- start1).count();
                time1+=tm1;

                auto start2 = chrono::high_resolution_clock::now();
                quick_sort(duplicate,0,n);
                auto end2 = chrono::high_resolution_clock::now();
                double tm2= chrono::duration_cast<chrono::nanoseconds>(end2- start2).count();
                time2+=tm2;
            }
            time1/=sample;
            time2/=sample;
            printf("Random:\n");
            printf("Merge sort took: %.5f ns\n",time1);
            printf("Quick sort took: %.5f ns\n\n\n",time2);
        }

    }
}
