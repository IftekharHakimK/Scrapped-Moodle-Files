#include<bits/stdc++.h>
using namespace std;
using namespace chrono;
void selSort(int *a,int n)
{
    int minimum,temp;
    for(int i=0; i<n-1; i++)
    {
        minimum=i;
        for(int j=i+1; j<n; j++)
        {
            if(a[minimum]>a[j])
            {
                minimum=j;
            }
        }
        temp=a[i];
        a[i]=a[minimum];
        a[minimum]=temp;
    }
}
void inSort(int *a,int n)
{
    int mark,j;
    for (int i=1; i<n; i++)
    {
        mark = a[i];
        j = i - 1;
        while (j >= 0 && a[j] > mark)
        {
            a[j + 1] = a[j];
            j = j - 1;
        }
        a[j + 1] = mark;
    }
}

double ask(int choice,int *a,int n)
{
    if(choice==1)
    {
        auto start1 = high_resolution_clock::now();
        selSort(a,n);
        auto finish1 =high_resolution_clock::now();
        double time1=duration_cast<nanoseconds>(finish1- start1).count();
        return time1;
    }
    else
    {
        auto start1 = high_resolution_clock::now();
        inSort(a,n);
        auto finish1 =high_resolution_clock::now();
        double time1=duration_cast<nanoseconds>(finish1- start1).count();
        return time1;
    }

}

main()
{
    srand(time(0));
    int ns[8]= {10,100,200,500,1000,2000,5000,10000};
    for(auto n:ns)
    {
        int a[n],b[n];
        double total1=0,total2=0;
        double best_sel=0;
        double worst_sel=0;
        double best_in=0;
        double worst_in=0;
        int num_samples=400000/n;
        for(int samp=1; samp<=num_samples; samp++)
        {
            for(int i=0; i<n; i++)
            {
                a[i]=rand()%100000;
                b[i]=a[i];
            }

            total1+=ask(1,a,n);
            total2+=ask(2,b,n);

            best_sel+=ask(1,a,n);
            best_in+=ask(2,a,n);


            for(int i=0;i<n;i++)
            {
                b[i]=a[n-1-i];
            }
            worst_sel+=ask(1,b,n);


            for(int i=0;i<n;i++)
            {
                b[i]=a[n-1-i];
            }
            worst_in+=ask(2,b,n);

        }

        cout<<setprecision(10)<<"n="<<n<<" Average(SS)="<<total1/num_samples<<" Average(IS)="<<total2/num_samples<<" Best(SS)="<<best_sel/num_samples<<" Best(IS)="<<best_in/num_samples<<" Worst(SS)="<<worst_sel/num_samples<<" Worst(IS)="<<worst_in/num_samples<<endl;
    }
}

