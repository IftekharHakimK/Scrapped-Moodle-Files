#include<bits/stdc++.h>
using namespace std;
using namespace chrono;
char a[65];
void build()
{
    int i=0;
    for(char c='0'; c<='9'; c++)
        a[i++]=c;
    for(char c='a'; c<='z'; c++)
        a[i++]=c;
    for(char c='A'; c<='Z'; c++)
        a[i++]=c;
    //cout<<i<<endl;
}



int countt[62];
string s;
int t=1;
void power(int idx,int taken)
{
    if(idx==62)
    {
        //cout<<t++<<' '<<s<<endl;
        return;
    }

    if(taken<countt[idx])
    {
        s.push_back(a[idx]);
        power(idx,taken+1);
        s.pop_back();
    }
    power(idx+1,0);

}

main()
{
    build();
    for(int n=5; n<=30; n++)
    {
        double total=0;
        int num_samp;
        if(n<=15) num_samp=500;
        else num_samp=3;
        for(int samp=1; samp<=num_samp; samp++)
        {
            t=1;
            memset(countt,0,sizeof countt);
            srand(time(0));
            int p;
            char test[n+1];
            for(int i=0; i<n; i++)
            {
                p=rand()%62;
                test[i]=a[p];
                countt[p]++;
            }
            test[n]=0;
            //cout<<test<<endl<<endl;
            auto start1 = high_resolution_clock::now();
            power(0,0);
            auto finish1 =high_resolution_clock::now();
            double time1=duration_cast<nanoseconds>(finish1- start1).count();
            total+=time1;
        }
        cout<<setprecision(7)<<n<<' '<<total/num_samp<<endl;
    }
}
