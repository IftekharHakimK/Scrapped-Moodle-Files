import numpy as np
import matplotlib as mpl
from matplotlib import pyplot as plt

def trapezoidal(fx,gap,i):
    return gap*(fx[i]+fx[i+1])/2
def onethree(fx,gap,i):
    return gap*(fx[i]+4*fx[i+1]+fx[i+2])/6
def threeeight(fx,gap,i):
    return gap*(fx[i]+3*fx[i+1]+3*fx[i+2]+fx[i+3])/8


if __name__=='__main__':
    file1=open('input.txt','r')
    n =int(file1.readline())
    
    x=[]
    fx=[]
    for line in file1:
        entries = list(map(float, line.split()))
        x.append(entries[0])
        fx.append(entries[1])
    
    first=0 #trapezoidal
    second=0 #1/3
    third=0 #3/8
    
    
    start=0
    ans=0
    plt.figure(figsize=(30,18))
    plt.grid(color='grey',linewidth=0.8)
    plt.xlabel("X values")
    plt.ylabel("Function Values")
    
    blue=0
    green=0
    red=0
    
    while start<=n-2:
        current=x[start+1]-x[start]
        j=start
        size=0
        while j<=n-2:
            now=x[j+1]-x[j]
            if abs(now-current)>1E-6:
                break
            else:
                size+=1
                j+=1
        
        
        while size!=0:
            if size>=3:
                if size-3!=1:
                    ans+=threeeight(fx,3*current,start)
                    third+=3
                    size-=3
                    
                    x_list=[]
                    y_list=[]
                    for p in range(start,start+4):
                        x_list.append(x[p])
                        y_list.append(fx[p])
                    start+=3
                    plt.fill_between(np.array(x_list),y1=np.array(y_list),color='red',label='3/8 rule' if red==0 else "")
                    red=1
                    
                else:
                    ans+=onethree(fx,2*current,start)
                    second+=2
                    size-=2
                    
                    x_list=[]
                    y_list=[]
                    for p in range(start,start+3):
                        x_list.append(x[p])
                        y_list.append(fx[p])
                    start+=2
                    plt.fill_between(np.array(x_list),y1=np.array(y_list),color='blue',label='1/3 rule' if blue==0 else "")
                    blue=1
                    
            elif size==2:
                ans+=onethree(fx,2*current,start)
                second+=2
                size-=2
                
                x_list=[]
                y_list=[]
                for p in range(start,start+3):
                    x_list.append(x[p])
                    y_list.append(fx[p])
                start+=2
                plt.fill_between(np.array(x_list),y1=np.array(y_list),color='blue',label='1/3 rule' if blue==0 else "")
                blue=1
                    
            else:
                ans+=trapezoidal(fx,current,start)
                first+=1
                size-=1
                x_list=[]
                y_list=[]
                for p in range(start,start+2):
                    x_list.append(x[p])
                    y_list.append(fx[p])
                start+=1
                plt.fill_between(np.array(x_list),y1=np.array(y_list),color='green',label='Trapezoidal' if green==0 else "")
                green=1
    plt.title("Integration")
    plt.scatter(np.array(x),np.array(fx),s=10,label='Points',color='black')  
    plt.legend(loc='best')
    print("Trapezoidal rule: "+str(first)+" intervals")
    print("1/3 rule: "+str(second)+" intervals")
    print("3/8 rule: "+str(third)+" intervals")
    print("Integral value: "+str(ans))
    file1.close()
    plt.show()
    
                    
                        
                    
                
                
                
            
            
            
            
            
        
        
        
        
        
            
        
        
        
    