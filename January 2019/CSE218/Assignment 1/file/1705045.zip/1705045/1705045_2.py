import math
import numpy as np
from matplotlib import pyplot as plt
import matplotlib as mpl
from matplotlib.ticker import (AutoMinorLocator,MultipleLocator)

def f(x):
    return ((x/(1-x))*math.sqrt(6/(2+x)))-0.05


def graphicalMethod():
    y=[]
    x=-0.1
    dx=[]
    while x<=0.1:
        dx.append(x)
        temp=f(x)
        y.append(temp)
        x+=0.0001
        
    dx=np.array(dx)
    y=np.array(y)
    
    fig,ax=plt.subplots(figsize=(100,80))
    ax.set_xlim(-0.1,0.1)
    ax.set_ylim(-0.1,0.2)
    ax.xaxis.set_major_locator(MultipleLocator(0.01))
    ax.yaxis.set_major_locator(MultipleLocator(0.01))
    ax.xaxis.set_minor_locator(MultipleLocator(0.001))
    ax.yaxis.set_minor_locator(MultipleLocator(0.001))
    ax.grid(which='major',color='red',linestyle='-')
    ax.grid(which='minor',color='black',linestyle=':')
    plt.plot(dx,y,linewidth='1')
    plt.savefig("Graphical method1.pdf")
    plt.show()   
    return 

def modifiedFalsePositionMethod(g,low,high,expected_error,max_iter):
    
    if low<=-2 or high<=-2:
        return 'Invalid segment'
    if low>=1 or high>=1:
        return 'Invalid segment'
    
    if g(low)==0:
        return [0,low]
    elif g(high)==0:
        return [0,high]
    elif g(low)*g(high)>0:
        return False
    iter=0
    error=1.1*expected_error+0.1
    last=1
    ih=0
    il=0
    glow=g(low)
    ghigh=g(high)
    while math.fabs(error)>expected_error and iter<max_iter:
        
        if glow-ghigh!=0:
            new=high-(ghigh*(low-high))/(glow-ghigh)
        if iter>=1 and new!=0:
            error=(new-last)*100/new
        last=new
        iter+=1
        if g(low)*g(new)<0:
            high=new
            il+=1
            ih=0
            ghigh=g(high)
            if il>=2:
                glow/=2
                
        elif g(low)*g(new)>0:
            low=new
            ih+=1
            il=0
            glow=g(low)
            if ih>=2:
                ghigh/=2
        else:
            break

    list=[iter,new]
    return list


def falsePositionMethod(g,low,high,expected_error,max_iter):
    
    if low<=-2 or high<=-2:
        return 'Invalid segment'
    if low>=1 or high>=1:
        return 'Invalid segment'
    
    if g(low)==0:
        return [0,low]
    elif g(high)==0:
        return [0,high]
    elif g(low)*g(high)>0:
        return False
    iter=0
    error=1.1*expected_error+0.1
    last=1
    new=0
    while math.fabs(error)>expected_error and iter<max_iter:
        glow=g(low)
        ghigh=g(high)
        if glow-ghigh!=0:
            new=high-(ghigh*(low-high))/(glow-ghigh)
        if iter>=1 and new!=0:
            error=(new-last)*100/new
        last=new
        iter+=1
        if g(low)*g(new)<0:
            high=new
        elif g(low)*g(new)>0:
            low=new
        else:
            break

    list=[iter,new]
    return list
def secantMethod(g,first,second,expected_error,max_iter):
    if first<=-2 or second<=-2:
        return False
    if first>=1 or second>=1:
        return False
    
    iter=0
    error=1.1*expected_error+0.1
    x=[-1,first,second]
    while math.fabs(error)>expected_error and iter<max_iter:
        x[0]=x[1]
        x[1]=x[2]
        x[2]=x[1]-g(x[1])*(x[0]-x[1])/(g(x[0])-g(x[1]))
        iter=iter+1
        if x[2]!=0:
            error=(x[2]-x[1])*100/x[2]
    return [iter,x[2]]


if __name__=='__main__':
    while True:
        choice=int(input("Input choice: "))
        if choice==1:
            graphicalMethod()
        if choice==2:
            print('False Position Method: ')
            low=float(input('lower bound: '))
            high=float(input('higher bound: '))
            expected_error=float(input('Es: '))
            mxit=int(input('Maximum iteration: '))
            
            ans=falsePositionMethod(f,low,high,expected_error,mxit)
            if ans=='Invalid segment':
                print(ans)
            elif ans==False:
                print('No root in the segment')
            else:
                print('Iteration needed='+str(ans[0]))
                print('Value='+str(ans[1]))
        if choice==3:
            print('Secant Method: ')
            first=float(input('First Initial Guess: '))
            second=float(input('Second Initial Guess: '))
            expected_error=float(input('Es: '))
            mxit=int(input('Maximum iteration: '))
            
            ans=secantMethod(f,first,second,expected_error,mxit)
            if ans==False:
                print('Invalid Guess')
            else:
                print('Iteration needed='+str(ans[0]))
                print('Value='+str(ans[1]))
        if choice==4:
            print('Modified False Position Method: ')
            low=float(input('lower bound: '))
            high=float(input('higher bound: '))
            expected_error=float(input('Es: '))
            mxit=int(input('Maximum iteration: '))
            
            ans=modifiedFalsePositionMethod(f,low,high,expected_error,mxit)
            if ans=='Invalid segment':
                print(ans)
            elif ans==False:
                print('No root in the segment')
            else:
                print('Iteration needed='+str(ans[0]))
                print('Value='+str(ans[1]))
        if choice==5:
            break