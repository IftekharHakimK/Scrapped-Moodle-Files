import math
import numpy as np
from matplotlib import pyplot as plt
import matplotlib as mpl

def get(x,n):
    ab=x
    sign=1
    ans=0

    for i in range(1,n+1,1) :
        ans+=(ab/i)*sign
        ab*=x
        sign=-sign
    return ans


def find(term):
    x=-0.9
    list=[]
    while x<=1:
        ans=get(x,term)
        list.append(ans)
        x+=0.1
    
    return np.array(list)
        

if __name__=='__main__':
   
    while True:
        
        choice=int(input("Input choice: "))
        if choice==1:
            x=float(input("Input x: "))
            n=int(input("Number of iterations: "))
            if x<=-1 or x>1:
                print('Invalid')
            else:
                print(get(x,n))
        elif choice==2:
            x=np.arange(-0.9,1.1,0.1)
            
            #Built-in:
            
            now_x=1+x
            y=np.log(now_x)
            y=y/math.log(math.e)
           
            plt.figure(figsize=(10,6))
            plt.plot(x,y,label='Built-in',color='black',linewidth=3,linestyle='-')
            plt.grid(color='grey',linewidth=0.8,dashes=[10,2,2,2,2,2])
            plt.legend(loc='lower right')
            plt.xlabel("X values")
            plt.ylabel("Values of ln(1+x)")
            plt.title("Plots")
            plt.show()
        elif choice==3:
            x=np.arange(-0.9,1.1,0.1)
            
            #Built-in:
            
            now_x=1+x
            y=np.log(now_x)
            y=y/math.log(math.e)
           
            plt.figure(figsize=(10,6))
            plt.plot(x,y,label='Built-in',color='black',linewidth=3,linestyle='-')
            plt.grid(color='grey',linewidth=0.8,dashes=[10,2,2,2,2,2])
            plt.legend(loc='lower right')
            plt.xlabel("X values")
            plt.ylabel("Values of ln(1+x)")
            plt.title("Plots")
            
            #Approxing with Taylor Series:
            x=np.arange(-0.9,1.1,0.1)
            terms=[1,3,5,20,50]
            colors=['green','orange','blue','red','yellow']
            for i in range(0,5,1):
                y=find(terms[i])
                plt.plot(x,y,label='Terms='+str(terms[i]),color=colors[i],linewidth=3,linestyle='-.')
                plt.legend(loc='lower right')
                
            plt.show()
        
        elif choice==4:
            x=0.5
            ans=0
            errors=[]
            for i in range(1,51,1):
                prev=ans
                ans=get(x,i)
                error=(ans-prev)*100/ans
                error=math.fabs(error)                    
                if i>=2:
                    errors.append(error)
            x=np.arange(2,51,1);
            y=np.array(errors)
            
            plt.figure(figsize=(10,6))
            plt.plot(x,y,color='black',linewidth=2,linestyle='-')
            plt.grid(color='grey',linewidth=0.8,dashes=[10,2,2,2,2,2])
            plt.xlabel("Terms")
            plt.ylabel("Percentage rel. approx. error(%)")
            plt.title("Percentage rel. approx. error for finding ln(1.5)")
            plt.show()
        elif choice==5:
            break