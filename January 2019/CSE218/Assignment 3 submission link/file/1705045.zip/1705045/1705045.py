import numpy as np
import matplotlib as mpl
from matplotlib import pyplot as plt


if __name__=='__main__':
    file1=open('data.txt','r')
    file2=open('out1.txt','w')
    x=[]
    y=[]
    n=0
    for line in file1:
        entries = list(map(float, line.split()))
        x.append(entries[0])
        y.append(entries[1])
        n+=1
    nx=np.array(x)
    ny=np.array(y)
    
    mn=np.amin(nx)
    mx=np.amax(nx)
    plt.figure(figsize=(10,6))
    plt.scatter(nx,ny,s=2,label='Points',color='blue')    
    plt.grid(color='grey',linewidth=0.8)
    plt.legend(loc='lower right')
    gca=plt.gca()
    gca.set_xlim(xmin=mn-2) 
    gca.set_xlim(xmax=mx+2)
    plt.xlabel("X values")
    plt.ylabel("Function Values")
    lst=[n] 
    temp=x
    ys=[np.sum(ny)]
    font={
      'family':'Times New Roman',
      'size':19
      }
 
    mpl.rc('font',**font)
    for j in range(1,7):
        if j==1:
            temp=nx
        else:
            temp=temp*nx
        sm=np.sum(temp)
        lst.append(sm)
        c=temp*ny
        sm=np.sum(c)
        ys.append(sm)
    color=['red','green','black']    
    for order in range(1,4):
        file2.write('Order='+str(order)+'\n')
        
        coeff=[]
        cons=[]
        
        for i in range(0,order+1):
            row=[]
            for j in range(0,order+1):
                row.append(lst[i+j])
            coeff.append(row)
            cons.append(ys[i])
        ans=np.linalg.solve(coeff,cons)
        
        st="F(x)="+str(ans[0])
        for i in range(0,order+1):
            file2.write("Co-efficient["+str(i)+"]="+str(ans[i])+'\n')
            if i!=0:
                st+="+("+str(ans[i])+"x^"+str(i)+")"
        file2.write(st+'\n')
        
        datax=[] 
        datay=[]
        ex=mn-2
        while ex<=mx+2:
            nowx=1
            ey=0
            for j in range(0,ans.size):
                ey+=nowx*ans[j]
                nowx*=ex
            datax.append(ex)
            datay.append(ey)
            ex+=0.01
        st=0
        sr=0
        avg=np.sum(ny)
        avg/=n
        for i in range(0,n):
            ey=0
            nowx=1
            for j in range(0,ans.size):
                ey+=nowx*ans[j]
                nowx*=x[i]
            err=(ey-y[i])*(ey-y[i])
            sr+=err
            st+=(y[i]-avg)*(y[i]-avg)
        rc=(st-sr)/st
        file2.write("r="+str(np.sqrt(rc))+'\n')
        
        
        datax=np.array(datax)
        datay=np.array(datay)     
        plt.plot(datax,datay,label='Order='+str(order),color=color[order-1],linewidth=2)
    plt.legend(loc='lower right')
    plt.savefig("GRAPH.pdf")
    file1.close()
    file2.close()
