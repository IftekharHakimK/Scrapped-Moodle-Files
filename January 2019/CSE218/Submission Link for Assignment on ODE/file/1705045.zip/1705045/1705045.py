import numpy as np
import matplotlib as mpl
from matplotlib import pyplot as plt

def f(x,y):
    return (x+20*y) * np.sin(x*y)
def RungeKutta2(x,y,a2,h):
    a1=1-a2
    p1=0.5*(1/a2)
    q11=p1
    k1=f(x,y)
    k2=f(x+p1*h,y+q11*k1*h)
    return y+(a1*k1+a2*k2)*h
def euler(x,y,h):
    return y+f(x,y)*h
def RK4(x,y,h):
    k1=f(x,y)
    k2=f(x+0.5*h,y+0.5*h*k1)
    k3=f(x+0.5*h,y+0.5*h*k2)
    k4=f(x+h,y+h*k3)
    return y+(1/6)*(k1+2*k2+2*k3+k4)*h



if __name__=='__main__':
    steps=[0.01,0.05,0.1,0.5]
    colors=['black','red','green','blue','yellow']
    p=0
    #Euler
    plt.figure(figsize=(10,6))
    plt.title("Euler")
    plt.grid(color='grey',linewidth=0.8)
    plt.xlabel("X")
    plt.ylabel("Y")
    for step in steps:
        xs=np.arange(0,10.01,step)
        y=4
        ys=[4]
        for e in range(0,xs.size-1):  
            x=xs[e]
            y_new=euler(x,y,step)
            ys.append(y_new)
            y=y_new
        ys=np.array(ys)
        plt.plot(xs,ys,label="Euler with h="+str(step),color=colors[p])
        plt.legend(loc='best')
        p=(p+1)%5
        
    #Heun,Mid,Ralston
    names=["Heun","Midpoint","Ralston"]
    a2s=[1/2,1,2/3]
    for i in range(0,3):
        plt.figure(figsize=(10,6))
        plt.title(names[i])
        plt.grid(color='grey',linewidth=0.8)
        plt.xlabel("X")
        plt.ylabel("Y")
        for step in steps:
            xs=np.arange(0,10.01,step)
            y=4
            ys=[4]
            for e in range(0,xs.size-1):  
                x=xs[e]
                y_new=RungeKutta2(x,y,a2s[i],step)
                ys.append(y_new)
                y=y_new
            ys=np.array(ys)
            plt.plot(xs,ys,label=names[i]+" with h="+str(step),color=colors[p])
            plt.legend(loc='best')
            p=(p+1)%5
    #RK4
    plt.figure(figsize=(10,6))
    plt.title("RK-4")
    plt.grid(color='grey',linewidth=0.8)
    plt.xlabel("X")
    plt.ylabel("Y")
    for step in steps:
        xs=np.arange(0,10.01,step)
        y=4
        ys=[4]
        for e in range(0,xs.size-1):  
            x=xs[e]
            y_new=RK4(x,y,step)
            ys.append(y_new)
            y=y_new
        ys=np.array(ys)
        plt.plot(xs,ys,label="RK-4 with h="+str(step),color=colors[p])
        plt.legend(loc='best')
        p=(p+1)%5
    
    
    #For steps:
    
    for step in steps:
        plt.figure(figsize=(10,6))
        plt.title("h="+str(step))
        plt.grid(color='grey',linewidth=0.8)
        plt.xlabel("X")
        plt.ylabel("Y")
        #Euler
        xs=np.arange(0,10.01,step)
        y=4
        ys=[4]
        for e in range(0,xs.size-1):  
            x=xs[e]
            y_new=euler(x,y,step)
            ys.append(y_new)
            y=y_new
        ys=np.array(ys)
        plt.plot(xs,ys,label="Euler",color=colors[p])
        plt.legend(loc='best')
        p=(p+1)%5
        
        #Heun,Mid,Ralston
        names=["Heun","Midpoint","Ralston"]
        a2s=[1/2,1,2/3]
        for i in range(0,3):
            y=4
            xs=np.arange(0,10.01,step)
            ys=[4]
            for e in range(0,xs.size-1):  
                x=xs[e]
                y_new=RungeKutta2(x,y,a2s[i],step)
                ys.append(y_new)
                y=y_new
            ys=np.array(ys)
            plt.plot(xs,ys,label=names[i],color=colors[p])
            plt.legend(loc='best')
            p=(p+1)%5
        #RK4
        xs=np.arange(0,10.01,step)
        y=4
        ys=[4]
        for e in range(0,xs.size-1):  
            x=xs[e]
            y_new=RK4(x,y,step)
            ys.append(y_new)
            y=y_new
        ys=np.array(ys)
        plt.plot(xs,ys,label="RK-4",color=colors[p])
        plt.legend(loc='best')
        p=(p+1)%5
        
    
            
            
        
    