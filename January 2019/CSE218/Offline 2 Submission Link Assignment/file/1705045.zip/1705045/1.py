import numpy as np
def show(file2,matrix,row,col):
    for i in range(0,row,1):
        strg=""
        for j in range(0,col,1):
            strg+=str("%.4f" % round(matrix[i][j],4))+' '
        file2.write(strg+'\n')
def VAR(file2,matrix,row,col):
    for i in range(0,row,1):
        strg=str("%.4f" % round(matrix[i],4))+' '
        file2.write(strg+'\n')
        
        
if __name__=='__main__':
    file1=open('in1.txt','r')
    file2=open('out1.txt','w')
    entries=file1.readline().split()
    n=int(entries[0])
    k=np.empty([n,n])
    A=[]
    for i in range(0,n,1):
        entries = list(map(float, file1.readline().split()))
        A.append(entries)
    B=[]
    for i in range(0,n,1):
        entries = list(map(float, file1.readline().split()))
        x=int(entries[0])
        B.append(x)
    
    L=np.zeros([n,n])
    U=np.zeros([n,n])
    check=0
    for i in range(0,n,1):
        U[i][i]=A[i][i]
        L[i][i]=1
        for j in range(i+1,n,1):
            L[j][i]=A[j][i]/U[i][i]
            U[i][j]=A[i][j]
            
        for j in range(i+1,n,1):
            for k in range(i+1,n,1):
                A[j][k]=A[j][k]-L[j][i]*U[i][k]
    for j in range(0,n,1):
        f=0
        for k in range(0,n,1):
            if U[j][k]==0:
                f+=1
            if f==n:
                check=1    
    y=[]
    show(file2,L,n,n)
    file2.write('\n')
    show(file2,U,n,n)
    file2.write('\n')
    if check==0:
        for i in range(0,n,1):
            ans=B[i]
            for j in range(0,i,1):
                ans-=L[i][j]*y[j]
            ans/=L[i][i]
            y.append(ans)
        x=[0]*n
        for i in range(n-1,-1,-1):
            ans=y[i]
            for j in range(i+1,n,1):
                ans-=U[i][j]*x[j]
            ans/=U[i][i]
            x[i]=ans
        VAR(file2,y,n,1)
        file2.write('\n')
        VAR(file2,x,n,1)
            
    else:
       file2.write("No unique solution")
    file1.close()
    file2.close()
    
   
      
   
    
    