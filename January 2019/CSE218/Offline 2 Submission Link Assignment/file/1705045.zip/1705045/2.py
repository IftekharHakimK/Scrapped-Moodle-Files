import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
def isItDone(A,x,y):
    f=0
    for i in range(0,y-1,1):
        if A[0][i]>=0:
            f+=1
    if f==y-1:
        return True
    else:
        return False

def highestNegInFirstRow(A,x,y):
    mn=A[0][0]
    ans=0
    for i in range(0,y-2):
        if A[0][i]<mn:
            mn=A[0][i]
            ans=i
    return ans
def smallestIntercept(A,x,y,piv_column):
    ans=-1
    ret=-1
    for i in range(1,x,1):
        if A[i][piv_column]!=0:
            intercept=A[i][y-1]/A[i][piv_column]
            if intercept>=0:
                if ans==-1:
                    ans=intercept
                    ret=i
                else:
                    if intercept<ans:
                        ans=intercept
                        ret=i
    return ret
def show(file2,matrix,row,col):
    for i in range(0,row,1):
        strg=""
        for j in range(0,col,1):
            strg+=str("%.2f" % round(matrix[i][j],2))+'\t'+'\t'
        file2.write(strg+'\n')
        
if __name__=='__main__':
    file1=open('in2.txt','r')
    file2=open('out2.txt','w')
    entries =list(map(float, file1.readline().split()))
    matrix=[]
    matrix.append(entries)
    n=len(entries)
    for i in range(0,n,1):
        matrix[0][i]=-matrix[0][i]
    m=0
    X=[]
    Y=[]
    Z=[]
    max_x=0
    for each_line in file1:
        entries = list(map(float, each_line.split()))
        matrix.append(entries)
        if n==2:
            X.append(entries[0])
            Y.append(entries[1])
            Z.append(entries[2])
            if X[m]!=0:
                if Z[m]/X[m]>max_x:
                    max_x=Z[m]/X[m]
        m+=1
    if n==2:
        plt.figure(figsize=(20,20))
        #max_x=math.ceil(max_x)
        x=np.arange(0,max_x,0.1)
        sz=x.size
        lst=[]
        wh=1000000000
        for i in range(0,m,1):
            a=Z[i]
            b=X[i]
            c=Y[i]
            if c!=0:
                now=(a-x*b)/c
                plt.plot(x,now,color='black')
                lst.append(now)
            else:
                tx=np.full((sz),a/b)
                now=np.arange(0,sz/10,0.1)
                plt.plot(tx,now,color='black')
                if a/b<wh:
                    wh=a/b
        minimum=lst[0]
        for i in range(1,len(lst),1):
            minimum=np.minimum(lst[i],minimum)
        low=np.zeros(sz)
        plt.fill_between(x, low, minimum, color='red', alpha='0.5')
        gca=plt.gca()
        gca.set_xlim(xmin=0)
        gca.set_ylim(ymin=0)
        if wh<1000000000:
            gca.set_xlim(xmax=wh)
        plt.xlabel("X values")
        plt.title("Plots")
        plt.grid(color='grey',linewidth=0.8,dashes=[10,2,2,2,2,2])
        plt.savefig("l.pdf")
    
    
    
    
    for i in range(0,m+1,1):
        if i!=0:
            C=matrix[i][n]
            matrix[i][n]=0
            for j in range(0,m,1):
                matrix[i].append(0)
            matrix[i][n+i-1]=1
            matrix[i].append(C)
        else:
            for j in range(0,m+2,1):
                matrix[i].append(0)
            matrix[i][n+m]=1
        
    y=n+m+2
    x=m+1
    p=0
    while True:
        file2.write("Current matrix before selecting pivot:\n")
        show(file2,matrix,x,y)
        file2.write('\n')
        if isItDone(matrix,x,y):            
            break
        else:
            piv_column=highestNegInFirstRow(matrix,x,y)
            piv_row=smallestIntercept(matrix,x,y,piv_column)
            e=matrix[piv_row][piv_column]
            for i in range(0,y,1):
                matrix[piv_row][i]/=e
            file2.write('Made pivot 1:\n')
            show(file2,matrix,x,y)
            #a*R2-b*R1
            for i in range(0,x,1):
                if i!=piv_row:
                    b=matrix[i][piv_column]
                    for j in range(0,y,1):
                        matrix[i][j]=matrix[i][j]-(b)*matrix[piv_row][j]
                    
            file2.write('Made other elements 0 in pivot column:\n')
            show(file2,matrix,x,y)
    file2.write("Ans=\n")
    file2.write(str("%.2f" % round(matrix[0][y-1],2))+'\n')
    values=[]
    for i in range(0,n,1):
        one=0
        zero=0
        for j in range(0,x,1):
            if matrix[j][i]==0:
                zero+=1
            elif matrix[j][i]==1:
                one+=1
                ans=matrix[j][y-1]
        if one==1 and zero==x-1:
            values.append(ans)
        else:
            values.append(0)
    file2.write("Values=\n")
    for i in range(0,n,1):
        file2.write(str("%.2f" % round(values[i],2))+'\n')
    file1.close()
    file2.close()
        
    
        
        
               
        
            
            
    