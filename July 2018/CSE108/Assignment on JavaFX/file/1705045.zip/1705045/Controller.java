package sample;

import javafx.fxml.FXML;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class Controller {
    @FXML
    TableView table;
    @FXML
    TableColumn WORD,FREQUENCY;
    public void tableupdate()
    {
        FileChooser fileChooser=new FileChooser();
        table.getItems().clear();
        fileChooser.getExtensionFilters().add(
                new FileChooser.ExtensionFilter("Text Files", "*.txt"));
        WORD.setCellValueFactory(new PropertyValueFactory<>("word"));
        FREQUENCY.setCellValueFactory(new PropertyValueFactory<>("frq"));
        Stage window=(Stage)table.getScene().getWindow();
        File f=fileChooser.showOpenDialog(window);
        try {
            FileReader fr = new FileReader(f);
            try {
                List<String> list=new ArrayList<String>();
                String string=new String();
                char c;
                while (fr.ready()) {
                    c=(char)fr.read();
                    if((c>='A'&&c<='Z')||(c>='a'&&c<='z')||(c>='0'&&c<='9') )
                    {
                        if(c>='A'&&c<='Z')
                        {
                            int q;
                            q=c-'A'+'a';
                            c=(char)q;
                        }

                        string=string+c;
                    }
                    else
                    {
                        if(string.isEmpty()==false)
                        {
                            list.add(string);
                            string=new String();
                        }
                    }
                }
                if(string.isEmpty()==false)
                {
                    list.add(string);
                }
                boolean[] check=new boolean[list.size()];
                for(int i=0;i<list.size();i++)
                {
                    if(check[i]==false)
                    {
                        check[i]=true;
                        int now=1;
                        for(int j=i+1;j<list.size();j++)
                        {
                            if(list.get(j).equals(list.get(i)))
                            {
                                now++;
                                check[j]=true;
                            }
                        }
                        table.getItems().add(new w(list.get(i),now));
                    }
                }



            }catch (IOException ioe)
            {
                System.out.println("IOEXCEPTION");
            }

        }catch (FileNotFoundException r)
        {
            System.out.println("FILE NOT FOUND");
        }
    }
}
