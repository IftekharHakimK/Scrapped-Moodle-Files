package sample;

public class w
{
    String word;int frq;
    w(String word,int frq)
    {
        this.word=word;
        this.frq=frq;
    }
    public String getWord()
    {
        return word;
    }
    public int getFrq()
    {
        return frq;
    }
}