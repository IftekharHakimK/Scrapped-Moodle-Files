import java.io.PrintWriter;

public class BMessage {
    String text;
    String name;
    PrintWriter outToClient2;
    boolean log;
    String type;
    public BMessage(String text,String name,PrintWriter printWriter,boolean log,String type)
    {
        this.name=name;
        this.text=text;
        this.outToClient2=printWriter;
        this.log=log;
        this.type=type;
    }
    public void next()
    {
        if(log==true)
        {
            if(type.equals("Admin"))
            {
                logged.send(text,name);

            }
            else
            {
                outToClient2.println("You are not admin...");
                outToClient2.flush();
            }
        }
        else
        {
            outToClient2.println("Please login first");
            outToClient2.flush();
        }
    }

}
