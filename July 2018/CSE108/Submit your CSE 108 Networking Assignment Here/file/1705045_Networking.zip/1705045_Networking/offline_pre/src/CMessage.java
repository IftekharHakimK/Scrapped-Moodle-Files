import java.io.*;
import java.net.Socket;

public class CMessage {
    String receiver_name,sender;
    String text;
    PrintWriter outToClient2;
    public CMessage(String receiver_name, String text,String sender,PrintWriter printWriter)
    {
        this.receiver_name=receiver_name;
        this.outToClient2=printWriter;
        this.text=text;
        this.sender=sender;
    }
    public void next()
    {
        if(logged.peerMessage(sender,receiver_name,text))
        {
            outToClient2.println("Sent to "+receiver_name);
            outToClient2.flush();
        }
        else
        {
            outToClient2.println("Message not sent.Receiver is offline");
            outToClient2.flush();
        }

    }
    public void sendFile(String fileName)
    {
        Socket socket=logged.getSocket(receiver_name);
        PrintWriter printWriter=logged.getPW(receiver_name);
        printWriter.println("You received a file");
        printWriter.flush();
        printWriter.println("#file,"+fileName);
        printWriter.flush();
        try
        {
            File file = new File(fileName);
            FileInputStream fis = new FileInputStream(file);
            BufferedInputStream bis = new BufferedInputStream(fis);
            OutputStream os = socket.getOutputStream();
            byte[] contents;
            long fileLength = file.length();
            printWriter.println(String.valueOf(fileLength));     //These two lines are used
            printWriter.flush();                                 //to send the file size in bytes.

            long current = 0;

            while(current!=fileLength){
                int size = 10000;
                if(fileLength - current >= size)
                    current += size;
                else{
                    size = (int)(fileLength - current);
                    current = fileLength;
                }
                contents = new byte[size];
                bis.read(contents, 0, size);
                os.write(contents);
                //System.out.println("Sending file ... "+(current*100)/fileLength+"% complete!");
            }
            os.flush();
        }
        catch(Exception e)
        {
            System.err.println("Could not transfer file to receiver.");
        }
        printWriter.flush();
    }
}
