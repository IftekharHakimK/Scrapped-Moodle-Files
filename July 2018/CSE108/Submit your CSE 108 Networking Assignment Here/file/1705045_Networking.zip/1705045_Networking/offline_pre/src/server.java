import javax.jws.soap.SOAPBinding;
import javax.xml.ws.LogicalMessage;
import java.io.*;
import java.net.*;
public class server
{
    public static void main(String argv[]) throws Exception
    {
        int workerThreadCount = 0;
        String clientSentence;
        String capitalizedSentence;
        ServerSocket welcomeSocket = new ServerSocket(555);
        int id=1;
        while(true)
        {
            Socket connectionSocket = welcomeSocket.accept();
            WorkerThread wt = new WorkerThread(connectionSocket, id);
            Thread t = new Thread(wt);
            t.start();
            workerThreadCount++;
            System.out.println("Client [" + id + "] is now connected. No. of worker threads = " + workerThreadCount);
            id++;
        }

    }
}



class WorkerThread implements Runnable {
    private Socket connectionSocket;
    private int id = 0;
    String userid;
    String type;

    public WorkerThread(Socket s, int id) {
        this.connectionSocket = s;
        this.id = id;
    }

    public void run() {
        boolean log=false;
        while (true) {
            String clientSentence;
            String capitalizedSentence;
            try {
                BufferedReader inFromClient = new BufferedReader(new InputStreamReader(connectionSocket.getInputStream()));
                PrintWriter outToClient2 = new PrintWriter(connectionSocket.getOutputStream());
                clientSentence = inFromClient.readLine();
                String[] strings=clientSentence.split(",");
                if (strings.length!=0)
                {
                    if(strings[0].equals("L"))
                    {
                        if(log==false) {
                            LMessage lMessage = new LMessage(strings[1], strings[2], strings[3], outToClient2);

                            if (lMessage.next()) {
                                userid = strings[1];
                                type = strings[3];
                                log = true;
                                logged.setA(userid, outToClient2, connectionSocket);
                            }
                        }
                        else
                        {
                            outToClient2.println("Device already in use");
                            outToClient2.flush();
                        }
                    }
                    if(strings[0].equals("S")) {
                        SMessage sMessage=new SMessage(strings[1],outToClient2,userid);
                        if (log == true) {
                            if(strings.length==3)
                                System.out.println(userid+" sent : "+strings[2]);
                            sMessage.next();
                        }
                        else
                        {
                            outToClient2.println("Please login first");
                            outToClient2.flush();
                        }
                    }
                    if(strings[0].equals("B"))
                    {
                        BMessage bMessage=new BMessage(strings[1],userid,outToClient2,log,type);
                        bMessage.next();
                    }
                    if(strings[0].equals("C"))
                    {
                        if(strings.length==3)
                        {
                            CMessage cMessage=new CMessage(strings[1],strings[2],userid,outToClient2);
                            if(log==true) {
                                cMessage.next();
                            }
                            else
                            {
                                outToClient2.println("Please login first");
                                outToClient2.flush();
                            }

                        }
                        else if(strings.length==4) {
                            CMessage cMessage = new CMessage(strings[1], strings[2], userid, outToClient2);

                            //All that avails is flight
                            try {
                                String strRecv;
                                strRecv = inFromClient.readLine();
                                int filesize = Integer.parseInt(strRecv);
                                byte[] contents = new byte[10000];
                                String temp = strings[3];
                                FileOutputStream fos = new FileOutputStream(temp);
                                BufferedOutputStream bos = new BufferedOutputStream(fos);
                                InputStream is = connectionSocket.getInputStream();
                                int bytesRead = 0;
                                int total = 0;
                                while (total != filesize)
                                {
                                    bytesRead = is.read(contents);
                                    total += bytesRead;
                                    bos.write(contents, 0, bytesRead);
                                }
                                bos.flush();
                                if(log==false)
                                {
                                    outToClient2.println("You are not logged");
                                    outToClient2.flush();
                                }
                                else if(logged.isLogged(strings[1])==false)
                                {
                                    outToClient2.println("Receiver not logged");
                                    outToClient2.flush();
                                }
                                else {
                                    cMessage.next();
                                    outToClient2.println("File sent");
                                    outToClient2.flush();
                                    cMessage.sendFile(temp);
                                }
                            } catch (Exception e) {
                                System.err.println("Could not transfer file to server.");
                            }
                        }
                        }

                    }

                //outToClient2.println("At least you tried");
            } catch (Exception e) {

            }
        }
    }
}