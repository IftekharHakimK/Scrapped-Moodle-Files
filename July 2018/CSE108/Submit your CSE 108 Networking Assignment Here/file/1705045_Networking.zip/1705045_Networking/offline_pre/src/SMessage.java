import java.io.PrintWriter;

public class SMessage {
    String string;
    PrintWriter outToClient2;
    String name;
    public SMessage(String string, PrintWriter printWriter,String name)
    {
        this.string=string;
        this.outToClient2=printWriter;
        this.name=name;
    }
    public boolean isValid()
    {
        if(string.equals("logout")||string.equals("show"))
        {
            return true;
        }
        else
        {
            return false;
        }
    }
    public void next()
    {
        if(isValid()) {
            if (string.equals("show")) {
                String s = logged.show();
                outToClient2.println(s);
                outToClient2.flush();

            }
            else if (string.equals("logout")) {
                logged.cancel(name);
                outToClient2.println("GOOD BYE");
                outToClient2.flush();
            }
        }
        else {
            outToClient2.println("Invalid Input");
            outToClient2.flush();
        }
    }
}
