import java.io.PrintWriter;
import java.net.Socket;

class logged
{
    static String[] a;
    static PrintWriter[] all_client;
    static Socket[] all_socket;
    static
    {
        all_client=new PrintWriter[10];
        all_socket=new Socket[10];
        a=new String[10];
        for(int i=0;i<10;i++)
        {
            a[i]=".";
        }
    }
    public static void setA(String name,PrintWriter printWriter,Socket socket)
    {
        for(int i=0;i<10;i++)
        {
            if(a[i].equals("."))
            {
                a[i]=name;
                all_client[i]=printWriter;
                all_socket[i]=socket;
                break;
            }
        }

    }
    public static String show()
    {
        String now=new String();
        for(int i=0;i<10;i++)
        {
            if(a[i].equals(".")==false)
            {

                if(now.length()==0)
                {
                    now=a[i];
                }
                else
                {
                    now=now+","+a[i];
                }
            }
            else
            {
                ;
            }
        }
        return now;
    }
    public static void cancel(String pop)
    {
        for(int i=0;i<10;i++)
        {
            if(a[i].equals(pop))
            {
                a[i]=".";
            }
        }
    }
    public static void send(String text,String sender)
    {
        for(int i=0;i<10;i++)
        {
            if(!a[i].equals("."))
            {
                if(!a[i].equals(sender))
                {
                    all_client[i].println("Broadcast message from "+sender+": "+text);
                    all_client[i].flush();
                }
                else
                {
                    all_client[i].println("Sent to all");
                    all_client[i].flush();
                }
            }
        }
    }
    public static boolean peerMessage(String sender,String receiver,String text)
    {
        for(int i=0;i<10;i++)
        {
            if(a[i].equals(receiver))
            {
                all_client[i].println(sender+" sent you a message: "+text);
                all_client[i].flush();
                return true;
            }

        }
        return false;
    }
    public static Socket getSocket(String name)
    {
        for(int i=0;i<10;i++)
        {
            if(a[i].equals(name))
            {
                return all_socket[i];
            }
        }
        return all_socket[0];
    }
    public static PrintWriter getPW(String name)
    {
        for(int i=0;i<10;i++)
        {
            if(a[i].equals(name))
            {
                //System.out.println("receiver="+name);
                return all_client[i];
            }
        }
        return all_client[0];
    }
    public static boolean isLogged(String name)
    {
        for(int i=0;i<10;i++)
        {
            if(a[i].equals(name))
            {
                return true;
            }
        }
        return false;
    }
}