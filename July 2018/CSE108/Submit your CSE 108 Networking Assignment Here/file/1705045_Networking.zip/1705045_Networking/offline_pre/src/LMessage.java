import java.io.*;

public class LMessage {
    private String name,pass,type;
    PrintWriter outToClient2;
    LMessage(String name, String pass, String type, PrintWriter printWriter)
    {
        this.name=name;
        this.pass=pass;
        this.type=type;
        this.outToClient2=printWriter;
    }
    public int isValid()
    {
        try {
            // FileReader reads text files in the default encoding.
            String line;
            FileReader fileReader =
                    new FileReader("reg.txt");

            // Always wrap FileReader in BufferedReader.
            BufferedReader bufferedReader =
                    new BufferedReader(fileReader);

            while((line = bufferedReader.readLine()) != null) {
                String[] out=line.split("#");
                if( (name.equals(out[0])&&pass.equals(out[1])&&type.equals(out[2])))
                {
                    for(int i=0;i<10;i++)
                    {
                        if(name.equals(logged.a[i]))
                        {
                            return 2;
                        }
                    }
                    return 1;
                }
            }
            bufferedReader.close();
            return 3;
        }
        catch(FileNotFoundException ex) {
            System.out.println(
                    "Unable to open file '" +
                            "reg.txt" + "'");
            return -1;
        } catch (IOException e) {
            e.printStackTrace();
            return -1;
        }


    }
    public boolean next()
    {
        if(isValid()==1)
        {
            outToClient2.println("Login Successful");
            outToClient2.flush();
            //logged.setA(name);
            return true;
        }
        else if(isValid()==3)
        {
            outToClient2.println("Failed.Wrong user ID or Password or type");
            outToClient2.flush();
            return false;
        }
        else
        {
            outToClient2.println("Already logged in");
            outToClient2.flush();
            return false;
        }
    }

}
