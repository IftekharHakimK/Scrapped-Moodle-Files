import java.io.*;
import java.net.Socket;

class TCPClient3 {
    public static void main(String argv[]) throws Exception
    {
        String sentence;
        String modifiedSentence;
        BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));
        Socket clientSocket = new Socket("localhost", 555);
        PrintWriter outToServer = new PrintWriter(clientSocket.getOutputStream(),true);
        BufferedReader inFromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));

        while(true)
        {

            if(inFromUser.ready()) {
                sentence = inFromUser.readLine();
                outToServer.println(sentence);
                String[] out=sentence.split(",");
                if(out[0].equals("C")&out.length==4)
                {
                    String  tyu=out[3];
                    try
                    {
                        File file = new File(tyu);
                        FileInputStream fis = new FileInputStream(file);
                        BufferedInputStream bis = new BufferedInputStream(fis);
                        OutputStream os = clientSocket.getOutputStream();
                        byte[] contents;
                        long fileLength = file.length();
                        outToServer.println(String.valueOf(fileLength));     //These two lines are used
                        outToServer.flush();                                 //to send the file size in bytes.

                        long current = 0;

                        while(current!=fileLength){
                            int size = 10000;
                            if(fileLength - current >= size)
                                current += size;
                            else{
                                size = (int)(fileLength - current);
                                current = fileLength;
                            }
                            contents = new byte[size];
                            bis.read(contents, 0, size);
                            os.write(contents);
                        }
                        os.flush();
                    }
                    catch(Exception e)
                    {
                        System.err.println("Could not transfer file to server.");
                    }
                    outToServer.flush();
                }


            }
            if(inFromServer.ready()) {
                modifiedSentence = inFromServer.readLine();
                String[] out=modifiedSentence.split(",");
                if(out[0].equals("#file"))
                {
                    //System.out.println(modifiedSentence);
                    try
                    {
                        String strRecv;
                        strRecv =inFromServer.readLine();                    //These two lines are used to determine
                        int filesize=Integer.parseInt(strRecv);     //the size of the receiving file
                        byte[] contents = new byte[10000];
                        String temp="saved_"+out[1];
                        FileOutputStream fos = new FileOutputStream(temp);
                        BufferedOutputStream bos = new BufferedOutputStream(fos);
                        InputStream is = clientSocket.getInputStream();
                        int bytesRead = 0;
                        int total=0;            //how many bytes read
                        while(total!=filesize)  //loop is continued until received byte=totalfilesize
                        {
                            bytesRead=is.read(contents);
                            total+=bytesRead;
                            bos.write(contents, 0, bytesRead);
                        }
                        bos.flush();
                    }
                    catch(Exception e)
                    {
                        System.err.println("Could not transfer file to client.");
                    }

                }
                else {
                    System.out.println(modifiedSentence);
                    if (modifiedSentence.equals("GOOD BYE")) {
                        System.exit(0);
                    }
                }
            }
        }

    }
}
