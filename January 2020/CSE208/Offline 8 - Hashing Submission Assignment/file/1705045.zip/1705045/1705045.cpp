#include<bits/stdc++.h>
#define ll long long
#define dbg(x) cout<<#x<<"-->"<<x<<endl;
using namespace std;

int hash1(string s,int N)
{
    int p1=1;
    int ans=0;
    for(int i=0; i<s.size(); i++)
    {
        ans=(ans+(s[i]-'a')*p1)%N;
        p1=(p1*31)%N;
    }
    return ans;
}
int hash2(string s,int N)
{
    int ans1=0,ans2=0;
    int p1=1;
    for(int i=0; i<s.size(); i++)
    {
        ans1=(ans1+(s[i]-'a')*p1)%N;
        p1=(p1*37)%N;
    }

    p1=1;
    for(int i=0; i<s.size(); i++)
    {
        ans2=(ans2+(s[i]-'a')*p1)%N;
        p1=(p1*53)%N;
    }
    return (ans1^ans2)%N;
}

int auxHash(string s,int N)
{
    int p1=1;
    int ans=0;
    for(int i=0; i<s.size(); i++)
    {
        int c=(s[i]-'a');
        if(i%2)
            c=(c+1)%26;
        else
            c=(c-1+26)%26;

        ans=(ans+c*p1)%N;
        p1=(p1*59)%N;
    }
    if(ans==0)
        ans=1;
    return ans;
}

struct node
{
    string key;
    int value;
    node* next=NULL;
    node()
    {
        ;
    }
    node(string _key,int _value)
    {
        key=_key;
        value=_value;
    }
    ~node()
    {
        if(next)
            delete next;
    }
};

class chaining_method_table
{
    int N;
    node**table;
    int (*getHash)(string,int);
public:
    int col=0,probe=0;

    chaining_method_table(int _N, int (*_getHash)(string,int))
    {
        N=_N;
        table=new node*[N];
        for(int i=0; i<N; i++)
            table[i]=NULL;
        getHash=_getHash;
    }
    ~chaining_method_table()
    {
        for(int i=0; i<N; i++)
        {
            if(table[i]!=NULL)
            {
                delete table[i];
            }
        }
        delete[] table;
    }

    void Insert(string _key, int _value)
    {
        node * temp=new node(_key,_value);
        int idx=getHash(_key,N);
        if(table[idx]==NULL)
        {
            table[idx]=temp;
        }
        else
        {
            col++;
            node * now=table[idx];
            node * last=NULL;
            while(true)
            {
                if(now==NULL)
                {
                    now=temp;
                    last->next=now;
                    break;
                }
                last=now;
                now=now->next;
            }
        }
    }

    void Delete(string _key)
    {
        int idx=getHash(_key,N);
        node * now=table[idx];
        node * last=NULL;
        while(now!=NULL)
        {
            if(now->key==_key)
            {
                if(last==NULL)
                    table[idx]=now->next;
                else
                {
                    last->next=now->next;
                }
                break;
            }
            last=now;
            now=now->next;
        }
    }

    bool Search(string _key)
    {
        int idx=getHash(_key,N);

        node * now=table[idx];
        while(now!=NULL)
        {
            probe++;
            if(now->key==_key)
                return true;
            now=now->next;
        }
        return false;
    }
};

class double_hashing_table // node->next is not necessary
{
    int N;
    node ** table;
    int (*getHash)(string,int);
public:
    int col=0,probe=0;

    double_hashing_table(int _N, int (*_getHash)(string,int))
    {
        N=_N;
        table=new node*[N];
        for(int i=0; i<N; i++)
            table[i]=NULL;
        getHash=_getHash;
    }
    ~double_hashing_table()
    {
        for(int i=0; i<N; i++)
        {
            if(table[i]!=NULL)
            {
                delete table[i];
            }
        }
        delete[] table;
    }

    void Insert(string _key, int _value)
    {
        node * temp=new node(_key,_value);
        //bool yes=0;
        int p1=getHash(_key,N),q1=auxHash(_key,N);
        for(int i=0; i<N; i++)
        {
            int idx=(p1+i*q1)%N;
            if(table[idx]==NULL)
            {
                table[idx]=temp;
                //yes=1;
                break;
            }
            col++;
        }
        //assert(yes);
        return;
    }
    void Delete(string _key)
    {
        int p1=getHash(_key,N),q1=auxHash(_key,N);
        for(int i=0; i<N; i++)
        {
            int idx=(p1+i*q1)%N;
            if(table[idx]!=NULL&&table[idx]->key==_key)
            {
                table[idx]=NULL;
                return;
            }
        }
        return;
    }

    bool Search(string _key)
    {
        int p1=getHash(_key,N),q1=auxHash(_key,N);
        for(int i=0; i<N; i++)
        {
            probe++;
            int idx=(p1+i*q1)%N;
            if(table[idx]!=NULL&&table[idx]->key==_key)
                return true;
        }
        return false;
    }
};

class custom_probing_table // node->next is not necessary
{
    int N;
    node ** table;
    int (*getHash)(string,int);
    const int C1=3,C2=5;
public:
    int col=0,probe=0,failed=0;
    custom_probing_table(int _N, int (*_getHash)(string,int))
    {
        N=_N;
        table=new node*[N];
        for(int i=0; i<N; i++)
            table[i]=NULL;
        getHash=_getHash;
    }
    ~custom_probing_table()
    {
        for(int i=0; i<N; i++)
        {
            if(table[i]!=NULL)
            {
                delete table[i];
            }
        }
        delete[] table;
    }
    void Insert(string _key, int _value)
    {
        node * temp=new node(_key,_value);
        bool yes=0;
        int p1=getHash(_key,N),q1=auxHash(_key,N);
        for(int i=0; i<N; i++)
        {
            int idx=(p1+(i*q1*C1)%N +(i*i*C2)%N)%N;
            if(table[idx]==NULL)
            {
                table[idx]=temp;
                yes=1;
                break;
            }
            col++;
        }
        if(!yes)
            failed++;
        return;
    }
    void Delete(string _key)
    {
        int p1=getHash(_key,N),q1=auxHash(_key,N);
        for(int i=0; i<N; i++)
        {
            int idx=(p1+(i*q1*C1)%N +(i*i*C2)%N)%N;
            if(table[idx]!=NULL&&table[idx]->key==_key)
            {
                table[idx]=NULL;
                return;
            }
        }
        return;
    }

    bool Search(string _key)
    {
        int p1=getHash(_key,N),q1=auxHash(_key,N);
        for(int i=0; i<N; i++)
        {
            probe++;
            int idx=(p1+(i*q1*C1)%N +(i*i*C2)%N)%N;
            if(table[idx]!=NULL&&table[idx]->key==_key)
                return true;
        }
        return false;
    }
};

string random_string(int length=7)
{
    string s;
    for(int i=0; i<length; i++)
    {
        s+=('a'+rand()%26);
    }
    return s;
}

main()
{
    int provision;
    cin>>provision;

    if(provision)
    {
        int N;
        cin>>N;

        srand(time(0));
        string all[10000];
        map<string,bool>mp1;
        int i=0;
        while(i<10000)
        {
            string s=random_string();
            if(!mp1[s])
            {
                mp1[s]=1;
                all[i++]=s;
            }
        }
        int idx[1000];
        i=0;
        map<int,int>mp2;
        while(i<1000)
        {
            int temp=rand()%10000;
            if(!mp2[temp])
            {
                mp2[temp]=1;
                idx[i++]=temp;
            }
        }

        chaining_method_table t1(N,&hash1),t4(N,&hash2);
        double_hashing_table t2(N,&hash1),t5(N,&hash2);
        custom_probing_table t3(N,&hash1),t6(N,&hash2);
        for(int i=0; i<10000; i++)
        {
            t1.Insert(all[i],i+1);
            t2.Insert(all[i],i+1);
            t3.Insert(all[i],i+1);
            t4.Insert(all[i],i+1);
            t5.Insert(all[i],i+1);
            t6.Insert(all[i],i+1);
        }
        for(int i=0; i<1000; i++)
        {
            t1.Search(all[idx[i]]);
            t2.Search(all[idx[i]]);
            t3.Search(all[idx[i]]);
            t4.Search(all[idx[i]]);
            t5.Search(all[idx[i]]);
            t6.Search(all[idx[i]]);
        }
        cout<<t1.col<<' '<<(t1.probe*1.0/1000)<<'\n';
        cout<<t2.col<<' '<<(t2.probe*1.0/1000)<<'\n';
        cout<<t3.col<<' '<<(t3.probe*1.0/1000)<<'\n';
        cout<<t4.col<<' '<<(t4.probe*1.0/1000)<<'\n';
        cout<<t5.col<<' '<<(t5.probe*1.0/1000)<<'\n';
        cout<<t6.col<<' '<<(t6.probe*1.0/1000)<<'\n';
    }
    else
    {
        int N;
        cin>>N;

        chaining_method_table t1(N,&hash1);
        double_hashing_table t2(N,&hash1);
        custom_probing_table t3(N,&hash1);

        while(true)
        {
            int c;
            cin>>c;
            if(c==1)
            {
                string s;
                int value;
                cin>>s>>value;
                t1.Insert(s,value);
                t2.Insert(s,value);
                t3.Insert(s,value);
            }
            else if(c==2)
            {
                string s;
                cin>>s;
                cout<<t1.Search(s)<<' '<<t2.Search(s)<<' '<<t3.Search(s)<<'\n';
            }
            else if(c==3)
            {
                string s;
                cin>>s;
                t1.Delete(s);
                t2.Delete(s);
                t3.Delete(s);
            }
            else
                break;
        }

    }
}
