#include<bits/stdc++.h>
#define INF 1e7
using namespace std;
class Graph
{
    vector<vector<pair<int,int> > > adj;
    vector<pair<int,pair<int,int> > > all;
    int n;
    int * parent, * rnk;
    bool * processed;

public:
    Graph(int _n)
    {
        n=_n;
        adj.resize(n);
        parent=new int[n];
        rnk=new int[n];
        processed=new bool[n];
    }
    ~Graph()
    {
        all.clear();
        for(int i=0;i<n;i++)
            adj[i].clear();
        adj.clear();
        delete[] parent;
        delete[] rnk;
        delete[] processed;
        parent=0;
        rnk=0;
        processed=0;
    }
    void addEdge(int u,int v,int w)
    {
        adj[u].push_back({v,w});
        adj[v].push_back({u,w});
        all.push_back({w,{u,v}});
        return;
    }
    void initDSU()
    {
        for(int i=0;i<n;i++)
            parent[i]=i,rnk[i]=0;
        return;
    }
    int FindSet(int u)
    {
        if(parent[u]==u)
            return u;
        else
            return parent[u]=FindSet(parent[u]);
    }
    void Union(int u,int v)
    {
        if(u==v)
            return;
        if(rnk[u]>rnk[v])
            parent[v]=u;
        else if(rnk[u]<rnk[v])
            parent[u]=v;
        else
            parent[u]=v,rnk[v]++;
        return;
    }
    void kruskal()
    {
        sort(all.begin(),all.end());
        initDSU();
        int sum=0;
        vector<pair<int,int> >ans;
        for(auto edge:all)
        {
            int w=edge.first;
            int u=FindSet(edge.second.first);
            int v=FindSet(edge.second.second);
            if(FindSet(u)!=FindSet(v))
            {
                sum+=w;
                Union(u,v);
                ans.push_back(edge.second);
            }
        }
        cout<<"Kruskal's Algorithm: \n";
        cout<<sum<<'\n';
        for(auto u:ans)
        {
            cout<<u.first<<' '<<u.second<<'\n';
        }
    }
    void Prim(int root=0)
    {
        for(int i=0;i<n;i++)
        {
            rnk[i]=INF;
            processed[i]=false;
        }
        rnk[root]=0;
        parent[root]=-1;
        priority_queue<pair<int,int>> q;
        q.push({0,root});
        while(!q.empty())
        {
            int u=q.top().second,x=-q.top().first;
            q.pop();
            if(processed[u])
                continue;
            processed[u]=true;
            for(auto edge:adj[u])
            {
                int v=edge.first,w=edge.second;
                if(!processed[v]&&w<rnk[v])
                {
                    rnk[v]=w;
                    parent[v]=u;
                    q.push({-rnk[v],v});
                }
            }
        }
        int sum=0;
        for(int i=0;i<n;i++)
            sum+=rnk[i];
        cout<<"Prim's Algorithm: "<<'\n';
        cout<<"Root node= "<<root<<'\n';
        cout<<sum<<'\n';
        for(int i=0;i<n;i++)
            if(parent[i]!=-1)
                cout<<i<<' '<<parent[i]<<'\n';
    }

};
main()
{

    int provision;
    cin>>provision;
    freopen("in.txt","r",stdin);
    if(provision==1)
        freopen("out.txt","w",stdout);
    int n,m;
    cin>>n>>m;
    Graph g(n);
    for(int i=1;i<=m;i++)
    {
        int u,v,w;
        cin>>u>>v>>w;
        g.addEdge(u,v,w);
    }
    g.kruskal();
    g.Prim();
}
