#include<bits/stdc++.h>
#define RED 1
#define BLACK 0
using namespace std;
class node
{
    int key;
    int color;
    node * L;
    node * R;
    node * parent;
public:
    node(int _key,int _color)
    {
        key=_key;
        color=_color;
        L=NULL;
        R=NULL;
        parent=NULL;
    }

    ~node()
    {
        if(L) delete L;
        if(R) delete R;
        L=0;
        R=0;
        parent=0;
    }


    int getKey()
    {
        return key;
    }
    int getColor()
    {
        return color;
    }
    node * getL()
    {
        return L;
    }
    node * getR()
    {
        return R;
    }
    node * getParent()
    {
        return parent;
    }
    void setKey(int _key)
    {
        key=_key;
    }
    void setColor(int _c)
    {
        color=_c;
    }
    void setL(node * _L)
    {
        L=_L;
    }
    void setR(node * _R)
    {
        R=_R;
    }
    void setParent(node * _parent)
    {
        parent=_parent;
    }
};
class RBT
{
    node * root;
public:

    RBT()
    {
        root=NULL;
    }

    ~RBT()
    {
        if(root) delete root;
        root=NULL;
    }

    int getColor(node * x)
    {
        if(!x)
            return BLACK;
        return x->getColor();
    }
    int getKey(node * x)
    {
        if(!x)
            return -1e9;
        return x->getKey();
    }
    node * getL(node * x)
    {
        if(!x)
            return NULL;
        return x->getL();
    }
    node * getR(node * x)
    {
        if(!x)
            return NULL;
        return x->getR();
    }
    node * getParent(node * x)
    {
        if(!x)
            return NULL;
        return x->getParent();
    }
    void setColor(node * x,int c)
    {
        if(!x)
            return;
        x->setColor(c);
    }
    void setKey(node * x,int key)
    {
        if(!x)
            return;
        x->setKey(key);
    }
    void setL(node * x, node *L)
    {
        if(!x)
            return;
        x->setL(L);
    }
    void setR(node * x, node * R)
    {
        if(!x)
            return;
        x->setR(R);
    }
    void setParent(node * x,node *parent)
    {
        if(!x)
            return;
        x->setParent(parent);
    }
    bool isLeftChild(node * x)
    {
        assert(getParent(x)!=NULL);
        return getL(getParent(x))==x;
    }

    node * getUncle(node *x)
    {
        node * P = getParent(x);
        if(isLeftChild(P))
        {
            return getR(getParent(P));
        }
        else
        {
            return getL(getParent(P));
        }
    }
    node * getGrand(node * x)
    {
        return getParent(getParent(x));
    }

    void LeftRotate(node *x)
    {
        node * y=getR(x);
        setR(x,getL(y));
        setParent(getL(y),x);
        setParent(y,getParent(x));
        if(getParent(x)==NULL)
        {
            root=y;
        }
        else if(isLeftChild(x))
        {
            setL(getParent(x),y);
        }
        else
        {
            setR(getParent(x),y);
        }
        setL(y,x);
        setParent(x,y);
        return;
    }
    void RightRotate(node *x)
    {
        node * y=getL(x);
        setL(x,getR(y));
        setParent(getR(y),x);
        setParent(y,getParent(x));
        if(getParent(x)==NULL)
        {
            root=y;
        }
        else if(isLeftChild(x))
        {
            setL(getParent(x),y);
        }
        else
        {
            setR(getParent(x),y);
        }
        setR(y,x);
        setParent(x,y);
        return;
    }

    void Insert_fixup(node * z)
    {
        while(getColor(getParent(z))==RED)
        {
            node * uncle= getUncle(z);
            node * g=getGrand(z);
            node * parent=getParent(z);

            if(isLeftChild(parent))
            {

                if(getColor(uncle)==RED) //CASE 1
                {
                    setColor(uncle,BLACK);
                    setColor(parent,BLACK);
                    setColor(g,RED);
                    z=g;
                }
                else if(getColor(uncle)==BLACK&&!isLeftChild(z)) //CASE 2
                {
                    z=parent;
                    LeftRotate(z);
                }
                else
                {
                    setColor(parent,BLACK);
                    setColor(g,RED);
                    RightRotate(g);
                    break;
                }
            }
            else
            {
                if(getColor(uncle)==RED)
                {
                    setColor(uncle,BLACK);
                    setColor(parent,BLACK);
                    setColor(g,RED);
                    z=g;
                }
                else if(getColor(uncle)==BLACK&&isLeftChild(z))
                {
                    z=parent;
                    RightRotate(z);
                }
                else
                {
                    setColor(parent,BLACK);
                    setColor(g,RED);
                    LeftRotate(g);
                    break;
                }
            }
        }
        setColor(root,BLACK);
    }

    void Insert(node * z)
    {
        if(!root)
        {
            root=z;
            setColor(root,BLACK);
            return;
        }
        node * now = root;
        node * last= NULL;
        while(true)
        {
            if(now==NULL)
                break;
            last=now;
            if(getKey(now) > getKey(z))
                now=getL(now);
            else
                now=getR(now);
        }
        if(getKey(last)> getKey(z))
        {
            setL(last,z);
            setParent(z,last);
        }
        else
        {
            setR(last,z);
            setParent(z,last);
        }
        Insert_fixup(z);
        return;
    }
    char toChar(int c)
    {
        if(c==BLACK)
            return 'b';
        else
            return 'r';
    }
    node * getRoot()
    {
        return root;
    }
    void Print(node * now)
    {
        if(now==NULL)
            return;
        cout<<getKey(now)<<":"<<toChar(getColor(now));
        if(getL(now)==NULL&&getR(now)==NULL)
            return;
        cout<<"(";
        Print(getL(now));
        cout<<")";
        cout<<"(";
        Print(getR(now));
        cout<<")";
        return;
    }
    node * Search(int key)
    {
        node * now=root;
        while(now!=NULL)
        {
            if(getKey(now)==key) return now;
            if(getKey(now)<key) now=getR(now);
            else now=getL(now);
        }
        return NULL;
    }

    bool Find(int key)
    {
        return Search(key)!=NULL;
    }

    node * InorderSuccessor(node * x) //Only in subtree and no child is NULL
    {
        x=getR(x);
        while(true)
        {
            if(getL(x)==NULL) return x;
            x=getL(x);
        }
    }

    void Delete(int key)
    {
        node * z=Search(key);
        assert(z!=NULL);
        node * y;
        if(getL(z)==NULL||getR(z)==NULL)
            y=z;
        else
            y=InorderSuccessor(z);
        node * x;
        if(getL(y)!=NULL)
            x=getL(y);
        else x=getR(y);
        setParent(x,getParent(y));

        if(getParent(y)==NULL)
            root=x; //Can be NULL
        else if(isLeftChild(y))
            setL(getParent(y),x);
        else
            setR(getParent(y),x);
        if(y!=z)
            setKey(z,getKey(y));

        if(getColor(y)==BLACK)
            Delete_fixup(x,getParent(y));
        return;
    }
    void Delete_fixup(node * x, node *parent) // No use of getParent(x)
    {
        node * w;
        while(getColor(x)==BLACK && x!=root)
        {
            if(getL(parent)==x) //Left Child
            {
                w=getR(parent);
                if(getColor(w)==RED)
                {
                    setColor(w,BLACK);
                    setColor(parent,RED);
                    LeftRotate(parent);
                }
                else if(getColor(getL(w))==BLACK&&getColor(getR(w))==BLACK)
                {
                    setColor(w,RED);
                    x=parent;
                    parent=getParent(parent);
                }
                else if(getColor(getL(w))==RED&&getColor(getR(w))==BLACK)
                {
                    setColor(getL(w),BLACK);
                    setColor(w,RED);
                    RightRotate(w);
                }
                else
                {
                    setColor(w,getColor(parent));
                    setColor(parent,BLACK);
                    setColor(getR(w),BLACK);
                    LeftRotate(parent);
                    x=root;
                    parent=NULL;
                }
            }
            else
            {
                w=getL(parent);
                if(getColor(w)==RED)
                {
                    setColor(w,BLACK);
                    setColor(parent,RED);
                    RightRotate(parent);
                }
                else if(getColor(getL(w))==BLACK&&getColor(getR(w))==BLACK)
                {
                    setColor(w,RED);
                    x=parent;
                    parent=getParent(parent);
                }
                else if(getColor(getR(w))==RED&&getColor(getL(w))==BLACK)
                {
                    setColor(getR(w),BLACK);
                    setColor(w,RED);
                    LeftRotate(w);
                }
                else
                {
                    setColor(w,getColor(parent));
                    setColor(parent,BLACK);
                    setColor(getL(w),BLACK);
                    RightRotate(parent);
                    x=root;
                    parent=NULL;
                }
            }
        }
        setColor(x,BLACK);
    }

};
main()
{
    freopen("input.txt","r",stdin);
    RBT tree;
    char c;
    int key;
    while(cin>>c>>key)
    {
        if(c=='I')
        {
            node * z=new node(key,RED);
            tree.Insert(z);
            tree.Print(tree.getRoot());
            cout<<"\n";
        }
        else if(c=='F')
        {
            if(tree.Find(key)) cout<<"True\n";
            else cout<<"False\n";
        }
        else if(c=='D')
        {
            tree.Delete(key);
            tree.Print(tree.getRoot());
            cout<<'\n';
        }
    }
    return 0;
}
