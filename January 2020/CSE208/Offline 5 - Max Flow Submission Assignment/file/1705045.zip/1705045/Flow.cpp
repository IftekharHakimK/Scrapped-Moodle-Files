#include<bits/stdc++.h>
using namespace std;

class List
{
    int * a;
    int * w;
    int cur,alloc;
public:
    List()
    {
        cur=0;
        alloc=2;
        a=new int [alloc];
        w=new int[alloc];
    }

    ~List()
    {
        cur=0,alloc=0;
        delete[] a;
        delete[] w;
    }

    void Insert(int _a,int _w)
    {
        if(cur==alloc)
        {
            int * temp;
            alloc*=2;

            temp=new int[alloc];
            for(int i=0; i<cur; i++)
                temp[i]=a[i];
            delete[] a;
            a=temp;

            int *temp2=new int[alloc];
            for(int i=0;i<cur;i++)
                temp2[i]=w[i];
            delete[] w;
            w=temp2;
        }
        a[cur]=_a;
        w[cur]=_w;
        cur++;
    }
    int Size()
    {
        return cur;
    }
    bool IsEmpty()
    {
        return cur==0;
    }
    int ItemAt(int idx)
    {
        if(idx<cur)
            return a[idx];
        else
            return INT_MIN;
    }
    int weightAt(int idx)
    {
        if(idx<cur)
            return w[idx];
        else
            return INT_MIN;
    }

    void updateWeight(int idx,int change)
    {
        if(idx<cur)
        {
            w[idx]+=change;
        }
        return;
    }

};

class Graph // Directed
{
    int n;
    List * adj;
    List * init;
    int * parent;
    int * mn;
public:
    Graph(int _n)
    {
        n=_n;
        adj=new List[n];
        init=new List[n];
        parent=new int[n];
        mn=new int[n];
    }

    ~Graph()
    {
        delete[] adj;
        delete[] init;
        delete[] parent;
        delete[] mn;
    }

    void addEdge(int a,int b,int w)
    {
        adj[a].Insert(b,w); // will be updated
        init[a].Insert(b,w);
        return;
    }

    int bfs(int source,int sink)
    {
        for(int i=0; i<n; i++)
            parent[i]=-1,mn[i]=0;
        mn[source]=1e7;
        parent[source]=source;
        queue<int>q;
        q.push(source);
        while(!q.empty())
        {
            int u=q.front();
            q.pop();
            for(int i=0; i<adj[u].Size(); i++)
            {
                int v=adj[u].ItemAt(i), w=adj[u].weightAt(i);
                if(parent[v]==-1&&w>0)
                {
                    parent[v]=u;
                    mn[v]=min(mn[u],w);
                    q.push(v);
                }
            }
        }
        return mn[sink];
    }

    int EdmondKarp(int source,int sink)
    {
        int ans=0;
        while(true)
        {
            int now=bfs(source,sink);
            if(!now)
                break;
            ans+=now;
            int last=sink;

            while(last!=source)
            {
                int u=parent[last], v=last;

                //decreasing residue (u,v)
                bool done=false;
                for(int i=0;i<adj[u].Size();i++)
                {
                    if(adj[u].ItemAt(i)==v)
                    {
                        adj[u].updateWeight(i,-now);
                        done=true;
                        break;
                    }
                }
                if(!done) adj[u].Insert(v,-now);

                //increasing residue (v,u)
                done=false;
                for(int i=0;i<adj[v].Size();i++)
                {
                    if(adj[v].ItemAt(i)==u)
                    {
                        adj[v].updateWeight(i,now);
                        done=true;
                        break;
                    }
                }
                if(!done) adj[v].Insert(u,now);

                last=u;
            }
        }
        return ans;
    }
    void findFlow(int source,int sink)
    {
        cout<<EdmondKarp(source,sink)<<'\n';

        for(int u=0;u<n;u++)
        {
            for(int i=0;i<init[u].Size();i++)
            {
                int v=init[u].ItemAt(i),w1=init[u].weightAt(i);
                int w2=adj[u].weightAt(i);
                assert(v==adj[u].ItemAt(i));
                int flow=w1-w2;
                flow=max(0,flow);
                flow=min(w1,flow);
                cout<<u<<' '<<v<<' '<<flow<<'/'<<w1<<'\n';
            }
        }

    }
};


main()
{
    int provision;
    cin>>provision;
    if(provision) freopen("output.txt","w",stdout);
    freopen("input.txt","r",stdin);
    int n,m;
    cin>>n>>m;
    Graph g(n);
    for(int i=0; i<m; i++)
    {
        int a,b,w;
        cin>>a>>b>>w;
        g.addEdge(a,b,w);
    }
    int source,sink;
    cin>>source>>sink;
    g.findFlow(source,sink);
}

/*
11 13
0 1 20
1 2 20
2 3 20
0 4 30
4 5 30
5 6 30
6 7 30
7 2 30
2 1 10
1 8 30
8 9 30
9 10 30
10 3 30
0 3
*/
