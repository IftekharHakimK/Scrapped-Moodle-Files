#include<bits/stdc++.h>
#define INIT 2
#define ll long long
const int INF=2e8;
using namespace std;
class XY
{
public:
    int x,y;
    XY()
    {
        ;
    }
    XY(int _x,int _y)
    {
        x=_x;
        y=_y;
    }
};
class pq
{
    XY *a;
    int cap,sz;
public:
    pq()
    {
        a=new XY[2];
        cap=2;
        sz=0;
    }
    bool empty()
    {
        return sz==0;
    }
    ~pq()
    {
        if(a)
            delete[] a;
        a=0;
    }
    void Insert(XY key)
    {
        if(sz+1>cap)
        {
            XY *temp;
            cap*=2;
            temp=new XY[cap];
            for(int i=0; i<sz; i++)
                temp[i]=a[i];
            delete[] a;
            a=temp;
        }
        a[sz]=key;
        heapifyUp(sz);
        sz++;
    }
    XY FindMin()
    {
        if(sz>0)
            return a[0];
        else
        {
            exit(0);
        }
    }
    XY ExtractMin()
    {
        if(sz>0)
        {
            XY ret=a[0];
            a[0]=a[sz-1];
            sz--;
            heapifyDown(0);
            return ret;
        }
        else exit(0);
    }
    inline int parent(int idx)
    {
        return (idx%2==0)?idx/2-1:idx/2;
    }
    void swp(XY *x,XY* y)
    {
        XY t=*x;
        *x=*y;
        *y=t;
    }
    void heapifyUp(int idx)
    {
        if(idx==0||a[idx].x>=a[parent(idx)].x)
            return;
        swp(&a[idx],&a[parent(idx)]);
        heapifyUp(parent(idx));
    }
    void heapifyDown(int idx)
    {
        int small=idx;
        if(2*idx+1<sz&&a[2*idx+1].x<a[small].x)
            small=2*idx+1;
        if(2*idx+2<sz&&a[2*idx+2].x<a[small].x)
            small=2*idx+2;
        if(small!=idx)
        {
            swp(&a[idx],&a[small]);
            heapifyDown(small);
        }
    }
};
class ArrayList
{
    int currentSize,allocSize;
    int *all;

public:

    ArrayList()
    {
        currentSize=0;
        allocSize=INIT;
        all=new int[allocSize];
    }
    ~ArrayList()
    {
        currentSize=allocSize=0;
        if(all)
            delete[] all;
        all=0;
    }
    void insertItem(int item)
    {
        if(currentSize==allocSize)
        {
            allocSize*=2;
            int *temp;
            temp=new int[allocSize];
            for(int i=0; i<currentSize; i++)
                temp[i]=all[i];
            delete[] all;
            all=temp;
        }
        all[currentSize++]=item;
        return;
    }
    int getItem(int pos) // **0-indexed
    {
        if(pos<0||pos>=currentSize)
            return INT_MAX;
        return all[pos];
    }
    int getLength()
    {
        return currentSize;
    }
};

class Graph
{
    int n;
    ArrayList *e;
    ArrayList *weight;
    int *distance;
    int *parent;
    bool *pro;

public:

    Graph()
    {
        e=0;
        weight=0;
        distance=0;
        parent=0;
        pro=0;
    }
    ~Graph()
    {
        n=0;
        if(e)
            delete[] e;
        if(weight)
            delete[] weight;
        if(distance)
            delete[] distance;
        if(parent)
            delete[] parent;
        if(pro)
            delete[] pro;
        e=0;
        weight=0;
        distance=0;
        parent=0;
        pro=0;
    }
    void setnVertices(int _n)
    {
        n=_n;
        e=new ArrayList[n];
        weight=new ArrayList[n];
        distance=0;
    }
    void addEdge(int u,int v,int w)
    {
        e[u].insertItem(v);
        weight[u].insertItem(w);
    }
    void print(int node,int s)
    {
        if(node==s)
        {
            cout<<node;
            return ;
        }
        print(parent[node],s);
        cout<<" -> "<<node;
    }
    void dijkstra(int s,int d)
    {
        cout<<"Dijkstra Algorithm: \n";
        pq q;

        if(distance)
            delete[] distance;
        if(pro)
            delete[] pro;
        if(parent)
            delete[] parent;

        distance=0;
        pro=0;
        parent=0;
        distance=new int[n];
        parent=new int[n];
        pro=new bool[n];

        for(int i=0; i<n; i++)
            distance[i]=INF,pro[i]=0;
        distance[s]=0;
        q.Insert(XY(0,s));
        while(!q.empty())
        {
            XY cur=q.FindMin();
            int curNode=cur.y,disNode=cur.x;
            q.ExtractMin();
            if(pro[curNode])
                continue;
            pro[curNode]=1;
            for(int i=0; i<e[curNode].getLength(); i++)
            {
                int b=e[curNode].getItem(i);
                int w=abs(weight[curNode].getItem(i));
                if(distance[curNode]+w<distance[b])
                {
                    distance[b]=distance[curNode]+w;
                    parent[b]=curNode;
                    q.Insert({distance[b],b});
                }
            }
        }
        int ans=distance[d];
        cout<<ans<<'\n';
        if(ans==INF)
        {
            cout<<"Source and Destination are not connected\n";
            return;
        }
        print(d,s);
        cout<<'\n';
    }
    void BellmanFord(int s,int d)
    {
        cout<<"Bellman Ford Algorithm: \n";
        if(distance)
            delete[] distance;
        if(parent)
            delete[] parent;
        distance=0;
        parent=0;
        distance=new int[n];
        parent=new int[n];
        for(int i=0; i<n; i++)
            distance[i]=INF;
        distance[s]=0;
        for(int round=1; round<=n-1; round++)
        {
            for(int node=0; node<n; node++)
            {
                for(int j=0; j<e[node].getLength(); j++)
                {
                    int b=e[node].getItem(j);
                    int w=weight[node].getItem(j);
                    if(distance[b]>distance[node]+w)
                    {
                        distance[b]=distance[node]+w;
                        parent[b]=node;
                    }
                }
            }
        }
        for(int node=0; node<n; node++)
        {
            for(int j=0; j<e[node].getLength(); j++)
            {
                int b=e[node].getItem(j);
                int w=weight[node].getItem(j);
                if(distance[node]+w<distance[b])
                {
                    cout<<"Negative Cycle\n";
                    return;
                }
            }
        }
        cout<<distance[d]<<'\n';
        print(d,s);
        cout<<'\n';
    }
};
main()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    Graph *g;
    int n,m;
    cin>>n>>m;
    g->setnVertices(n);
    for(int i=0; i<m; i++)
    {
        int a,b,w;
        cin>>a>>b>>w;
        g->addEdge(a,b,w);
    }
    int s,d;
    cin>>s>>d;
    g->BellmanFord(s,d);
    g->dijkstra(s,d);

}
