#include<bits/stdc++.h>
#define ll long long
#define dbg(x) cout<<#x<<": "<<x<<endl;
#define N 1700
using namespace std;
using namespace chrono;

struct Comparator {
    bool operator()(tuple<double,bitset<N>,int> & p1, tuple<double,bitset<N>,int> &  p2)
    {
        return get<0>(p1) < get<0>(p2);
    }
};

struct TSP
{
    int n;
    double ** adj;
    double * minOut;
    TSP(int _n)
    {
        n=_n;
        adj=new double*[n];
        for(int i=0;i<n;i++)
        {
            adj[i]=new double[n];
            for(int j=0;j<n;j++)
            {
                adj[i][j]=1e9;
            }
        }
        minOut=new double[n];
        for(int i=0;i<n;i++)
        {
            minOut[i]=1e9;
        }
    }
    void addEdge(int a,int b,double w)
    {
        adj[a][b]=w;
        minOut[a]=min(minOut[a],w);
        return;
    }
    double solve()
    {
        //Starting from 0
        double temp=0;
        for(int i=0;i<n;i++)
        {
            temp+=minOut[i];
        }

        priority_queue<tuple<double,bitset<N>,int>,vector<tuple<double,bitset<N>,int>>,Comparator>pq; //Lower Bound, mask(visited), node
        pq.push(make_tuple(temp,1,0));

        double ans=1e18;
        int cnt=0;

        while(!pq.empty()&&cnt<=1e6)
        {
            cnt++;
            auto least=pq.top();
            pq.pop();
            ll cost=get<0>(least);
            bitset<N> mask=get<1>(least);
            ll node=get<2>(least);

            if(cost>ans)
            {
                break;
            }
            //cout<<mask.count()<<' '<<node<<endl;

            if(mask.count()==n)
            {
                double temp=cost+adj[node][0]-minOut[node];
                ans=min(ans,temp);
                continue;
            }

            for(int i=0;i<n;i++)
            {
                if(mask[i]==0)
                {
                    ll bound=cost+adj[node][i]-minOut[node];
                    if(bound<ans)
                    {
                        mask[i]=1;
                        pq.push(make_tuple(bound,mask,i));
                        mask[i]=0;
                    }
                }
            }
        }
        return ans;
    }

    double exact()
    {
        vector<int>all;
        for(int i=0;i<n;i++) all.push_back(i);

        double ans=1e18;
        vector<int>x;

        do
        {
            double temp=0;
            for(int i=1;i<n;i++)
            {
                temp+=adj[all[i-1]][all[i]];
            }
            temp+=adj[all[n-1]][all[0]];
            ans=min(ans,temp);
            if(ans==temp)
                x=all;
        }while(next_permutation(all.begin(),all.end()));
        return ans;
    }

};



main()
{

    freopen("wi29.tsp","r",stdin);

    int n;
    cin>>n;
    cout<<"# of cities "<<n<<endl;
    double x[n],y[n];

    for(int i=1;i<=n;i++)
    {
        int r;
        cin>>r;
        r--;
        cin>>x[r]>>y[r];
    }
    TSP tsp(n);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            tsp.addEdge(i,j,sqrt((x[i]-x[j])*(x[i]-x[j])+(y[i]-y[j])*(y[i]-y[j])));
        }
    }

    time_point<system_clock> start, finish;

    start=system_clock::now();
    double ans=tsp.solve();
    finish=system_clock::now();

    cout<<setprecision(7)<<"Pruning solution: "<<ans<<'\n';
    cout<<"Took "<<duration_cast<milliseconds>(finish - start).count()<<endl;
}


