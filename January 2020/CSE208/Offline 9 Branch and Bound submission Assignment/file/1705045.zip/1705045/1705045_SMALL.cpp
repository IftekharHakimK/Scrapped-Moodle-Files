#include<bits/stdc++.h>
#define ll long long
#define dbg(x) cout<<#x<<": "<<x<<endl;
using namespace std;
using namespace chrono;

struct TSP
{
    int n;
    double ** adj;
    double * minOut;
    TSP(int _n)
    {
        n=_n;
        adj=new double*[n];
        for(int i=0;i<n;i++)
        {
            adj[i]=new double[n];
            for(int j=0;j<n;j++)
            {
                adj[i][j]=1e9;
            }
        }
        minOut=new double[n];
        for(int i=0;i<n;i++)
        {
            minOut[i]=1e9;
        }
    }
    void addEdge(int a,int b,double w)
    {
        adj[a][b]=w;
        minOut[a]=min(minOut[a],w);
        return;
    }
    double solve()
    {
        //Starting from 0
        double temp=0;
        for(int i=0;i<n;i++)
        {
            temp+=minOut[i];
        }
        priority_queue<tuple<double,ll,int>>pq; //Lower Bound, mask(visited), node
        pq.push(make_tuple(-temp,1,0));

        double ans=1e18;
        while(!pq.empty())
        {
            auto least=pq.top();
            pq.pop();
            ll cost=-get<0>(least);
            ll mask=get<1>(least);
            ll node=get<2>(least);

            if(cost>ans)
            {
                break;
            }

            if(mask==(1LL<<n)-1)
            {
                double temp=cost+adj[node][0]-minOut[node];
                ans=min(ans,temp);
                continue;
            }

            for(int i=0;i<n;i++)
            {
                if(!(mask&(1LL<<i)))
                {
                    ll bound=cost+adj[node][i]-minOut[node];
                    if(bound<ans)
                    {
                        pq.push(make_tuple(-bound,mask|(1LL<<i),i));
                    }
                }
            }
        }
        return ans;
    }

    double exact()
    {
        vector<int>all;
        for(int i=0;i<n;i++) all.push_back(i);

        double ans=1e18;
        vector<int>x;

        do
        {
            double temp=0;
            for(int i=1;i<n;i++)
            {
                temp+=adj[all[i-1]][all[i]];
            }
            temp+=adj[all[n-1]][all[0]];
            ans=min(ans,temp);
            if(ans==temp)
                x=all;
        }while(next_permutation(all.begin(),all.end()));
        return ans;
    }

};

main()
{
    freopen("data10.txt","r",stdin);
    string filename;
    cin>>filename;
    cout<<filename<<endl;
    int n;
    cin>>n;
    cout<<"# of cities "<<n<<endl;
    TSP tsp(n);
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n;j++)
        {
            double x;
            cin>>x;
            if(i!=j)
            {
                tsp.addEdge(i,j,x);
            }
        }
    }

    time_point<system_clock> start, finish;

    start=system_clock::now();
    double ans=tsp.solve();
    finish=system_clock::now();

    cout<<"Pruning solution: "<<ans<<'\n';
    cout<<"Took "<<duration_cast<milliseconds>(finish - start).count()<<endl;

    if(n<=12)
    {
        start=system_clock::now();
        double ans=tsp.exact();
        finish=system_clock::now();

        cout<<"Exact Solution: "<<ans<<'\n';
        cout<<"Took "<<duration_cast<milliseconds>(finish - start).count()<<endl;
    }

}

