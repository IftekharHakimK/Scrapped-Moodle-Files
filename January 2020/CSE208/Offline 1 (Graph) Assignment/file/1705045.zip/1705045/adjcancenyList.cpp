#include<bits/stdc++.h>
#define ll long long
#include <chrono>
#define INIT 2
#define dbg(x) cout<< #x <<"--> "<<x<<endl;
using namespace std;
using namespace chrono;
const int WHITE=0,GREY=1,BLACK=2,INF=INT_MAX;
class Queue
{
    int frnt,rear;
    int currentSize,allocSize;
    int *all;
public:

    Queue()
    {
        currentSize=0;
        allocSize=2;
        all=new int[allocSize];
        frnt=rear=0;
    }
    ~Queue()
    {
        frnt=rear=currentSize=allocSize=0;
        if(all)
            delete[] all;
        all=0;
    }
    void enqueue(int item)
    {
        if(currentSize==allocSize)
        {
            int *temp;
            allocSize*=2;
            temp=new int[allocSize];
            int p=0;
            for(int i=rear; i<currentSize; i++)
                temp[p++]=all[i];
            for(int i=0; i<rear; i++)
                temp[p++]=all[i];
            delete[] all;
            all= temp;
            frnt=currentSize;
            rear=0;
        }
        all[frnt]=item;
        currentSize++;
        frnt=(++frnt)%allocSize;
        //display();
        return;
    }

    int dequeue()
    {
        if(currentSize==0)
        {
            return INT_MAX;
        }
        int item=all[rear];
        currentSize--;
        rear=(++rear)%allocSize;
        return item;
    }
    bool empty()
    {
        return currentSize==0;
    }
    int size()
    {
        return currentSize;
    }
    void display()
    {
        dbg(currentSize);
        dbg(frnt);
        dbg(rear);
        for(int i=0; i<allocSize; i++)
            cout<<all[i]<<' ';
        cout<<'\n';
    }
};
class ArrayList
{
    int currentSize,allocSize;
    int *all;
public:

    ArrayList()
    {
        currentSize=0;
        allocSize=INIT;
        all=new int[allocSize];
    }
    ~ArrayList()
    {
        currentSize=allocSize=0;
        if(all)
            delete[] all;
        all=0;
    }
    void insertItem(int item)
    {
        if(currentSize==allocSize)
        {
            allocSize*=2;
            int *temp;
            temp=new int[allocSize];
            for(int i=0; i<currentSize; i++)
                temp[i]=all[i];
            delete[] all;
            all=temp;
        }
        all[currentSize++]=item;
        return;
    }
    int searchItem(int item)
    {
        for(int i=0; i<currentSize; i++)
        {
            if(all[i]==item)
                return i; // *returning first occurrence
        }
        return -1; //it means it does not appear
    }
    void removeItem(int item)
    {
        if(currentSize==0)
            return;
        int idx=searchItem(item);
        if(idx!=-1)
        {
            all[idx]=all[--currentSize];
        }
        return;
    }
    void removeItemAt(int pos)
    {
        if(pos<0||pos>=currentSize)
            return;
        all[pos]=all[--currentSize];
    }
    int getItem(int pos) // **0-indexed
    {
        if(pos<0||pos>=currentSize)
            return INT_MAX;
        return all[pos];
    }
    int getLength()
    {
        return currentSize;
    }
    bool empty()
    {
        return currentSize==0;
    }
    void printList()
    {
        dbg(currentSize);//dbg(allocSize);
        for(int i=0; i<currentSize; i++)
            cout<<all[i]<<' ';
        cout<<'\n';
    }
};

class Graph
{
    int n;
    int dir;//dir=0 if undirected
    ArrayList *e;
    int * inDegs;
    int *parent;
    int *color;
    int *distance;

public:

    Graph(int _dir=0)
    {
        dir=_dir;
        e=0;
        inDegs=parent=color=distance=0;
    }
    ~Graph()
    {
        n=dir=0;
        if(e)
            delete[] e;
        if(inDegs)
            delete[] inDegs;
        if(parent)
            delete[] parent;
        if(color)
            delete[] color;
        if(distance)
            delete[] distance;
        e=0;
        inDegs=parent=color=distance=0;
    }
    void setnVertices(int _n)
    {
        n=_n;
        e=new ArrayList[n];
        inDegs=new int[n];
        parent=color=distance=0;
        memset(inDegs,0,sizeof inDegs);
    }
    bool addEdge(int u,int v)
    {
        if(e[u].searchItem(v)!=-1)
        {
            return false;
        }
        e[u].insertItem(v);
        inDegs[v]++;
        if(!dir)
            e[v].insertItem(u);
        return true;
    }
    void printGraph()
    {
        for(int i=0; i<n; i++)
        {
            cout<<"Adj List for node: "<<i<<'\n';
            e[i].printList();
        }
        return;
    }
    void removeEdge(int u,int v)
    {
        if(e[u].searchItem(v)==-1)
        {
            return;
        }
        e[u].removeItem(v);
        inDegs[v]--;
        if(!dir)
            e[v].removeItem(u);
        return;
    }
    bool isEdge(int u,int v)
    {
        return e[u].searchItem(v)!=-1;
    }
    int getOutDegree(int u)
    {
        return e[u].getLength();
    }
    int getInDegree(int u)
    {
        if(!dir)
            return e[u].getLength();
        else
        {
            return inDegs[u];
        }
    }
    bool hasCommonAdjacent(int u, int v)
    {
        for(int i=0; i<e[u].getLength(); i++)
        {
            if(e[v].searchItem(e[u].getItem(i))!=-1)
                return true;
        }
        return false;
    }
    void bfs(int source,int cmnt=1)// when taking stat cmnt should be 0
    {
        if(source<0||source>=n)
            return;

        if(distance)
            delete[] distance;
        if(color)
            delete[] color;
        if(parent)
            delete[] parent;
        distance=color=parent=0;
        color=new int[n];
        distance=new int[n];
        parent=new int[n];
        for(int i=0; i<n; i++)
        {
            color[i]=WHITE;
            distance[i]=INF;
            parent[i]=-1;
        }
        Queue q;
        q.enqueue(source);
        distance[source]=0;
        parent[source]=-1;
        color[source]=GREY;
        if(cmnt)
            cout<<"Starting bfs from "<<source<<'\n';
        while(!q.empty())
        {
            int now=q.dequeue();
            for(int i=0; i<e[now].getLength(); i++)
            {
                int s=e[now].getItem(i);

                if(color[s]==WHITE)
                {
                    color[s]=GREY;
                    if(cmnt)
                        cout<<"Discovered "<<s<<'\n';
                    distance[s]=distance[now]+1;
                    parent[s]=now;
                    q.enqueue(s);
                }
            }
            color[now]=BLACK;
        }
        return;
    }
    void visit(int node,int cmnt)
    {
        if(cmnt)
            cout<<"Discovered "<<node<<'\n';
        color[node]=GREY;
        int u;
        for(int i=0; i<e[node].getLength(); i++)
        {
            u=e[node].getItem(i);
            if(color[u]==WHITE)
            {
                parent[u]=node;
                visit(u,cmnt);
            }
        }
        color[node]=BLACK;
        return;
    }
    void dfs(int source,int cmnt=1)
    {
        if(source<0||source>=n)
            return;
        if(color)
            delete[] color;
        if(parent)
            delete[] parent;
        color=new int[n];
        parent=new int[n];
        for(int i=0; i<n; i++)
        {
            color[i]=WHITE;
            parent[i]=-1;
        }
        visit(source,cmnt);
    }
    int getDist(int u,int v)
    {
        bfs(u,0);
        return distance[v];
    }
};


main()
{
    srand(time(0));
    Graph *g;
    g=0;
    while(true)
    {
        cout<<" 1: Initialize Graph  2: Add edge\n";
        cout<<" 3: Print Graph       4: Remove edge\n";
        cout<<" 5: IsEdge            6: Has common adjacent\n";
        cout<<" 7: Indegree          8: Outdegree\n";
        cout<<" 9: Run bfs          10: Run dfs\n";
        cout<<"11: Get distance     12: Build random for stat\n";
        cout<<"13: End\n";
        int ch;
        cin>>ch;
        if(ch==1)
        {
            int n,dir;
            cout<<"No. of vertices: ";
            cin>>n;
            cout<<"Directed(1) or Undirected(0): ";
            cin>>dir;
            g=new Graph(dir);
            g->setnVertices(n);
        }
        else if(ch==2)
        {
            int u,v;
            cin>>u>>v;
            g->addEdge(u,v);
        }
        else if(ch==3)
        {
            g->printGraph();
        }
        else if(ch==4)
        {
            int u,v;
            cin>>u>>v;
            g->removeEdge(u,v);
        }
        else if(ch==5)
        {
            int u,v;
            cin>>u>>v;
            cout<<(g->isEdge(u,v)?"YES":"NO")<<'\n';
        }
        else if(ch==6)
        {
            int u,v;
            cin>>u>>v;
            cout<<(g->hasCommonAdjacent(u,v)?"YES":"NO")<<'\n';
        }
        else if(ch==7)
        {
            int u;
            cin>>u;
            cout<<g->getInDegree(u)<<'\n';
        }
        else if(ch==8)
        {
            int u;
            cin>>u;
            cout<<g->getOutDegree(u)<<'\n';
        }
        else if(ch==9)
        {
            int s;
            cout<<"Source: ";
            cin>>s;
            g->bfs(s,1);
        }
        else if(ch==10)
        {
            int s;
            cout<<"Source: ";
            cin>>s;
            g->dfs(s,1);
        }
        else if(ch==11)
        {
            int u,v;
            cout<<"From: ";
            cin>>u;
            cout<<"To: ";
            cin>>v;
            cout<<g->getDist(u,v)<<'\n';
        }
        else if(ch==12) //Stat checking and it is done for undirected only
        {
            for(int n=1000; n<=16000; n*=2)
            {
                for(ll edges=n; edges<=(1LL*n*n-n)/8; edges*=2)
                {
                    if(g)
                    {
                        delete g;
                        g=0;
                    }
                    g=new Graph(0);
                    g->setnVertices(n);
                    ll i=0;
                    while(i<edges)
                    {
                        int a=rand()%n,b=rand()%n;
                        if(a!=b&&!g->isEdge(a,b))
                        {
                            g->addEdge(a,b);
                            i++;
                        }
                    }
                    //cout<<"b"<<endl;
                    double sum=0;
                    int sample=min(1000LL,(10000000LL/(n+edges))+1);
                    for(int i=0;i<sample;i++)
                    {
                        int a=rand()%n;
                        auto start=high_resolution_clock::now();
                        g->bfs(a,0);
                        auto finish=high_resolution_clock::now();
                        auto gap=duration_cast<nanoseconds>(finish-start).count();
                        sum+=gap;
                    }
                    cout<<setprecision(5)<<"Nodes: "<<n<<" Edges: "<<edges<<" Avg.Time: "<<sum/sample<<'\n';
                }
            }


        }
        else if(ch==13)
            break;


    }

}
