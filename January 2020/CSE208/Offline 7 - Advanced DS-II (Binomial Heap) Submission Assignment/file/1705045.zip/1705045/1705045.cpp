#include<bits/stdc++.h>
using namespace std;
class Node
{
    int value;
    Node * parent;
    vector<Node*> children; // In ascending order of degree
public:
    Node(int _value)
    {
        value=_value;
        parent=0;
    }
    ~Node()
    {
        parent=0;
        for(Node * node: children)
            delete node;
        children.clear();
    }
    void setValue(int _value)
    {
        value=_value;
        return;
    }
    void setParent(Node * node)
    {
        parent=node;
        return;
    }
    void insertNewChild(Node * node)
    {
        children.push_back(node);
        return;
    }
    int getValue()
    {
        return value;
    }
    int getK()
    {
        return children.size();
    }
    vector<Node*> getChildren()
    {
        return children;
    }
};

class Heap
{
    vector<Node*> roots; // in ascending order of degree
public:
    Heap()
    {
        ;
    }
    Heap(Node * node)
    {
        roots.push_back(node);
    }
    Heap(vector<Node*> & v)
    {
        roots=v;
    }
    ~Heap()
    {
        for(Node * node:roots)
            delete node;
        roots.clear();
    }
    vector<Node*> getRoots()
    {
        return roots;
    }
    void Union(Heap * h1)
    {
        vector<Node*> v2=h1->getRoots();
        vector<Node*> temp;
        Node * carry=NULL;

        int i=0,j=0;
        int cur=0;

        while(i<roots.size()||j<v2.size()||(carry!=NULL))
        {
            Node * a=NULL;
            Node * b=NULL;
            if(i<roots.size()&&roots[i]->getK()==cur)
            {
                a=roots[i];
                i++;
            }
            if(j<v2.size()&&v2[j]->getK()==cur)
            {
                b=v2[j];
                j++;
            }
            int sum=(a!=NULL)+(b!=NULL)+(carry!=NULL);
           // dbg(sum);
            if(sum==3)
            {
                if(a->getValue()>b->getValue())
                    swap(a,b);
                a->insertNewChild(b);
                b->setParent(a);
                temp.push_back(carry);

                carry=a;
            }
            else if(sum==2)
            {
                if(a==NULL)
                    a=carry;
                if(b==NULL)
                    b=carry;

                if(a->getValue()>b->getValue())
                    swap(a,b);
                a->insertNewChild(b);
                b->setParent(a);
                carry=a;
            }
            else if(sum==1)
            {
                if(b!=NULL)
                    a=b;
                else if(carry!=NULL)
                    a=carry;
                temp.push_back(a);
                carry=NULL;
            }
            cur++;
        }
        roots=temp;
        return;
    }
    Node * findMin()
    {
        if(roots.size()==0)
            return NULL;

        Node * ans=roots[0];
        for(int i=1;i<roots.size();i++)
        {
            if(roots[i]->getValue() < ans->getValue())
            {
                ans=roots[i];
            }
        }
        return ans;
    }


    Node * extractMin()
    {
        if(roots.size()==0)
            return NULL;
        Node * ans=findMin();
        vector<Node*>temp;

        for(int i=0;i<roots.size();i++)
        {
            if(roots[i]==ans)
            {
                for(int j=i+1;j<roots.size();j++) temp.push_back(roots[j]);
                break;
            }
            temp.push_back(roots[i]);
        }
        roots=temp;

        vector<Node*>leftChildren=ans->getChildren();
        for(Node* node:leftChildren)
        {
            node->setParent(NULL);
        }
        Heap * h1= new Heap(leftChildren);
        Union(h1);
        return ans;
    }

    void Insert(Node * w)
    {
        Heap * h1=new Heap(w);
        Union(h1);
        return;
    }

    void Print()
    {
        cout<<"Printing Binomial Heap...\n";
        for(Node* root:roots)
        {
            cout<<"Binomial Tree, B"<<root->getK()<<'\n';
            vector<Node*>currentLevel,nextLevel;
            currentLevel.push_back(root);
            for(int level=0;level<=root->getK();level++)
            {
                cout<<"Level "<<level<<" : ";
                for(Node * node:currentLevel)
                {
                    cout<<node->getValue()<<' ';

                    vector<Node*>temp=node->getChildren();
                    reverse(temp.begin(),temp.end());
                    for(Node * child: temp)
                        nextLevel.push_back(child);
                }
                cout<<'\n';

                currentLevel=nextLevel;
                nextLevel.clear();
            }
        }
        return;
    }

};
main()
{

    int provision;
    cin>>provision;
    if(provision)
        freopen("output.txt","w",stdout);
    freopen("in0.txt","r",stdin);
    Heap h;
    char op;
    while(cin>>op)
    {
        if(op=='I')
        {
            int x;
            cin>>x;
            h.Insert(new Node(x));
        }
        else if(op=='F')
        {
            Node * ans=h.findMin();
            cout<<"Find-Min returned "<<ans->getValue() <<'\n';
        }
        else if(op=='E')
        {
            Node * ans=h.extractMin();
            cout<<"Extract-Min returned "<< ans->getValue() <<'\n';
        }
        else if(op=='U')
        {
            string s;
            getline(cin,s);
            istringstream st(s);

            Heap * temp=new Heap();

            int x;
            while(st>>x)
            {
                temp->Insert(new Node(x));
            }
            h.Union(temp);
        }
        else if(op=='P')
        {
            h.Print();
        }
    }
}
