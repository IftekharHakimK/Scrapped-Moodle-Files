import os
import socket
import f2_1705045 as RSA
import f1_1705045 as AES

if __name__=="__main__":
    rec_sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    rec_sock.connect(("127.0.0.1",8080))
    
    choice=rec_sock.recv(4096).decode('utf-8')
    rec_sock.send(str('ACK Choice').encode())

    if choice.lower()=='file':
        filename=rec_sock.recv(4096).decode('utf-8')
        rec_sock.send(str('ACK Filename').encode())

    cipher_text=rec_sock.recv(20*4096).decode('utf-8')
    rec_sock.send(str('ACK cipher text').encode())
    e=rec_sock.recv(4096).decode('utf-8')
    rec_sock.send(str('ACK e').encode())
    n=rec_sock.recv(4096).decode('utf-8')
    rec_sock.send(str('ACK n').encode())
    encrypted_key=eval(rec_sock.recv(4096).decode('utf-8'))
    rec_sock.send(str('ACK encrypted_key').encode())

    # print(cipher_text)
    # print(e)
    # print(n)
    # print(encrypted_key)

    dir=os.getcwd()
    dir+="\Don't open this\KEY.txt"
    #print(dir)
    file=open(dir,'r')
    d=file.read()
    
    #print(d)

    d=int(d)
    n=int(n)

    decrypted_key=RSA.decryption(encrypted_key,d,n)
    print('Decrypted AES Key: '+str(decrypted_key))

    w=AES.keyExpansion(decrypted_key)
    decrypted_ptext,decrypted_ptext_hex=AES.decryption(cipher_text,w,len(decrypted_key)*8)
    #print('Decrypted Plain text: '+str(decrypted_ptext))
    file.close()
    
    #print(len(decrypted_ptext))
    
    if choice.lower()=='file':
        decrypted_ptext=decrypted_ptext.encode('ISO-8859-1')
        #print(decrypted_ptext[len(decrypted_ptext)-1])
        while decrypted_ptext[len(decrypted_ptext)-1]==36:
            decrypted_ptext=decrypted_ptext[:-1]

        filename='Received_'+filename

        file=open(filename,'wb+')
        file.write(decrypted_ptext)
        file.close()
    elif choice.lower()=='text':
        file=open(dir,'w')
        file.write(decrypted_ptext)
        file.close()
        
    rec_sock.send(str('Decrypted').encode())

    rec_sock.close()