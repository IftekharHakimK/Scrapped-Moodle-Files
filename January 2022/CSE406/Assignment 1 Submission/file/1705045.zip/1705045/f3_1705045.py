import socket
import f1_1705045 as AES
import f2_1705045 as RSA
import os

if __name__=="__main__":
    sender_sock=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    sender_sock.bind(("127.0.0.1",8080))
    sender_sock.listen(5)
    (rec_sock, address) = sender_sock.accept()
    
    K=256
    key=str(input('AES Key: '))
    keysize=len(key)*8

    choice=str(input('File/Text?: '))
    if choice.lower()=='text':
        ptext=str(input('Plain text to send: '))
    elif choice.lower()=='file':
        filename=str(input('Filename: '))
        in_file = open(filename, "rb")
        ptext=in_file.read().decode('ISO-8859-1')
        #print("got = "+ptext)
        in_file.close()
    else:
        print('Wrong choice')
        exit()

    while len(ptext)%16!=0:
        ptext+='$'
    #print(len(ptext))
    
    #print(ptext)

    w=AES.keyExpansion(key)
    cipher_text_ascii,cipher_text_hex=AES.encryption(ptext,w,keysize)
    e,d,n=RSA.generateKey(K)
    encrypted_key=RSA.encryption(key,e,n)
    
    dir=os.getcwd()
    dir+="\Don't open this"
    if not os.path.exists(dir):
        os.makedirs(dir)
    dir+='\KEY.txt'
    file=open(dir,'w+')
    file.write(str(d))
    file.close()
    
    # print(cipher_text_hex)
    # print(e)
    # print(d)
    # print(n)
    # print(encrypted_key)

    rec_sock.send(choice.encode())
    rec_sock.recv(1024) #ACK

    if choice.lower()=='file':
        rec_sock.send(filename.encode())
        rec_sock.recv(1024) #ACK

    rec_sock.send(cipher_text_hex.encode())
    rec_sock.recv(1024) #ACK
    rec_sock.send(str(e).encode())
    rec_sock.recv(1024) #ACK
    rec_sock.send(str(n).encode())
    rec_sock.recv(1024) #ACK
    rec_sock.send(str(encrypted_key).encode())
    rec_sock.recv(1024) #ACK

    reply=rec_sock.recv(1024).decode('utf-8')

    #print(ptext)
    if reply=='Decrypted':
        if choice.lower()=='text':
            file=open(dir,'r')
            got_text=file.read()
            #print(got_text+' .. ')
            if got_text!=ptext:
                print('Decryption failed')
            else:
                print('Decryption successful')
        else:
            got_text=open('Received_'+filename,'rb').read()
            actual_ptext=open(filename,'rb').read()
            if got_text!=actual_ptext:
                print('Decryption failed')
            else:
                print('Decryption successful')
    rec_sock.close()



  
