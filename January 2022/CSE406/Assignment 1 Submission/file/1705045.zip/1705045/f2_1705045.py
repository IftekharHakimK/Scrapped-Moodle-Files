from BitVector import *
import random
import math
import time

def bigmod(a,b,M):
    ans=1
    while b>0:
        if b%2!=0:
            ans=(ans*a)%M
        a=(a*a)%M
        b=(b>>1)
    return ans

def generateKey(K):
    p=-1
    q=-1
    while True:
        bv=BitVector(intVal=0)
        bv=bv.gen_random_bits(K>>1)
        check=bv.test_for_primality()
        if check != 0:
            p=bv.intValue()
            break
    while True:
        bv=BitVector(intVal=0)
        bv=bv.gen_random_bits(K>>1)
        check=bv.test_for_primality()
        if bv.intValue()!=p and check != 0:
            q=bv.intValue()
            break
    #print("p: "+str(p))
    #print("q: "+str(q))
    n=p*q
    phi_n=(p-1)*(q-1)
    e=-1
    while True:
        e=random.randint(2,phi_n-1)
        gcd=math.gcd(e,phi_n)
        if gcd==1:
            break
    
    bv_phi=BitVector(intVal=phi_n)
    bv_e=BitVector(intVal=e)
    d=bv_e.multiplicative_inverse(bv_phi)

    if d is None:
        print('GCD was not 1.')
    else:
        d=d.intValue()
    return e,d,n

def encryption(plain_text,e,n):
    cipher_text=[]
    for i in range(0,len(plain_text)):
        x=bigmod(ord(plain_text[i]),e,n)
        cipher_text.append(x)
    return cipher_text
def decryption(cipher_text,d,n):
    decrypted_text=''
    for i in range(0,len(cipher_text)):
        x=bigmod(cipher_text[i],d,n)
        decrypted_text+=chr(x)
    return decrypted_text

def generateStat():
    KS=[16,32,64,128]
    for K in KS:
        savedTime=time.time()
        e,d,n=generateKey(K)
        keyGenerationTime=time.time()-savedTime
        
        plain_text='CanTheyArrangeTheFest?'
        
        savedTime=time.time()
        cipher_text=encryption(plain_text,e,n)
        encryptionTime=time.time()-savedTime

        #print('Cipher text:\n '+ str(cipher_text))

        savedTime=time.time()
        decrypted_text=decryption(cipher_text,d,n)
        decryptionTime=time.time()-savedTime

        #print('Decrypted text:'+decrypted_text)

        print('K = '+str(K))
        print('Key Generation: '+str(keyGenerationTime)+' seconds')
        print('Encryption: '+str(encryptionTime)+' seconds')
        print('Decryption: '+str(decryptionTime)+' seconds')
        print()

if __name__=="__main__":
    
    #generateStat()

    K=int(input('K: '))

    savedTime=time.time()
    e,d,n=generateKey(K)
    keyGenerationTime=time.time()-savedTime
    
    print('Public key: {'+str(e)+','+str(n)+'}')
    print('Private key: {'+str(d)+','+str(n)+'}')
    
    plain_text=str(input('Plain text: '))
    
    savedTime=time.time()
    cipher_text=encryption(plain_text,e,n)
    encryptionTime=time.time()-savedTime

    print('Cipher text:\n '+ str(cipher_text))

    savedTime=time.time()
    decrypted_text=decryption(cipher_text,d,n)
    decryptionTime=time.time()-savedTime

    print('Decrypted text:'+decrypted_text)

    print('Execution time: ')
    print('Key Generation: '+str(keyGenerationTime)+' seconds')
    print('Encryption: '+str(encryptionTime)+' seconds')
    print('Decryption: '+str(decryptionTime)+' seconds')