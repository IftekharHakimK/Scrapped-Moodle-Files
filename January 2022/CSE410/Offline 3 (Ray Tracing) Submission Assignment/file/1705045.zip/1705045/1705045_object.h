extern vector<PointLight>pointLights;
extern vector<SpotLight>spotLights;
class Object;
extern vector<Object*>objects;
extern int recursionLevel;

class Object
{
public:

    //co-efficient
    double ambient;
    double diffuse;
    double specular;
    double reflection;
    int shine; // exponent term of specular component
    double color[3];

    Object()
    {
//        color=new double[3];
        color[0]=color[1]=color[2]=0;
    }
    virtual void draw()=0;
    void setColor(double r,double g,double b)
    {
        color[0]=r;
        color[1]=g;
        color[2]=b;
    }
    void setShine(int _shine)
    {
        shine=_shine;
    }
    void setAmbient(double _ambient)
    {
        ambient=_ambient;
    }
    void setDiffuse(double _diffuse)
    {
        diffuse=_diffuse;
    }
    void setSpecular(double _specular)
    {
        specular=_specular;
    }
    void setReflection(double _reflection)
    {
        reflection=_reflection;
    }
    ~Object()
    {

    }

    virtual double getT(Ray ray)=0;
    virtual Vector getNormalAt(Point intersectionPoint, Ray ray)=0;
    virtual void getColorAt(double * intersectionPointColor, Point intersectionPoint)=0;

    void calculateAmbientDiffuseSpecular(Ray ray, Point intersectionPoint, Vector normal, double * color)
    {
        double intersectionPointColor[3]= {0,0,0};

        getColorAt(intersectionPointColor,intersectionPoint);

        color[0]=intersectionPointColor[0]*ambient;
        color[1]=intersectionPointColor[1]*ambient;
        color[2]=intersectionPointColor[2]*ambient;

        for(PointLight pl:pointLights)
        {
            Ray L(pl.pos,intersectionPoint-pl.pos);

            double t_block=INF;
            for(auto u:objects)
            {
                double dummy_color[3]= {0,0,0};
                double t_here=u->intersect(L,dummy_color,0);
                if(t_here>0&&t_here<t_block)
                {
                    t_block=t_here;
                }
            }

            if(t_block>0)
            {
                Point blocked_at=L.Ro+L.Rd*t_block;
                if(!isSamePoint(blocked_at,intersectionPoint))
                {
                    continue;
                }
            }


            Vector uL=L.Rd*-1;

            double lambert=DOT(uL,normal);
            Vector R=normal*DOT(uL,normal)*2-uL;
            R=R/LEN(R);

            double phong=DOT(ray.Rd*-1,R);

            lambert=max(0.0,lambert);
            phong=max(0.0,phong);

//            cout<<"int "<<intersectionPointColor[0]<<' '<<intersectionPointColor[1]<<' '<<intersectionPointColor[2]<<endl;

            color[0]+=pl.color[0]*diffuse*lambert*intersectionPointColor[0];
            color[1]+=pl.color[1]*diffuse*lambert*intersectionPointColor[1];
            color[2]+=pl.color[2]*diffuse*lambert*intersectionPointColor[2];

            if(phong>EPS)
            {
                color[0]+=pl.color[0]*specular*pow(phong,shine)*intersectionPointColor[0];
                color[1]+=pl.color[1]*specular*pow(phong,shine)*intersectionPointColor[1];
                color[2]+=pl.color[2]*specular*pow(phong,shine)*intersectionPointColor[2];
            }

//            dbg(lambert);
//            dbg(phong);
        }

        for(SpotLight sl:spotLights)
        {
            Ray L(sl.pos,intersectionPoint-sl.pos);

            //check cutoff
            double angle=getAngleInDegree(sl.light_direction,L.Rd);
            if(angle>sl.cutoff_angle)
            {
                continue;
            }
//            cout<<"blocked"<<endl;

            double t_block=INF;
            for(auto u:objects)
            {
                double dummy_color[3]= {0,0,0};
                double t_here=u->intersect(L,dummy_color,0);
                if(t_here>0&&t_here<t_block)
                {
                    t_block=t_here;
                }
            }

            if(t_block>0)
            {
                Point blocked_at=L.Ro+L.Rd*t_block;
                if(!isSamePoint(blocked_at,intersectionPoint))
                {
                    continue;
                }
            }


            Vector uL=L.Rd*-1;

            double lambert=DOT(uL,normal);
            Vector R=normal*DOT(uL,normal)*2-uL;
            R=R/LEN(R);

            double phong=DOT(ray.Rd*-1,R);

            lambert=max(0.0,lambert);
            phong=max(0.0,phong);

            color[0]+=sl.color[0]*diffuse*lambert*intersectionPointColor[0];
            color[1]+=sl.color[1]*diffuse*lambert*intersectionPointColor[1];
            color[2]+=sl.color[2]*diffuse*lambert*intersectionPointColor[2];

            if(phong>EPS)
            {
                color[0]+=sl.color[0]*specular*pow(phong,shine)*intersectionPointColor[0];
                color[1]+=sl.color[1]*specular*pow(phong,shine)*intersectionPointColor[1];
                color[2]+=sl.color[2]*specular*pow(phong,shine)*intersectionPointColor[2];
            }


//            dbg(lambert);
//            dbg(phong);
//            cout<<"here"<<endl;
        }
    }

    void calculateReflection(Ray ray, Point intersectionPoint, Vector normal, double * color,int level)
    {

        Vector uL=ray.Rd*-1;
        Vector R=normal*DOT(uL,normal)*2-uL;
        Ray reflectRay(intersectionPoint+R*EPS*3,R);
        Object * which=NULL;
        double tMin=INF;

        for(Object * obj:objects)
        {
            double dummy[3]= {0,0,0};
            double t_r=obj->intersect(reflectRay,dummy,0);
//                dbg(t);

            if(t_r>0&&t_r<tMin)
            {
                tMin=t_r;
                which=obj;
            }
        }

        if(which!=NULL)
        {
            double reflectedColor[3]= {0,0,0};
            which->intersect(reflectRay,reflectedColor,level+1);

            color[0]+=reflectedColor[0]*reflection;
            color[1]+=reflectedColor[1]*reflection;
            color[2]+=reflectedColor[2]*reflection;

        }
    }

    double intersect(Ray ray, double * color, int level)
    {
        double t=getT(ray);
        if(level==0||t<0)
        {
            return t;
        }

//        cout<<this->color[0]<<' '<<this->color[1]<<' '<<this->color[2]<<endl;

        Point intersectionPoint=ray.Ro+ray.Rd*t;
        Vector normal=getNormalAt(intersectionPoint,ray);

        calculateAmbientDiffuseSpecular(ray,intersectionPoint,normal,color);
        if(level==recursionLevel)
            return t;

        calculateReflection(ray,intersectionPoint,normal,color,level);

        color[0]=min(1.0,max(0.0,color[0]));
        color[1]=min(1.0,max(0.0,color[1]));
        color[2]=min(1.0,max(0.0,color[2]));

        return t;
    }

};
