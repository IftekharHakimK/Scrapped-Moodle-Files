extern int recursionLevel;

class Floor: public Object
{
public:
    double floorWidth;
    double tileWidth;

    Floor(double _floorWidth,double _tileWidth)
    {
        floorWidth=_floorWidth;
        tileWidth=_tileWidth;
        ambient=0.4;
        diffuse=0.2;
        specular=0.2;
        reflection=0.2;
        shine=10;

    }
    void draw()
    {
//        return;
        glPushMatrix();
        Point bottomLeft(-floorWidth/2,-floorWidth/2,0);

        int cnt=ceil(floorWidth/tileWidth);
//        dbg(cnt);

        for(int i=0; i<cnt; i++)
        {
            for(int j=0; j<cnt; j++)
            {
//                cout<<i<<' '<<j<<endl;

                Point A=bottomLeft+Vector(1,0,0)*i*tileWidth+Vector(0,1,0)*j*tileWidth;
                Point B=bottomLeft+Vector(1,0,0)*(i+1)*tileWidth+Vector(0,1,0)*j*tileWidth;
                Point C=bottomLeft+Vector(1,0,0)*(i+1)*tileWidth+Vector(0,1,0)*(j+1)*tileWidth;
                Point D=bottomLeft+Vector(1,0,0)*i*tileWidth+Vector(0,1,0)*(j+1)*tileWidth;

                if((i+j)%2==0)
                {
                    glColor3f(1,1,1);
                }
                else
                {
                    glColor3f(0,0,0);
                }

                glBegin(GL_QUADS);
                {
                    glVertex3f(A.x,A.y,A.z);
                    glVertex3f(B.x,B.y,B.z);
                    glVertex3f(C.x,C.y,C.z);
                    glVertex3f(D.x,D.y,D.z);
                }
                glEnd();
            }
        }

        glPopMatrix();
    }

    double getT(Ray ray)
    {
        Vector normal=Vector(0,0,1);
        if(DOT(normal,ray.Rd*-1)<0)
        {
            normal=normal*-1;
        }

        double down=DOT(normal,ray.Rd);
        if(isSame(down,0))
            return -1;
        double up=-DOT(normal,ray.Ro);

        double t=up/down;

        Point intersectionPoint=ray.Ro+ray.Rd*t;

        if(!(intersectionPoint.x>=-floorWidth/2&&intersectionPoint.x<=floorWidth/2&&intersectionPoint.y>=-floorWidth/2&&intersectionPoint.y<=floorWidth/2))
            return -1;
        return t;
    }

    Vector getNormalAt(Point intersectionPoint, Ray ray)
    {
        Vector normal=Vector(0,0,1);
        if(DOT(normal,ray.Rd*-1)<0)
        {
            normal=normal*-1;
        }
        return normal;
    }

    void getColorAt(double * intersectionPointColor, Point intersectionPoint)
    {
        int i=floor((intersectionPoint.x+floorWidth/2)/tileWidth);
        int j=floor((intersectionPoint.y+floorWidth/2)/tileWidth);
        if((i+j)%2==0)
        {
            intersectionPointColor[0]=1;
            intersectionPointColor[1]=1;
            intersectionPointColor[2]=1;
        }
        else
        {
            intersectionPointColor[0]=0;
            intersectionPointColor[1]=0;
            intersectionPointColor[2]=0;
        }
//        cout<<intersectionPointColor[0]<<' '<<intersectionPointColor[1]<<' '<<intersectionPointColor[2]<<endl;

        return;
    }

    ~Floor()
    {

    }
};


