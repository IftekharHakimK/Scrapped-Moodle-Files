class Ray
{
public:

    Point Ro;
    Vector Rd;
    Ray(Point _Ro, Vector _Rd)
    {
        Ro=_Ro;
        Rd=_Rd;
        Rd=Rd/LEN(Rd);
    }
    ~Ray()
    {

    }
};
