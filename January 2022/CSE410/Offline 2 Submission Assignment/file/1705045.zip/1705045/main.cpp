#include<bits/stdc++.h>
using namespace std;

#include "bitmap_image.hpp"

#define pi acos(-1.0)

struct Point
{
    double x,y,z;
    Point(){}
    Point(double x,double y,double z)
    {
        this->x=x;
        this->y=y;
        this->z=z;
    }
    Point operator+(const Point& another)
    {
        return Point(x+another.x,y+another.y,z+another.z);
    }
    Point operator-(const Point& another)
    {
        return Point(x-another.x,y-another.y,z-another.z);
    }
    bool operator==(const Point& another)
    {
        return abs(x-another.x)<1e-9 && abs(y-another.y)<1e-9 && abs(z-another.z)<1e-9;
    }
    Point operator*(double v)
    {
        return Point(x*v,y*v,z*v);
    }
    Point operator/(double v)
    {
        return Point(x/v,y/v,z/v);
    }
};
//void print(Point a)
//{
//    cout<<setprecision(10)<<a.x<<' '<<a.y<<' '<<a.z<<endl;
//}
#define Vector Point
double DOT(Vector a,Vector b)
{
    return a.x*b.x+a.y*b.y+a.z*b.z;
}
Vector CROSS(Vector a,Vector b)
{
    return Vector(a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x);
}

double LEN(Vector a)
{
    return sqrt(a.x*a.x+a.y*a.y+a.z*a.z);
}

#define N 4

#define MATRIX vector<vector<double>>

MATRIX getI4()
{
    MATRIX res;
    res.resize(N);
    for(int i=0;i<N;i++)
        res[i].resize(N);

    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            res[i][j]=(i==j);
        }
    }
    return res;
}

MATRIX multiply(MATRIX a,MATRIX b)
{

    int n1=a.size(),m1=a[0].size();
    int n2=b.size(),m2=a[0].size();
    assert(m1==n2);

    MATRIX res;
    res.resize(n1);
    for(int i=0;i<n1;i++)
        res[i].resize(m2);

    for(int i=0;i<n1;i++)
    {
        for(int j=0;j<m2;j++)
        {
            res[i][j]=0;
            for(int k=0;k<m1;k++)
            {
                res[i][j]+=a[i][k]*b[k][j];
            }
        }
    }
    return res;
}

Vector R(Vector X,Vector A,double theta) //theta in degree
{
    theta=theta*pi/180.0;
    Vector ans=X*cos(theta)+A*DOT(A,X)*(1-cos(theta))+CROSS(A,X)*sin(theta);
    return ans;
}

int cnt;
Point eye;
Vector look;
Vector up;
double fovY,aspectRatio,near,far;
ofstream out;
ifstream in;


vector<Point>all_points;

void Stage1()
{

    in.open("scene.txt");
    out.open("stage1.txt");

    in>>eye.x>>eye.y>>eye.z;
    in>>look.x>>look.y>>look.z;
    in>>up.x>>up.y>>up.z;
    in>>fovY>>aspectRatio>>near>>far;

    stack<MATRIX>S;
    S.push(getI4());
    string command;
    while(in>>command)
    {
        if(command=="triangle")
        {
            for(int i=0;i<3;i++)
            {
                MATRIX v;
                v.resize(4);
                for(int i=0;i<4;i++)
                    v[i].resize(1);
                in>>v[0][0]>>v[1][0]>>v[2][0];
                v[3][0]=1;

                v=multiply(S.top(),v);

                for(int i=0;i<3;i++)
                {
                    out<<v[i][0]<<' ';
                }
                out<<'\n';
                all_points.push_back(Point(v[0][0],v[1][0],v[2][0]));
            }
            out<<'\n';
            cnt+=3;
        }
        else if(command=="translate")
        {
            MATRIX v=getI4();
            in>>v[0][3]>>v[1][3]>>v[2][3];
            auto u=S.top();
            S.pop();
            S.push(multiply(u,v));
        }
        else if(command=="scale")
        {
            MATRIX v=getI4();
            in>>v[0][0]>>v[1][1]>>v[2][2];
            auto u=S.top();
            S.pop();
            S.push(multiply(u,v));
        }
        else if(command=="rotate")
        {
            double ang;
            in>>ang;
            Vector A;
            in>>A.x>>A.y>>A.z;
            A=A/LEN(A);

            MATRIX v=getI4();

            for(int i=0;i<3;i++)
            {
                Vector c=R(Vector(i==0,i==1,i==2),A,ang);
                v[0][i]=c.x;
                v[1][i]=c.y;
                v[2][i]=c.z;
            }
            auto u=S.top();
            S.pop();
            S.push(multiply(u,v));

        }
        else if(command=="push")
        {
            S.push(S.top());
        }
        else if(command=="pop")
        {
            S.pop();
        }
        else if(command=="end")
        {
            break;
        }
    }
    in.close();
    out.close();
}

void Stage2()
{
    out.open("stage2.txt");

    Vector l=look-eye;
    l=l/LEN(l);
    Vector r=CROSS(l,up);
    r=r/LEN(r);
    Vector u=CROSS(r,l);

    MATRIX T=getI4();
    T[0][3]=-eye.x;
    T[1][3]=-eye.y;
    T[2][3]=-eye.z;

    MATRIX R=getI4();
    R[0]={r.x,r.y,r.z,0};
    R[1]={u.x,u.y,u.z,0};
    R[2]={-l.x,-l.y,-l.z,0};

    MATRIX V=multiply(R,T);

    MATRIX pt;
    pt.resize(4);
    for(int i=0;i<4;i++)
        pt[i].resize(1);
    pt[3][0]=1;
    for(int cs=0;cs<cnt;cs++)
    {
        pt[0][0]=all_points[cs].x;
        pt[1][0]=all_points[cs].y;
        pt[2][0]=all_points[cs].z;
        pt[3][0]=1;

        pt=multiply(V,pt);


        out<<pt[0][0]<<' '<<pt[1][0]<<' '<<pt[2][0]<<'\n';

        all_points[cs]=Point(pt[0][0],pt[1][0],pt[2][0]);

        if(cs%3==2)
            out<<'\n';
    }
    out.close();
}

void Stage3()
{
    out.open("stage3.txt");

    fovY=fovY*pi/180.0;

    double fovX=fovY*aspectRatio;
    double t=near*tan(fovY/2);
    double r=near*tan(fovX/2);

    MATRIX P;
    P.resize(4);
    for(int i=0;i<4;i++)
        P[i].resize(4);

    P[0][0]=near/r;
    P[1][1]=near/t;
    P[2][2]=-(far+near)/(far-near);
    P[2][3]=-(far*near*2)/(far-near);
    P[3][2]=-1;

    MATRIX pt;
    pt.resize(4);
    for(int i=0;i<4;i++)
        pt[i].resize(1);
    pt[3][0]=1;
    for(int cs=0;cs<cnt;cs++)
    {
        pt[0][0]=all_points[cs].x;
        pt[1][0]=all_points[cs].y;
        pt[2][0]=all_points[cs].z;

        pt[3][0]=1;

        pt=multiply(P,pt);
        pt[0][0]/=pt[3][0];
        pt[1][0]/=pt[3][0];
        pt[2][0]/=pt[3][0];
        pt[3][0]/=pt[3][0];

        out<<pt[0][0]<<' '<<pt[1][0]<<' '<<pt[2][0]<<'\n';
        all_points[cs]=Point(pt[0][0],pt[1][0],pt[2][0]);
        if(cs%3==2)
            out<<'\n';
    }
    out.close();
}

void Stage4()
{
    in.open("config.txt");

    int screenW,screenH;
    in>>screenW>>screenH;
    double left_limit_X;
    double bottom_limit_Y;
    double front_limit_Z;
    double rear_limit_Z;
    in>>left_limit_X>>bottom_limit_Y>>front_limit_Z>>rear_limit_Z;

    double right_limit_X=-left_limit_X;
    double top_limit_Y=-bottom_limit_Y;
    in.close();

    bitmap_image image(screenW,screenH);

    for(int i=0;i<screenW;i++)
    {
        for(int j=0;j<screenH;j++)
        {
            image.set_pixel(i,j,0,0,0);
        }
    }


    double dx=2*right_limit_X/screenW;
    double dy=2*top_limit_Y/screenH;

    double topY=top_limit_Y-dy/2;
    double leftX=left_limit_X+dx/2;
    double rightX=-leftX;

    vector<vector<double>>z_buffer;
    z_buffer.resize(screenH);

    for(int i=0;i<screenH;i++)
    {
        z_buffer[i].resize(screenW);
        for(int j=0;j<screenW;j++)
        {
            z_buffer[i][j]=rear_limit_Z;
        }
    }

    for(int cs=0;cs<cnt/3;cs++)
    {
        int r=rand()%255;
        int g=rand()%255;
        int b=rand()%255;

        //debug(R,G,B);

        vector<Point>v(3);
        double top_scanline=-1e50;

        double bottom_scanline=1e50;

        double right_scanline=-1e50;
        double left_scanline=1e50;

        for(int i=0;i<3;i++)
        {
            v[i].x=all_points[cs*3+i].x;
            v[i].y=all_points[cs*3+i].y;
            v[i].z=all_points[cs*3+i].z;

            top_scanline=max(top_scanline,v[i].y);
            bottom_scanline=min(bottom_scanline,v[i].y);

            right_scanline=max(right_scanline,v[i].x);
            left_scanline=min(left_scanline,v[i].x);
        }

        top_scanline=min(top_scanline,top_limit_Y);
        bottom_scanline=max(bottom_scanline,bottom_limit_Y);
        right_scanline=min(right_scanline,right_limit_X);
        left_scanline=max(left_scanline,left_limit_X);

        //debug(top_scanline,bottom_scanline,right_scanline,left_scanline);

        if(top_scanline<bottom_scanline||right_scanline<left_scanline)
            continue;
        //debug(R,G,B);

        int top_row_no=ceil((topY-top_scanline)/dy);
        int bottom_row_no=floor((topY-bottom_scanline)/dy);

        int left_col_no=ceil((left_scanline-leftX)/dx);
        int right_col_no=floor((right_scanline-leftX)/dx);





        vector<Point>projected=v;
        for(int i=0;i<3;i++)
            projected[i].z=0;

        auto CROSS2D=[&](Vector A, Vector B)
        {
            return A.x*B.y-A.y*B.x;
        };

        if(CROSS2D(projected[1]-projected[0],projected[2]-projected[0])<0)
        {
            swap(projected[1],projected[2]);
            swap(v[1],v[2]);
        }

        Vector temp=CROSS(v[1]-v[0],v[2]-v[0]);
        double A=temp.x,B=temp.y,C=temp.z;
        double D=-(A*v[0].x+B*v[0].y+C*v[0].z);
        if(abs(C)<1e-10)
            continue;

        for(int row_no=max(0,top_row_no-1);row_no<=min(screenH-1,bottom_row_no+1);row_no++)
        {
            for(int col_no=max(0,left_col_no-1);col_no<=min(screenW-1,right_col_no+1);col_no++)
            {
                double X=leftX+col_no*dx;
                double Y=topY-row_no*dy;

                int tot=0;
                for(int i=0;i<3;i++)
                {
                    if(CROSS2D(projected[(i+1)%3]-projected[i],Point(X,Y,0)-projected[i])>=-1e-4)
                    {
                        tot++;
                    }
                }
                if(tot!=3)
                    continue;
                //debug(X,Y);


                double Z=-(A*X+B*Y+D)/C;
                if(Z>=front_limit_Z&&z_buffer[row_no][col_no]>Z)
                {
                    z_buffer[row_no][col_no]=Z;
                    image.set_pixel(col_no,row_no,r,g,b);
                }

            }

        }
    }
    out.open("z_buffer.txt");
    out<<fixed<<setprecision(6);
    for(int i=0;i<screenH;i++)
    {
        for(int j=0;j<screenW;j++)
        {
            if(z_buffer[i][j]<rear_limit_Z)
            {
                out<<z_buffer[i][j]<<'\t';
            }

        }
        out<<'\n';
    }
    image.save_image("output.bmp");
    in.close();
    out.close();

    all_points.clear();
    z_buffer.clear();
}

main()
{
    srand(time(0));

    out<<fixed<<setprecision(7);

    Stage1();
    Stage2();
    Stage3();
    Stage4();

}
