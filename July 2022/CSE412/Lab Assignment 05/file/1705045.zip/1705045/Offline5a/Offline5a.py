import random
import numpy as np
import matplotlib.pyplot as plt

n=100
ss=[1,3,5,10]
s=int(input())
values=np.zeros(n)
for trial in range(0,10000):
    # generate random permutation of 0,1,...,n-1
    rank=[i for i in range(0,n)]
    random.shuffle(rank)

    for m in range(0,n):
        
        sample=random.sample(range(0,n),m)
        notsample=[i for i in range(0,n) if i not in sample]
        
        best=n
        for i in sample:
            if rank[i]<best:
                best=rank[i]
        pick=-1

        random.shuffle(notsample)

        for i in notsample:
            if rank[i]<best:
                pick=rank[i]
                break
            pick=rank[i]

        if pick!=-1 and pick<s:
            values[m]+=1

values=values/10000
# generate graph of values
plt.plot(values)
plt.xlabel('m')
plt.ylabel('probability')
plt.title('s='+str(s))
plt.show()
plt.savefig('Offline5a_s='+str(s)+'.png')
plt.clf()
            


