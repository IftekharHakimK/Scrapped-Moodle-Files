
#include<bits/stdc++.h>
using namespace std;
mt19937 rng(chrono::system_clock::now().time_since_epoch().count());

int main()
{
    int trial=10000;
    int gen;
    freopen("input.txt","r",stdin);
    cin>>gen;
    double P[4];
    double cP[4];
    double csum=0;
    for(int i=0;i<4;i++)
    {
        cin>>P[i];
        csum+=P[i];
        cP[i]=csum;
//        cout<<i<<' '<<cP[i]<<endl;
    }
//    cout<<gen<<endl;
    uniform_real_distribution<double> distribution(0.0,1.0);
    int cnt[5];
    memset(cnt,0,sizeof cnt);
    for(int tr=1;tr<=trial;tr++)
    {
        int last=1;
        for(int lv=1;lv<=gen;lv++)
        {
            int nxt=0;
            for(int k=1;k<=last;k++)
            {
                double got=distribution(rng);
                int x=-1;
//                cout<<"got "<<got<<endl;
                for(int c=0;c<4;c++)
                {
                    if(got<=cP[c])
                    {
                        x=c;
                        break;
                    }
                }
                assert(x!=-1);
                nxt+=x;
            }
            last=nxt;
        }
        if(last<=4)
            cnt[last]+=1;
    }
    for(int i=0;i<=4;i++)
    {
        cout<<setprecision(4)<<fixed<<"Child "<<i<<' '<<" Probability "<<cnt[i]*1.0/trial<<'\n';
    }


}

