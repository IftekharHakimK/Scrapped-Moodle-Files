#include<bits/stdc++.h>
using namespace std;
#include "lcgrand.h"
#define BUSY 1
#define IDLE 0

#define NONE 0
#define ARRIVAL 1
#define DEPARTURE 2

typedef float T;

int next_event_type, num_custs_delayed, num_delays_required, num_events,
    server_status;
T area_num_in_q, area_server_status, mean_interarrival, mean_service,
      sim_time, time_last_event, time_next_event[3],
      total_of_delays;
queue<T>time_arrival;
void initialize(void);
void timing(void);
void arrive(void);
void depart(void);
void report(void);
void update_time_avg_stats(void);
T expon(T mean);
int main()
{
    freopen("mm1.in","r",stdin);
    freopen("mm1.out","w",stdout);
    num_events = 2;
    cin>>mean_interarrival>>mean_service>>num_delays_required;

    cout<<fixed<<setprecision(3);
    cout<<"Single-server queueing system\n\n";
    cout<<"Mean interarrival time "<<mean_interarrival<<" minutes\n\n";
    cout<<"Mean service time "<<mean_service<<" minutes\n\n";
    cout<<"Number of customers "<<num_delays_required<<"\n\n";
    initialize();
    while (num_custs_delayed < num_delays_required)
    {
        timing();
        update_time_avg_stats();
        switch (next_event_type)
        {
            case ARRIVAL:
                arrive();
                break;
            case DEPARTURE:
                depart();
                break;
        }
    }
    report();
    return 0;
}
void initialize(void)
{
    sim_time = 0.0;
    server_status = IDLE;
    time_last_event = 0.0;
    num_custs_delayed = 0;
    total_of_delays = 0.0;
    area_num_in_q = 0.0;
    area_server_status = 0.0;
    time_next_event[ARRIVAL] = sim_time + expon(mean_interarrival);
    time_next_event[DEPARTURE] = 1.0e+30;
}
void timing(void)
{
    int i;
    T min_time_next_event = 1.0e+29;
    next_event_type = NONE;

    if(time_next_event[ARRIVAL]<min_time_next_event)
    {
        next_event_type=ARRIVAL;
        min_time_next_event=time_next_event[ARRIVAL];
    }
    if(time_next_event[DEPARTURE]<min_time_next_event)
    {
        next_event_type=DEPARTURE;
        min_time_next_event=time_next_event[DEPARTURE];
    }
    if (next_event_type == NONE)
    {
        cout<<"\nEvent list empty at time "<<sim_time<<"\n";
        exit(1);
    }
    sim_time = min_time_next_event;
}
void arrive(void)
{
    T delay;
    time_next_event[ARRIVAL] = sim_time + expon(mean_interarrival);
    if (server_status == BUSY)
    {
        time_arrival.push(sim_time);
    }
    else
    {
        delay = 0.0;
        total_of_delays += delay;
        ++num_custs_delayed;
        server_status = BUSY;
        time_next_event[DEPARTURE] = sim_time + expon(mean_service);
    }
}
void depart(void)
{
    int i;
    T delay;
    if (time_arrival.size() == 0)
    {
        server_status = IDLE;
        time_next_event[DEPARTURE] = 1.0e+30;
    }
    else
    {
        delay = sim_time - time_arrival.front();
        time_arrival.pop();
        total_of_delays += delay;
        ++num_custs_delayed;
        time_next_event[DEPARTURE] = sim_time + expon(mean_service);
    }
}
void report(void)
{
    cout<<"\n\nAverage delay in queue "<<total_of_delays / num_custs_delayed<<" minutes\n\n";
    cout<<"Average number in queue "<<area_num_in_q / sim_time<<" \n\n";
    cout<<"Server utilization "<<area_server_status / sim_time<<"\n\n";
    cout<<"Time simulation ended "<<sim_time<<" minutes";
}
void update_time_avg_stats(void)
{
    T time_since_last_event;
    time_since_last_event = sim_time - time_last_event;
    time_last_event = sim_time;
    area_num_in_q += time_arrival.size() * time_since_last_event;
    area_server_status += server_status * time_since_last_event;
}
T expon(T mean)
{
    return -mean * log(lcgrand(1));
}
