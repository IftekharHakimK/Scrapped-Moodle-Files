#include<pthread.h>
#include<semaphore.h>
#include<unistd.h>
#include<bits/stdc++.h>
using namespace std;

const int MX=11; //number of passengers+1
const double lambda=20; //avg number of passengers in a minute


int M,N,P;
int w,x,y,z;
auto initialClock=chrono::high_resolution_clock::now();

sem_t printMutex;

queue<int>freeKiosk;
sem_t queueMutex;

sem_t lockKiosk;
sem_t lockSpecialKiosk;
sem_t lockBelt[MX];
bool vip[MX];
pthread_t person[MX];


sem_t direction,entry;
int waiting,moving;
sem_t waiting_mutex,moving_mutex;

sem_t boarding_lock;

void print(string s)
{
    sem_wait(&printMutex);
    cout<<s<<endl;
    sem_post(&printMutex);
}

int currentTime()
{
    auto now=chrono::high_resolution_clock::now();
    auto elapsed=chrono::duration_cast<chrono::seconds>(now-initialClock);
    int tm=elapsed.count();
    return tm;
}

void checkKiosk(int id)
{
    sem_wait(&lockKiosk);

    sem_wait(&queueMutex);
    int whichKiosk=freeKiosk.front();
    freeKiosk.pop();
    sem_post(&queueMutex);

    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" started self-check in at kiosk "+to_string(whichKiosk)+" at time "+to_string(currentTime()));

    sleep(w);

    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" finished check in at time "+to_string(currentTime()));

    sem_wait(&queueMutex);
    freeKiosk.push(whichKiosk);
    sem_post(&queueMutex);

    sem_post(&lockKiosk);
}
void checkSpecialKiosk(int id)
{
    sem_wait(&lockSpecialKiosk);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" started self-check in at special kiosk at time "+to_string(currentTime()));
    sleep(w);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" finished check in at time "+to_string(currentTime()));
    sem_post(&lockSpecialKiosk);
}
void checkSecurity(int whichBelt,int id)
{
    sem_wait(&lockBelt[whichBelt]);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" started security check at belt "+to_string(whichBelt+1)+" at time "+to_string(currentTime()));
    sleep(x);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" crossed security check at time "+to_string(currentTime()));
    sem_post(&lockBelt[whichBelt]);
}
void vipLR(int id)
{
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" waiting at VIP Channel (LR) at time "+to_string(currentTime()));

    sem_wait(&waiting_mutex);
    waiting++;
    if(waiting==1)
    {
        sem_wait(&entry);
        sem_wait(&direction);
    }
    sem_post(&waiting_mutex);

    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" started crossing VIP Channel (LR) to reach boarding gate at time "+to_string(currentTime()));
    sleep(z);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" crossed VIP Channel (LR) to reach boarding gate at time "+to_string(currentTime()));

    sem_wait(&waiting_mutex);
    waiting--;
    if(waiting==0)
    {
        sem_post(&direction);
        sem_post(&entry);
    }
    sem_post(&waiting_mutex);

}

void vipRL(int id)
{
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" waiting at VIP Channel (RL) at time "+to_string(currentTime()));


    sem_wait(&entry);
    sem_wait(&moving_mutex);
    moving++;
    if(moving==1)
        sem_wait(&direction); //never sleeps
    sem_post(&moving_mutex);
    sem_post(&entry);


    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" started crossing VIP Channel (RL) to reach Special Kiosk at time "+to_string(currentTime()));
    sleep(z);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" crossed VIP Channel (RL) to reach Special Kiosk at time "+to_string(currentTime()));

    sem_wait(&moving_mutex);
    moving--;
    if(moving==0)
        sem_post(&direction);
    sem_post(&moving_mutex);
}

void boarding(int id)
{
    sem_wait(&boarding_lock);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" started boarding the plane at time "+to_string(currentTime()));
    sleep(y);
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" boarded the plane at time "+to_string(currentTime()));
    sem_post(&boarding_lock);
}

void * simulatePassenger(void * arg)
{
    int *x=(int *)arg;
    int id=*x;
    print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" arrived at the airport at time "+to_string(currentTime()));


    checkKiosk(id);

    if(!vip[id])
    {
        int whichBelt=rand()%N;
        checkSecurity(whichBelt,id);
    }
    else
    {
        vipLR(id);
    }

    Boarding:

    int r=rand()%2;
    if(r==0)
    {
        print("Passenger "+to_string(id)+(vip[id]?" (VIP)":"")+" lost Boarding Pass. He is sent back");
        vipRL(id);
        checkSpecialKiosk(id);
        vipLR(id);
        goto Boarding;
    }
    boarding(id);
}


int main()
{
    srand(time(0));

    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    cin>>M>>N>>P;
    cin>>w>>x>>y>>z;

    sem_init(&printMutex,0,1);

    sem_init(&lockKiosk,0,M);
    sem_init(&queueMutex,0,1);

    for(int i=1;i<=M;i++)
        freeKiosk.push(i);

    sem_init(&lockSpecialKiosk,0,1);
    for(int i=0;i<N;i++)
    {
        sem_init(&lockBelt[i],0,P);
    }
    sem_init(&direction,0,1);
    sem_init(&entry,0,1);
    sem_init(&moving_mutex,0,1);
    sem_init(&waiting_mutex,0,1);
    sem_init(&boarding_lock,0,1);


    mt19937 gen(rand());
    poisson_distribution<> d(60.0/lambda);

    for(int id=1;id<MX;id++)
    {
        int delay=d(gen);
        sleep(delay);
        int * x=new int(id);
        vip[id]=rand()%2;
        pthread_create(&person[id],NULL,simulatePassenger,(void*)x);
    }

    pthread_exit(NULL);
	return 0;

}
