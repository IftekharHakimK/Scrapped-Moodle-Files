#!/bin/bash

declare -A map_for_csv

f(){
	#echo enter "$1"
	cd "$1"
	IFS=$'\n'
	
	for file in `ls`
	do
		#echo $file
		if [ -d "$file" ]; then
			f "$file" "$2$file/"
		else
			ext=${file##*.}
			
			if [ "$ext" == "$file" ]; then
				ext=others
			fi
			
			
			flag=0
			for type in ${ignored_type[@]}
			do
				if [ "$type" == "$ext" ]; then
					flag=1
					((map_for_csv[ignored]=map_for_csv[ignored]+1))
					break
				fi
			done
			
			if [ "$flag" -eq 0 ]; then
			
			    now_at="$PWD"
				
				cd "$output_directory_path"
				if ! [ -e "$ext" ]; then
					mkdir "$ext"
				fi
				
				to_path=`realpath $ext`
				cd "$ext"
				
				if ! [ -e "$file" ]; then
					cd "$now_at"
					cp "$file" "$to_path"
					cd ~-
					
					if ! [ -e "desc_$ext.txt" ]; then
						touch "desc_$ext.txt"
					fi
					echo "$2$file" >> "desc_$ext.txt"
					
					((map_for_csv[$ext]=map_for_csv[$ext]+1))
				else
					((map_for_csv[ignored]=map_for_csv[ignored]+1))
				fi
				
				cd "$now_at"
			fi
		fi
	done
	cd ..
}

#main

working_directory="$PWD"
rt=""

if (($#==2)); then
	working_directory="$1"
	input_filename="$2"
	rt="$working_directory/"
elif (($#==1)); then
	input_filename="$1"
else 
	echo "Provide input filename, you may provide working directory too (optional)"
	exit
fi

if ! [ -e "$input_filename" ]; then
	echo "Provide correct input filename"
	exit
fi

n=0
while read line || [ -n "$line" ] ;
do
	ignored_type[$n]="$line"
	((n=n+1))
done < "$input_filename"

cd "$working_directory/.."
if  ! [ -e output_directory ]; then
	mkdir output_directory
else
	rm -r output_directory
	mkdir output_directory
fi

output_directory_path=`realpath output_directory`

f "$working_directory" "$rt"
touch myoutput.csv

echo file_type , no_of_files > myoutput.csv

for type in ${!map_for_csv[@]}
do
	echo $type , "${map_for_csv[$type]}"
done >> myoutput.csv

