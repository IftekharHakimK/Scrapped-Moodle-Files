#include<bits/stdc++.h>
#define ll long long
#define dbg(x) cout<<#x<<": "<<x<<endl;
#define N 20
#define M 20
using namespace std;

const double F=0.85;//Probability of correct reading
const double P=0.9; //Probability of moving to cell with shared edge

int n,m,k;
bool obs[N][M];
double B[N][M];
double B_part[N][M];

void showB()
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            cout<<B[i][j]<<' ';
        }
        cout<<'\n';
    }
}

double calculate_observationP(int u,int v,int b,int x,int y)
{
    if(abs(u-x)<=1&&abs(v-y)<=1)
    {
        if(b==0) return 1-F;
        else     return F;
    }
    else
    {
        if(b==0) return F;
        else     return 1-F;
    }
}
double calculate_transitionP(int fx,int fy,int tx,int ty)
{
    assert(fx>=0&&fx<n&&fy>=0&&fy<m);
    assert(tx>=0&&tx<n&&ty>=0&&ty<m);
    assert(obs[fx][fy]==0);
    assert(obs[tx][ty]==0);
    assert(abs(fx-tx)<=1&&abs(fy-ty)<=1);

    int free_cell=0;
    int free_cell_in_edge=0;
    for(int u=max(fx-1,0);u<=min(fx+1,n-1);u++)
    {
        for(int v=max(fy-1,0);v<=min(fy+1,m-1);v++)
        {
            if(obs[u][v])
                continue;
            free_cell++;
            if(abs(u-fx)+abs(v-fy)==1)
               free_cell_in_edge++;
        }
    }

    if(free_cell_in_edge==0) //special case
    {
        if(abs(fx-tx)+abs(fy-ty)!=1)
            return 1.0/free_cell;
        else
            return 0;
    }
    else
    {
        if(abs(fx-tx)+abs(fy-ty)!=1)
            return (1-P)/(free_cell-free_cell_in_edge);
        else
            return P/free_cell_in_edge;
    }
}

void build_transitionP(int x,int y,vector<pair<pair<int,int>,double>>&P)
{
    for(int u=max(x-1,0);u<=min(x+1,n-1);u++)
    {
        for(int v=max(y-1,0);v<=min(y+1,m-1);v++)
        {
            if(obs[u][v])
                continue;
            P.push_back({{u,v},calculate_transitionP(u,v,x,y)});
        }
    }
    return;
}

void iterate(int u,int v,int b)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            B_part[i][j]=0;
            if(obs[i][j])
            {
                continue;
            }
            vector<pair<pair<int,int>,double>>P;
            build_transitionP(i,j,P);

            for(auto r:P)
            {
                B_part[i][j]+=r.second*B[r.first.first][r.first.second];
            }
        }
    }
    double tot=0;
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            B[i][j]=0;
            if(obs[i][j])
            {
                continue;
            }
            B[i][j]=calculate_observationP(u,v,b,i,j)*B_part[i][j];
            tot+=B[i][j];
        }
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            B[i][j]/=tot;
        }
    }
    return;
}

main()
{

    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);

    cout<<fixed<<setprecision(4);

    cin>>n>>m>>k;
    for(int i=0;i<k;i++)
    {
        int u,v;
        cin>>u>>v;
        obs[u][v]=1;
    }
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<m;j++)
        {
            if(!obs[i][j])
                B[i][j]=1.0/(n*m-k); //all given points must be distinct
            else
                B[i][j]=0;
        }
    }

    cout<<"Initially:\n";
    showB();
    cout<<'\n';

    int reading=0;

    while(true)
    {
        char c;
        cin>>c;
        if(c=='R')
        {
            int u,v,b;
            cin>>u>>v>>b;

            reading++;
            cout<<"Reading: "<<reading<<'\n';

            iterate(u,v,b);

            cout<<"After enquiry\n";
            showB();
        }
        else if(c=='C')
        {
            double mx=0;
            int u=-1,v=-1;
            for(int i=0;i<n;i++)
            {
                for(int j=0;j<m;j++)
                {
                    if(B[i][j]>=mx)
                    {
                        mx=B[i][j];
                        u=i;
                        v=j;
                    }
                }
            }
            cout<<"Probable position: "<<u<<' '<<v<<'\n';
        }
        else
        {
            return 0;
        }
        cout<<'\n';
    }

}

