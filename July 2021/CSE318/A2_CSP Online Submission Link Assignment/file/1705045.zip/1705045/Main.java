package com.company;

import org.chocosolver.solver.Model;
import org.chocosolver.solver.Solver;
import org.chocosolver.solver.constraints.extension.Tuples;
import org.chocosolver.solver.variables.IntVar;


public class Main {
    public static void main(String[] args) {

        Model model = new Model("1705045");

        IntVar[][] board=model.intVarMatrix("board",6,6,1,6);


        for(int i=0;i<6;i++)
        {
            model.allDifferent(new IntVar[]{
                    board[i][0],
                    board[i][1],
                    board[i][2],
                    board[i][3],
                    board[i][4],
                    board[i][5],
            }).post();
        }

        for(int i=0;i<6;i++)
        {
            model.allDifferent(new IntVar[]{
                    board[0][i],
                    board[1][i],
                    board[2][i],
                    board[3][i],
                    board[4][i],
                    board[5][i]
            }).post();
        }
        IntVar z=model.intVar("z",1,36);
        model.times(board[0][0],board[1][0],z).post();
        model.times(z,board[0][1],10).post();

        IntVar y=model.intVar("y",1,36);
        model.times(board[2][0],board[3][0],y).post();
        model.times(board[4][0],y,72).post();


        IntVar x=model.intVar("x",1,36);
        model.times(board[0][2],board[0][3],x).post();
        model.times(x,board[1][2],48).post();

        model.times(board[5][2],board[5][3],30).post();
        model.arithm(board[4][5],"+",board[5][5],"=",8).post();

        model.sum(new IntVar[]{board[2][3],board[3][3],board[3][4]},"=",10).post();

        model.sum(new IntVar[]{board[0][4],board[1][4],board[2][4],board[1][3]},"=",14).post();


        Tuples tup=new Tuples(true);
        for(int i=1;i<=6;i++)
        {
            for(int j=1;j<=6;j++)
            {
                if(i-j==1||i-j==-1)
                {
                    tup.add(new int[]{i, j});
                }
            }
        }
        model.table(new IntVar[]{board[1][1],board[2][1]},tup,"CT+").post();

        tup=new Tuples(true);
        for(int i=1;i<=6;i++)
        {
            for(int j=1;j<=6;j++)
            {
                if((i/j==2&&i%j==0)||(j/i==2&&j%i==0))
                {
                    tup.add(new int[]{i, j});
                }
            }
        }
        model.table(new IntVar[]{board[3][1],board[4][1]},tup,"CT+").post();
        model.table(new IntVar[]{board[4][4],board[5][4]},tup,"CT+").post();

        tup=new Tuples(true);
        for(int i=1;i<=6;i++)
        {
            for(int j=1;j<=6;j++)
            {
                if((i/j==3&&i%j==0)||(j/i==3&&j%i==0))
                {
                    tup.add(new int[]{i, j});
                }
            }
        }
        model.table(new IntVar[]{board[5][0],board[5][1]},tup,"CT+").post();
        model.table(new IntVar[]{board[2][2],board[3][2]},tup,"CT+").post();

        tup=new Tuples(true);
        for(int i=1;i<=6;i++)
        {
            for(int j=1;j<=6;j++)
            {
                if(i-j==4||j-i==4)
                {
                    tup.add(new int[]{i, j});
                }
            }
        }
        model.table(new IntVar[]{board[4][2],board[4][3]},tup,"CT+").post();

        tup=new Tuples(true);
        for(int i=1;i<=6;i++)
        {
            for(int j=1;j<=6;j++)
            {
                if(i-j==2||j-i==2)
                {
                    tup.add(new int[]{i, j});
                }
            }
        }
        model.table(new IntVar[]{board[0][5],board[1][5]},tup,"CT+").post();

        tup=new Tuples(true);
        for(int i=1;i<=6;i++)
        {
            for(int j=1;j<=6;j++)
            {
                if(i-j==3||j-i==3)
                {
                    tup.add(new int[]{i, j});
                }
            }
        }
        model.table(new IntVar[]{board[2][5],board[3][5]},tup,"CT+").post();

        Solver solver = model.getSolver();
        solver.showStatistics();
        solver.showSolutions();
        solver.findSolution();

        for(int i=0;i<6;i++)
        {
            for(int j=0;j<6;j++)
            {
                int k=board[i][j].getValue();
                System.out.print(k+" ");
            }
            System.out.println();
        }

    }

}
