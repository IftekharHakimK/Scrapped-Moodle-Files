struct Node
{
    Board curBoard;
    Node * prevNode;
    int cost;

    Node(Board curBoard, Node * prevNode,int cost)
    {
        this->curBoard=curBoard;
        this->prevNode=prevNode;
        this->cost=cost;
    }
};
