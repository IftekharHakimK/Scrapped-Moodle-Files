int hamming_distance(Board board)
{
    int cnt=0;
    int now=1;
    for(auto &row:board)
    {
        for(int x:row)
        {
            if(x!=0)
            {
                if(x!=now)
                {
                    cnt++;
                }
            }
            now++;
        }
    }
    return cnt;
}
int manhattan(Board board)
{
    int k=board.size();
    int sum=0;
    for(int i=0;i<k;i++)
    {
        for(int j=0;j<k;j++)
        {
            if(board[i][j]!=0)
            {
                int ax=(board[i][j]-1)/k;
                int ay=(board[i][j]-1)%k;
                sum+=abs(ax-i)+abs(ay-j);
            }
        }
    }
    return sum;
}
int conflict(Board board)
{
    int k=board.size();
    int sum=0;

    for(int i=0;i<k;i++)
    {
        for(int j=0;j<k;j++)
        {
            for(int l=j+1;l<k;l++)
            {
                if(board[i][j]==0||board[i][l]==0)
                    continue;
                if((board[i][j]-1)/k==i&&(board[i][l]-1)/k==i)
                {
                    if(board[i][j]>board[i][l])
                    {
                        sum++;
                    }
                }
            }
        }
    }
    sum=sum*2+manhattan(board);
    return sum;
}
