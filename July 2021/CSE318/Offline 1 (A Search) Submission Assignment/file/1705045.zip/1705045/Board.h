
typedef vector<vector<int>> Board;

bool isGoal(Board board)
{
    int k=board.size();

    bool f=(board.back().back()==0);
    int now=1;
    for(auto &row:board)
    {
        for(int x:row)
        {
            if(x!=0)
            {
                f&=(now==x);
            }
            now++;
        }
    }
    return f;
}

vector<Board> neighbours(Board board)
{
    int x0,y0;
    int k=board.size();
    for(int i=0; i<k; i++)
    {
        for(int j=0; j<k; j++)
        {
            if(board[i][j]==0)
            {
                x0=i;
                y0=j;
            }
        }
    }
    vector<Board>res;
    for(int i=0; i<k; i++)
    {
        for(int j=0; j<k; j++)
        {
            if(abs(i-x0)+abs(j-y0)==1)
            {
                Board another=board;
                another[x0][y0]=board[i][j];
                another[i][j]=0;
                res.push_back(another);
            }
        }
    }
    return res;
}
void showBoard(Board board)
{
    int k=board.size();
    for(int i=0; i<k; i++)
    {
        for(int j=0; j<k; j++)
        {
            if(board[i][j]==0)
                cout<<'*'<<' ';
            else
                cout<<board[i][j]<<' ';
        }
        cout<<'\n';
    }
}

int rowMajorInversion(Board board)
{
    vector<int>v;
    for(auto &row:board)
    {
        for(int x:row)
        {
            if(x!=0)
                v.push_back(x);
        }
    }
    int cnt=0;
    for(int i=0;i<v.size();i++)
    {
        for(int j=i+1;j<(int)v.size();j++)
        {
            if(v[i]>v[j])
                cnt++;
        }
    }
    return cnt;
}

bool solvable(Board board)
{
    int cnt=rowMajorInversion(board);
    int k=board.size();
    if(k%2==1)
    {
        return (cnt%2==0);
    }
    else
    {
        int x0;
        for(int i=0;i<k;i++)
        {
            for(int j=0;j<k;j++)
            {
                if(board[i][j]==0)
                {
                    x0=i;
                    break;
                }
            }
        }

        if(x0%2==k%2&&cnt%2==1)
            return true;
        else if(x0%2!=k%2&&cnt%2==0)
            return true;
        else
            return false;
    }
}
