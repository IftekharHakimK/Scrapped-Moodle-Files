#include<bits/stdc++.h>
using namespace std;

#include "Board.h"
#include "Node.h"
#include "Heuristics.h"


class HeuristicSearch
{
    int (*h)(Board)=NULL;
    Node * initialNode;
public:
    HeuristicSearch() {}
    HeuristicSearch(int (*_h)(Board), Board initial)
    {
        h=_h;
        initialNode=new Node(initial,NULL,0);
    }

    void run()
    {
        priority_queue<pair<int,Node*>, vector<pair<int,Node*>>, greater<pair<int,Node*>> > q;
        map<Board,bool>closedList;
        map<Board,int>dist;

        q.push({h(initialNode->curBoard),initialNode});
        Node * goal=NULL;
        dist[initialNode->curBoard]=0;

        int expanded=0;

        while(!q.empty())
        {
            Node * now = q.top().second;
            q.pop();

            if(isGoal(now->curBoard))
            {
                goal=now;
                break;
            }

            if(closedList[now->curBoard]==true)
                continue;

            closedList[now->curBoard]=true;

            expanded++;

            for(Board v:neighbours(now->curBoard))
            {
                if(closedList.count(v))
                    continue;
                if(dist.count(v)&&dist[v]<=now->cost+1)
                    continue;

                dist[v]=now->cost+1;
                Node * temp =new Node(v,now,now->cost+1);
                q.push({temp->cost+h(v),temp});
            }
        }

//        if(goal==NULL) cout<<"impossible\n";
//        else cout<<goal->cost<<'\n';

        if(goal==NULL)
        {
            cout<<"Goal could not be reached\n";
            return;
        }
        cout<<"Goal reached\n";
        cout<<"Cost: "<<goal->cost<<'\n';
        cout<<"Steps: \n";

        vector<Board>step;
        while(goal!=NULL)
        {
            step.push_back(goal->curBoard);
            goal=goal->prevNode;
        }
        reverse(step.begin(),step.end());

        for(Board board:step)
        {
            showBoard(board);
            cout<<'\n';
        }

        cout<<"Expanded nodes: "<<expanded<<'\n';
        cout<<"Explored nodes: "<<dist.size()<<'\n';

    }
};
main()
{
    //freopen("input.txt","r",stdin);

    int k;
    cin>>k;
    Board board(k);

    for(auto &row:board)
    {
        row.resize(k);
        for(int &u:row)
        {
            string s;
            cin>>s;
            if(s=="*")
                u=0;
            else
                u=stoi(s);
        }
    }

    if(!solvable(board))
    {
        cout<<"Goal could not be reached\n";
        return 0;
    }


    cout<<"Hamming: \n";
    HeuristicSearch h1(&hamming_distance,board);
    h1.run();

    cout<<"Manhattan: \n";
    HeuristicSearch h2(&manhattan,board);
    h2.run();

    cout<<"Linear conflict: \n";
    HeuristicSearch h3(&conflict,board);
    h3.run();
}
