public class Heuristic2 implements Heuristic {
    int W1,W2;
    Heuristic2(int W1,int W2)
    {
        this.W1=W1;
        this.W2=W2;
    }
    @Override
    public int value(Board board,int player, int free1,int free2) {
        int val=W1*(board.x[board.storage(1)]-board.x[board.storage(2)]);
        for(int i=1;i<=6;i++) val+=W2*board.x[i];
        for(int i=8;i<=13;i++) val-=W2*board.x[i];

        return val;
    }
    @Override
    public String toString()
    {
        String w="("+W1+", "+W2+")";
        String s="\"H2 "+w+"\"";
        return s;
    }
}
