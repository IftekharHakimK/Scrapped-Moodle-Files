public class Heuristic6 implements Heuristic {
    int W1;
    int W2;
    int W3;
    Heuristic6(int W1,int W2,int W3)
    {
        this.W1=W1;
        this.W2=W2;
        this.W3=W3;
    }
    @Override
    public int value(Board board,int player, int free1,int free2) {
        int val=W1*(board.x[board.storage(1)]-board.x[board.storage(2)]);

        if(player==1)
            free1=1;
        if(player==2)
            free2=1;

        val+=free1*W2;
        val-=free2*W2;

        for(int i=1;i<=6;i++)
        {
            if(board.x[14-i]>0&&board.x[i]==0)
                val+=W3;
            else if(board.x[14-i]==0&&board.x[i]>0)
                val-=W3;
        }
        return val;
    }

    @Override
    public String toString()
    {
        String w="("+W1+", "+W2+", "+W3+")";
        String s="\"H6 "+w+"\"";
        return s;
    }

}
