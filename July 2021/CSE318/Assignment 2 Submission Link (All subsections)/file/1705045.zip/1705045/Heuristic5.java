public class Heuristic5 implements Heuristic {
    int W1,W2;
    Heuristic5(int W1,int W2)
    {
        this.W1=W1;
        this.W2=W2;
    }
    @Override
    public int value(Board board,int player, int free1,int free2) {
        int val=W1*(board.x[board.storage(1)]-board.x[board.storage(2)]);

        for(int i=1;i<=6;i++)
        {
            if(board.x[14-i]>0&&board.x[i]==0)
                val+=W2;
            else if(board.x[14-i]==0&&board.x[i]>0)
                val-=W2;
        }

        return val;
    }
    @Override
    public String toString()
    {
        String w="("+W1+", "+W2+")";
        String s="\"H5 "+w+"\"";
        return s;
    }
}
