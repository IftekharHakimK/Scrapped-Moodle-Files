public interface Heuristic {
    public int value(Board board,int player, int free1,int free2);
    public String toString();
}
