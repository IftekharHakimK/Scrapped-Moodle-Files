import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class Stat_maker {
    static PrintWriter writer;

    static int getResult(Heuristic heuristic1,Heuristic heuristic2,int depth,int firstMove)
    {
        Heuristic heuristic[]=new Heuristic[3];
        Minimax minimax[]=new Minimax[3];

        heuristic[1]=heuristic1;
        heuristic[2]=heuristic2;
        minimax[1]=new Minimax(heuristic[1]);
        minimax[2]=new Minimax(heuristic[2]);

        Board board=new Board();
        int player=firstMove;

        while(true)
        {
            int position=minimax[player].runWithPruningAndRandom(board,depth,player, Integer.MIN_VALUE, Integer.MAX_VALUE,0,0).second;

            int r=board.move(player,position,false);
            if(r==-1)
            {
                System.out.println("Invalid move");
                continue;
            }

            if(r==0) player=3-player;

            boolean f=board.reform();
            if(f)
            {
                if(board.x[board.storage(1)]>board.x[board.storage(2)]) {
                    return 1;
                }
                else if(board.x[board.storage(1)]<board.x[board.storage(2)])
                {
                    return 2;
                }
                else
                {
                    return 0;
                }
            }
        }
    }

    public static void main(String[] args) throws FileNotFoundException {
        writer=new PrintWriter("Statistics.csv");
        StringBuilder sb=new StringBuilder();
        sb.append("Player1");
        sb.append(",");
        sb.append("Player2");
        sb.append(",");
        sb.append("#Player1 Win");
        sb.append(",");
        sb.append("#Player2 Win");
        sb.append(",");
        sb.append("#Draw");
        sb.append("\n");

        writer.write(sb.toString());

        ArrayList<Heuristic> all=new ArrayList<>();

        all.add(new Heuristic1());

        all.add(new Heuristic2(3,2));

        all.add(new Heuristic3(5,1,2));

        all.add(new Heuristic4(3,1));

        all.add(new Heuristic5(4,1));

        all.add(new Heuristic6(6,2,1));

        for(var u:all)
        {
            for(var v:all)
            {
                int win=0,defeat=0,draw=0;
                for(int depth=1;depth<=10;depth++)
                {
                    for(int trial=1;trial<=5;trial++)
                    {
                        int r1=getResult(u,v,depth,1);

                        if(r1==0) draw++;
                        else if(r1==1) win++;
                        else defeat++;

                        r1=getResult(u,v,depth,2);
                        if(r1==0) draw++;
                        else if(r1==1) win++;
                        else defeat++;
                    }
                }
                sb=new StringBuilder();
                sb.append(u.toString());
                sb.append(",");
                sb.append(v.toString());
                sb.append(",");
                sb.append(win);
                sb.append(",");
                sb.append(defeat);
                sb.append(",");
                sb.append(draw);
                sb.append("\n");

                writer.append(sb.toString());
                writer.flush();
            }
            writer.append("\n");
        }

        writer.write(sb.toString());

    }
}
