/*
          13 12 11 10 9 8    - player2
        0                 7
            1 2 3 4 5 6      - player1
*/
public class Board {
    int x[];
    Board()
    {
        x=new int[14];
        for(int i=0;i<14;i++)
            x[i]=4;
        x[0]=x[7]=0;
    }
    Board(Board b)
    {
        x=new int[14];
        for(int i=0;i<14;i++)
            x[i]=b.x[i];
    }

    boolean valid(int player,int position)
    {
        if(player==1&&!(position>=1&&position<=6))
            return false;
        if(player==2&&!(position>=8&&position<=13))
            return false;
        return true;
    }
    int storage(int player)
    {
        if(player==1) return 7;
        else return 0;
    }

    /* returns 1 if game ended after reform */
    boolean reform()
    {
        int p=0,q=0;
        for(int i=1;i<=6;i++)
            p+=x[i];
        for(int i=8;i<=13;i++)
            q+=x[i];
        if(p==0)
        {
            for(int i=8;i<=13;i++)
                x[i]=0;
            x[0]+=q;
        }
        if(q==0)
        {
            for(int i=1;i<=6;i++)
                x[i]=0;
            x[7]+=p;
        }

        if(p==0||q==0)
            return true;
        return false;
    }

    /*
     returns -1 if invalid move
     returns 0 if no free move
     return 1 if free move
     */
    int  move(int player,int position,boolean print)
    {
        if(!valid(player,position))
            return -1;
        if(x[position]==0)
            return -1;

        int c=x[position];
        x[position]=0;
        position=(position+1)%14;
        int last=-1;
        while(c>0)
        {
            if(player==1&&position==0)
            {
                position=(position+1)%14;
                continue;
            }
            if(player==2&&position==7)
            {
                position=(position+1)%14;
                continue;
            }
            x[position]+=1;
            last=position;
            c--;
            position=(position+1)%14;
        }

        //Capture
        if(x[last]==1&&valid(player,last)&&x[14-last]>0)
        {
            x[storage(player)]+=x[14-last]+x[last];
            x[14-last]=0;
            x[last]=0;
            if(print)
                System.out.println("Captured");
            return 0;
        }
        if(storage(player)==last)
            return 1;
        return 0;
    }
    void show()
    {
        System.out.print("   ");
        for(int i=13;i>=8;i--)
            System.out.print(x[i]+"  ");
        System.out.print("\n");
        System.out.print(x[0]);
        for(int i=1;i<=7;i++) System.out.print("   ");
        System.out.print(x[7]);
        System.out.print("\n");
        System.out.print("   ");
        for(int i=1;i<=6;i++)
            System.out.print(x[i]+"  ");
        System.out.print("\n");
    }

}
