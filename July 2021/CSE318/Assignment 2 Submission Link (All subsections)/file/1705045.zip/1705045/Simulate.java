import java.util.Scanner;

public class Simulate {

    static int normalize(int player,int position)
    {
        if(player==1) return position;
        else
            return 14-position;
    }

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);
        String type[]=new String[3];
        Heuristic heuristic[]=new Heuristic[3];
        Minimax minimax[]=new Minimax[3];
        long time[]=new long[3];
        int moves[]=new int[3];

        time[1]=time[2]=0;
        moves[1]=moves[2]=0;

        for(int i=1;i<=2;i++)
        {
            System.out.println("Player "+i);
            System.out.print("Type (Human/AI): ");
            type[i]=scanner.next();
            if(type[i].equalsIgnoreCase("AI"))
            {
                System.out.print("Which heuristic: ");
                int choice=scanner.nextInt();
                if(choice==1)
                {
                    heuristic[i]=new Heuristic1();
                }
                else if(choice==2)
                {
                    int W1,W2;
                    System.out.print("W1: ");
                    W1=scanner.nextInt();
                    System.out.print("W2: ");
                    W2=scanner.nextInt();
                    heuristic[i]=new Heuristic2(W1,W2);
                }
                else if(choice==3)
                {
                    int W1,W2,W3;
                    System.out.print("W1: ");
                    W1=scanner.nextInt();
                    System.out.print("W2: ");
                    W2=scanner.nextInt();
                    System.out.print("W3: ");
                    W3=scanner.nextInt();
                    heuristic[i]=new Heuristic3(W1,W2,W3);
                }
                else if(choice==4)
                {
                    int W1,W2;
                    System.out.print("W1: ");
                    W1=scanner.nextInt();
                    System.out.print("W2: ");
                    W2=scanner.nextInt();
                    heuristic[i]=new Heuristic4(W1,W2);
                }
                else if(choice==5)
                {
                    int W1,W2;
                    System.out.print("W1: ");
                    W1=scanner.nextInt();
                    System.out.print("W2: ");
                    W2=scanner.nextInt();
                    heuristic[i]=new Heuristic5(W1,W2);
                }
                else if(choice==6)
                {
                    int W1,W2,W3;
                    System.out.print("W1: ");
                    W1=scanner.nextInt();
                    System.out.print("W2: ");
                    W2=scanner.nextInt();
                    System.out.print("W3: ");
                    W3=scanner.nextInt();
                    heuristic[i]=new Heuristic6(W1,W2,W3);
                }
                else
                {
                    System.out.println("Wrong choice");
                    return;
                }
                minimax[i]=new Minimax(heuristic[i]);
            }
        }


        Board board=new Board();
        int player=1;

        System.out.print("First move (Player 1/2)?: ");
        player=scanner.nextInt();

        while(true)
        {
            System.out.println("################################################################################");
            board.show();
            System.out.println("Move of player "+player);
            int position;

            if(type[player].equalsIgnoreCase("Human"))
            {
                System.out.print("Position: ");
                long start=System.nanoTime();
                position = scanner.nextInt();
                long end=System.nanoTime();
                position=normalize(player,position);
                time[player]+=(end-start);
                moves[player]++;
            }
            else
            {
                long start=System.nanoTime();
                position=minimax[player].runWithPruningAndRandom(board,10,player, Integer.MIN_VALUE, Integer.MAX_VALUE, 0,0).second;
                //position=minimax[player].runWithPruningAndOrdering(board,7,player, Integer.MIN_VALUE, Integer.MAX_VALUE, 0,0).second;
                //position=minimax[player].runWithPruning(board,7,player, Integer.MIN_VALUE, Integer.MAX_VALUE, 0,0).second;
                //position=minimax[player].runWithoutPruning(board,7,player, 0,0).second;
                long end=System.nanoTime();
                System.out.println("AI chooses: "+normalize(player,position));
                time[player]+=(end-start);
                moves[player]++;
                System.out.println("Took "+(end-start)/1e3+" micros");
            }

            int r=board.move(player,position,true);
            if(r==-1)
            {
                System.out.println("Invalid move");
                continue;
            }
            if(r==0) player=3-player;
            else
            {
                System.out.println("Earned free move");
            }

            boolean f=board.reform();
            if(f)
            {
                board.show();
                if(board.x[board.storage(1)]>board.x[board.storage(2)])
                    System.out.println("Player 1 won");
                else if(board.x[board.storage(1)]<board.x[board.storage(2)])
                    System.out.println("Player 2 won");
                else
                    System.out.println("Draw!");
                System.out.println("Player 1's avg time in microsecond per move "+(time[1]/(moves[1]*1e3)));
                System.out.println("Player 2's avg time in microsecond per move "+(time[2]/(moves[2]*1e3)));
                return;
            }
        }
    }
}
