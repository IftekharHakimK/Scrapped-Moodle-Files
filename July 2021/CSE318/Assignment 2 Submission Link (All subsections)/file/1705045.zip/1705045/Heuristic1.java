public class Heuristic1 implements Heuristic {
    @Override
    public int value(Board board,int player, int free1,int free2) {
        return board.x[board.storage(1)]-board.x[board.storage(2)];
    }
    @Override
    public String toString()
    {
        String s="\"H1\"";
        return s;
    }
}
