import java.util.*;

public class Minimax {
    Heuristic heuristic;

    Minimax(Heuristic heuristic)
    {
        this.heuristic=heuristic;
    }

    Pair runWithPruning(Board board,int depth,int player,int alpha,int beta,int free1,int free2)
    {
        if(board.reform())
            return new Pair(heuristic.value(board,player,free1,free2),-1);
        if(depth==0)
            return new Pair(heuristic.value(board,player,free1,free2),-1);

        if(player==1)
        {
            int mx=Integer.MIN_VALUE;
            int best=-1;

            for(int i=1;i<=6;i++)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(1,i,false);
                if(r==-1) continue;

                int got;

                if(r==0) got=runWithPruning(nextBoard,depth-1,2,alpha,beta,0,0).first;
                else got=runWithPruning(nextBoard,depth-1,1,alpha,beta,1,0).first;

                if(got>mx)
                {
                    mx=got;
                    best=i;
                }

                if(mx>=beta)
                {
                    return new Pair(mx,best);
                }
                if(mx>alpha)
                    alpha=mx;
            }
            return new Pair(mx,best);
        }
        else
        {
            int mn=Integer.MAX_VALUE;
            int best=-1;

            for(int i=8;i<=13;i++)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(2,i,false);
                if(r==-1) continue;

                int got;
                if(r==0) got=runWithPruning(nextBoard,depth-1,1,alpha,beta,0,0).first;
                else got=runWithPruning(nextBoard,depth-1,2,alpha,beta,0,1).first;

                if(got<mn)
                {
                    mn=got;
                    best=i;
                }
                if(mn<=alpha)
                {
                    return new Pair(mn,best);
                }
                if(mn<beta)
                    beta=mn;
            }
            return new Pair(mn,best);
        }
    }
    Pair runWithoutPruning(Board board,int depth,int player,int free1,int free2)
    {
        if(board.reform())
        {
            return new Pair(heuristic.value(board,player,free1,free2),-1);
        }

        if(depth==0) {
            return new Pair(heuristic.value(board,player,free1,free2),-1);
        }

        if(player==1)
        {
            int mx=Integer.MIN_VALUE;
            int best=-1;

            for(int i=1;i<=6;i++)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(1,i,false);
                if(r==-1) continue;
                else if(r==0)
                {
                    int got=runWithoutPruning(nextBoard,depth-1,2,0,0).first;
                    if(got>mx)
                    {
                        mx=got;
                        best=i;
                    }
                }
                else
                {
                    int got=runWithoutPruning(nextBoard,depth-1,1,1,0).first;
                    if(got>mx)
                    {
                        mx=got;
                        best=i;
                    }
                }
            }
            return new Pair(mx,best);
        }
        else
        {
            int mn=Integer.MAX_VALUE;
            int best=-1;

            for(int i=8;i<=13;i++)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(2,i,false);
                if(r==-1) continue;
                else if(r==0)
                {
                    int got=runWithoutPruning(nextBoard,depth-1,1,0,0).first;
                    if(got<mn)
                    {
                        mn=got;
                        best=i;
                    }
                }
                else
                {
                    int got=runWithoutPruning(nextBoard,depth-1,2,0,1).first;
                    if(got<mn)
                    {
                        mn=got;
                        best=i;
                    }
                }
            }
            return new Pair(mn,best);
        }
    }
    Pair runWithPruningAndOrdering(Board board,int depth,int player,int alpha,int beta,int free1,int free2)
    {
        if(board.reform())
            return new Pair(heuristic.value(board,player,free1,free2),-1);
        if(depth==0)
            return new Pair(heuristic.value(board,player,free1,free2),-1);

        if(player==1)
        {
            ArrayList<Pair> list=new ArrayList<>();
            for(int i=1;i<=6;i++)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(1,i,false);
                if(r==-1) continue;

                if(r==0) list.add(new Pair(heuristic.value(nextBoard,2,0,0),i));
                else list.add(new Pair(heuristic.value(nextBoard,1,1,0),i));
            }

            Collections.sort(list, new Comparator<Pair>() {
                @Override
                public int compare(Pair o1, Pair o2) {
                    return o2.first-o1.first;
                }
            });

            int mx=Integer.MIN_VALUE;
            int best=-1;
            for(var u:list)
            {
                int i=u.second;
                Board nextBoard=new Board(board);

                int r=nextBoard.move(1,i,false);
                if(r==-1) continue;

                int got;

                if(r==0) got=runWithPruningAndOrdering(nextBoard,depth-1,2,alpha,beta,0,0).first;
                else got=runWithPruningAndOrdering(nextBoard,depth-1,1,alpha,beta,1,0).first;

                if(got>mx)
                {
                    mx=got;
                    best=i;
                }

                if(mx>=beta)
                {
                    return new Pair(mx,best);
                }
                if(mx>alpha)
                    alpha=mx;
            }
            return new Pair(mx,best);
        }
        else
        {
            ArrayList<Pair> list=new ArrayList<>();
            for(int i=8;i<=13;i++)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(2,i,false);
                if(r==-1) continue;

                if(r==0) list.add(new Pair(heuristic.value(nextBoard,1,0,0),i));
                else list.add(new Pair(heuristic.value(nextBoard,2,0,1),i));
            }

            Collections.sort(list, new Comparator<Pair>() {
                @Override
                public int compare(Pair o1, Pair o2) {
                    return o1.first-o2.first;
                }
            });

            int mn=Integer.MAX_VALUE;
            int best=-1;
            for(var u:list)
            {
                int i=u.second;

                Board nextBoard=new Board(board);

                int r=nextBoard.move(2,i,false);
                if(r==-1) continue;

                int got;
                if(r==0) got=runWithPruningAndOrdering(nextBoard,depth-1,1,alpha,beta,0,0).first;
                else got=runWithPruningAndOrdering(nextBoard,depth-1,2,alpha,beta,0,1).first;

                if(got<mn)
                {
                    mn=got;
                    best=i;
                }
                if(mn<=alpha)
                {
                    return new Pair(mn,best);
                }
                if(mn<beta)
                    beta=mn;
            }
            return new Pair(mn,best);
        }
    }

    Pair runWithPruningAndRandom(Board board,int depth,int player,int alpha,int beta,int free1,int free2)
    {
        if(board.reform())
            return new Pair(heuristic.value(board,player,free1,free2),-1);
        if(depth==0)
            return new Pair(heuristic.value(board,player,free1,free2),-1);

        if(player==1)
        {
            int mx=Integer.MIN_VALUE;
            int best=-1;

            ArrayList<Integer> list=new ArrayList<>();
            for(int i=1;i<=6;i++)
                list.add(i);
            Collections.shuffle(list);

            for(int i:list)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(1,i,false);
                if(r==-1) continue;

                int got;

                if(r==0) got=runWithPruningAndRandom(nextBoard,depth-1,2,alpha,beta,0,0).first;
                else got=runWithPruningAndRandom(nextBoard,depth-1,1,alpha,beta,1,0).first;

                if(got>mx)
                {
                    mx=got;
                    best=i;
                }

                if(mx>=beta)
                {
                    return new Pair(mx,best);
                }
                if(mx>alpha)
                    alpha=mx;
            }
            return new Pair(mx,best);
        }
        else
        {
            int mn=Integer.MAX_VALUE;
            int best=-1;

            ArrayList<Integer> list=new ArrayList<>();
            for(int i=8;i<=13;i++)
                list.add(i);
            Collections.shuffle(list);


            for(int i:list)
            {
                Board nextBoard=new Board(board);

                int r=nextBoard.move(2,i,false);
                if(r==-1) continue;

                int got;
                if(r==0) got=runWithPruningAndRandom(nextBoard,depth-1,1,alpha,beta,0,0).first;
                else got=runWithPruningAndRandom(nextBoard,depth-1,2,alpha,beta,0,1).first;

                if(got<mn)
                {
                    mn=got;
                    best=i;
                }
                if(mn<=alpha)
                {
                    return new Pair(mn,best);
                }
                if(mn<beta)
                    beta=mn;
            }
            return new Pair(mn,best);
        }
    }
}
