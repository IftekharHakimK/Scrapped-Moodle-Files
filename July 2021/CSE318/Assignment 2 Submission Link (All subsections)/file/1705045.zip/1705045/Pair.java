public class Pair {
    int first=0,second=0;
    Pair(){ }
    Pair(int first,int second)
    {
        this.first=first;
        this.second=second;
    }
}
