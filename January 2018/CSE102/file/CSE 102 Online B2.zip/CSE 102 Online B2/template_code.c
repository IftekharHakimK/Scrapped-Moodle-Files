#include<stdio.h>

int main()
{
    int n, result;
    ///Following lines of code is to test the foo function
    printf("Enter the number: ");
    scanf("%d",&n);
    result=foo(n);
    printf("The foo value is %d",result);

    ///Following lines of code is to test the bar function
    /*printf("Enter the number: ");
    scanf("%d",&n);
    result=bar(n);
    printf("The bar value is %d",result);*/

    ///Following lines of code is to test the bseries function
    /*printf("Enter the number: ");
    scanf("%d",&n);
    result=bseries(n);
    printf("The %d bseries number is %d",n,result);*/

    return 0;
}

