# include "iGraphics.h"

char str[100], str2[100];
int len,a=0;
int mode,x=100,c=300,last=100000,r=255,g=0,b=255;

void drawTextBox()
{
    iSetColor(150, 150, 150);
    iRectangle(50, 250, 250, 30);
}
void l1(int x)
{
    iFilledRectangle(x,100,20,-3);
}
void l2(int x)
{
    iFilledRectangle(x,100,3,-20);
}
void l3(int x)
{
    iFilledRectangle(x+20,100,-3,-20);
}
void l4(int x)
{
    iFilledRectangle(x,80,20,3);
}
void l5(int x)
{
    iFilledRectangle(x,80,3,-20);
}
void l6(int x)
{
    iFilledRectangle(x,60,20,3);
}
void l7(int x)
{
    iFilledRectangle(x+20,80,-3,-20);
}
void iDraw()
{
    iClear();
    drawTextBox();
    if(mode == 1)
    {
        iText(55, 260, str);
    }
    iText(10, 10, "Click to activate the box, enter to finish.");
    iSetColor(r,g,b);
    if(last+20<0)
    {
        c=400;
    }
    for(int i=0; i<strlen(str2); i++)
    {
        x=c+i*26;
        last=x;
        if(str2[i]=='A')
        {

            l1(x);
            l2(x);
            l3(x);
            l4(x);
            l5(x);
            l7(x);
        }
        if(str2[i]=='b')
        {
            l2(x);
            l4(x);
            l5(x);
            l6(x);
            l7(x);

        }
        if(str2[i]=='C')
        {
            l1(x);
            l2(x);
            l5(x);
            l6(x);
        }
        if(str2[i]=='D')
        {
            l1(x);
            l2(x);
            l3(x);
            l5(x);
            l6(x);
            l7(x);
        }
        if(str2[i]=='E')
        {
            l1(x);
            l2(x);
            l4(x);
            l5(x);
            l6(x);
        }
        if(str2[i]=='F')
        {
            l1(x);
            l2(x);
            l4(x);
            l5(x);
        }
        if(str2[i]=='0')
        {
            l1(x);
            l2(x);
            l3(x);
            l5(x);
            l6(x);
            l7(x);
        }
        if(str2[i]=='1')
        {
            l3(x);
            l7(x);
        }
        if(str2[i]=='2')
        {
            l1(x);
            l3(x);
            l4(x);
            l5(x);
            l6(x);
        }
        if(str2[i]=='3')
        {
            l1(x);
            l3(x);
            l4(x);
            l7(x);
            l6(x);
        }
        if(str2[i]=='4')
        {
            l2(x);
            l3(x);
            l4(x);
            l7(x);
        }
        if(str2[i]=='5')
        {
            l1(x);
            l2(x);
            l4(x);
            l6(x);
            l7(x);
        }
        if(str2[i]=='6')
        {
            l1(x);
            l2(x);
            l4(x);
            l5(x);
            l6(x);
            l7(x);
        }
        if(str2[i]=='7')
        {
            l1(x);
            l3(x);
            l7(x);
        }
        if(str2[i]=='8')
        {
            l1(x);
            l2(x);
            l3(x);
            l4(x);
            l5(x);
            l6(x);
            l7(x);
        }
        if(str2[i]=='9')
        {
            l1(x);
            l2(x);
            l3(x);
            l4(x);
            l6(x);
            l7(x);
        }
    }
}

void iMouseMove(int mx, int my)
{
}

void iMouse(int button, int state, int mx, int my)
{
    if(button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
        if(mx >= 50 && mx <= 300 && my >= 250 && my <= 280 && mode == 0)
        {
            mode = 1;
        }
    }
}
void iKeyboard(unsigned char key)
{
    int i;
    if(mode == 1)
    {
        if(key == '\r')
        {
            c=400;
            mode = 0;
            strcpy(str2, str);
            for(i = 0; i < len; i++)
                str[i] = 0;
            len = 0;
        }
        else
        {
            str[len] = key;
            len++;
        }
    }

    if(key == 'x')
    {
        exit(0);
    }
}

void iSpecialKeyboard(unsigned char key)
{

    if(key == GLUT_KEY_END)
    {
        exit(0);
    }
}
void lessenc()
{
    c-=1;
}
void coloring()
{
    r=rand()%255;
    g=rand()%255;
    b=rand()%255;
}
int main()
{
    len = 0;
    mode = 0;
    str[0]= 0;
    iSetTimer(50,lessenc);
    iSetTimer(1000,coloring);
    iInitialize(400, 400, "TextInputDemoooo");
    return 0;
}
