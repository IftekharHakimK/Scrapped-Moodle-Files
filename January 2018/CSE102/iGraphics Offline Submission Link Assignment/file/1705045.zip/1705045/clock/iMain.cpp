# include "iGraphics.h"
#include<math.h>
#include<time.h>
time_t rawtime=time(NULL);
struct tm *info=localtime(&rawtime);
int hours=info -> tm_hour;
int minutes=info -> tm_min;
int sec=info ->tm_sec;
int x=hours*3600+minutes*60+sec;//For manual time,place hour,minute,second;
float pi=acos(-1);
int lx=300,ly=495;
float an1=pi/2,an2=pi/2-(x*pi/1800),an3=pi/2-(x*pi/21600);
char num[13][3]= {" ","1","2","3","4","5","6","7","8","9","10","11","12"};

void iDraw()
{

    iClear();
    iSetColor(255,255,255);
    iCircle(300,300,200);
    for(int i=1; i<=12; i++)
    {
        iText(300+215*cos((pi/2)-i*(pi/6)),300+215*sin((pi/2)-i*(pi/6)),num[i]);
    }
    iLine(300,300,300+(195*cos(an1)),300+195*(sin(an1)));
    iSetColor(200,150,200);
    iLine(300,300,300+(150*cos(an2)),300+(150*sin(an2)));
    iSetColor(50,50,255);
    iLine(300,300,300+100*cos(an3),300+100*sin(an3));

}
void iMouseMove(int mx, int my) {}

void iMouse(int button, int state, int mx, int my)
{
    if (button == GLUT_LEFT_BUTTON && state == GLUT_DOWN)
    {
    }
    if (button == GLUT_RIGHT_BUTTON && state == GLUT_DOWN)
    {
    }
}

void iKeyboard(unsigned char key)
{
    if (key == 'q')
    {
        exit(0);
    }

}
void iSpecialKeyboard(unsigned char key)
{
    if (key == GLUT_KEY_END)
    {
        exit(0);
    }
}
void second()
{
    an1-=pi/30;
}
void minute()
{
    an2-=pi/1800;
}
void hour()
{
    an3-=pi/21600;
}
int main()
{
    iSetTimer(1000,second);
    iSetTimer(1000,minute);
    iSetTimer(1000,hour);
    iInitialize(600, 600, "clock");
    return 0;
}
